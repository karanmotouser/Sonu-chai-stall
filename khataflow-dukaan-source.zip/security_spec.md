# Security Specification: Dukaan Management & Hisab-Kitab

## 1. Data Invariants
1. **Strict Single-Tenant Shop Ownership**: Every shop document `/shops/{shopId}` and every subcollection document `/shops/{shopId}/<collection>/{docId}` belongs strictly to the authenticated user whose `request.auth.uid == shopId` and `email_verified == true`.
2. **Owner Field Integrity**: Every document must contain `ownerId == request.auth.uid`, immutable across updates (`incoming().ownerId == existing().ownerId`).
3. **Temporal Integrity**: `createdAt == request.time` on creation and `createdAt == existing().createdAt` on updates; mutable entities enforce `updatedAt == request.time`.
4. **Immutable Ledgers**: `price_history`, `udhaar_transactions`, `supplier_payments`, `stock_movements`, `returns`, `cashbook_entries`, and `audit_logs` are append-only (updates and deletes forbidden from client SDK).
5. **Terminal State Locking**: Once a `bill` or `purchase` reaches `status == 'cancelled'`, it cannot be modified again (`existing().status != 'cancelled'`).
6. **Payload Bounds & Path Validation**: All document IDs match `^[a-zA-Z0-9_-]+$` (`<= 128` chars), all strings enforce explicit `.size()` bounds, and line-item arrays (`items`) are capped at `<= 100` items.
7. **PII Isolation**: Customer phone numbers, supplier GSTIN/phones, and owner contact info are strictly isolated inside `/shops/{shopId}/...` with zero cross-user `get` or `list` access.

## 2. The "Dirty Dozen" Attack Payloads (All Must Return PERMISSION_DENIED)
1. **Unauthenticated Read**: `get /shops/uidA/products/p1` with `auth = null`.
2. **Cross-Tenant List**: `list /shops/uidA/customers` signed in as `uidB`.
3. **Unverified Email Write**: `create /shops/uidA/products/p1` with `email_verified = false`.
4. **Identity Spoofing on Create**: `create /shops/uidA/products/p1` as `uidA` with `ownerId: "uidB"`.
5. **Shadow / Ghost Field Injection**: `create /shops/uidA/customers/c1` with extra unexpected field `isAdmin: true`.
6. **OwnerId Mutation on Update**: `update /shops/uidA/products/p1` changing `ownerId` from `uidA` to `uidB`.
7. **Price History Overwrite**: `update /shops/uidA/price_history/h1` attempting to alter `previousPrice`.
8. **Cancelled Bill Tampering**: `update /shops/uidA/bills/b1` when existing `status == 'cancelled'`.
9. **Client Timestamp Forgery**: `create /shops/uidA/expenses/e1` with forged past `createdAt` (`!= request.time`).
10. **Path ID Poisoning**: `create /shops/uidA/products/bad$id!@#` with invalid ID characters.
11. **Oversized String DoS**: `create /shops/uidA/products/p1` with `name` exceeding 160 chars.
12. **Unbounded Array DoS**: `create /shops/uidA/bills/b1` with `items` list size > 100.
