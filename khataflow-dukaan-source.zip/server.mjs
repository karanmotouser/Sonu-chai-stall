import express from 'express';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const distDir = path.resolve(__dirname, 'dist');
const port = Number(process.env.PORT) || 3000;

const app = express();

app.get('/healthz', (_req, res) => {
  res.status(200).json({ status: 'ok' });
});

app.get('/khataflow-dukaan-source.zip', (_req, res, next) => {
  const candidates = [
    path.join(distDir, 'khataflow-dukaan-source.zip'),
    path.resolve(__dirname, 'public', 'khataflow-dukaan-source.zip'),
    path.resolve(__dirname, 'khataflow-dukaan-source.zip'),
  ];
  const zipPath = candidates.find((p) => fs.existsSync(p));
  if (zipPath) {
    res.setHeader('Cache-Control', 'no-store');
    res.download(zipPath, 'khataflow-dukaan-source.zip');
    return;
  }
  next();
});

app.get('/manifest.webmanifest', (_req, res, next) => {
  const manifestPath = path.join(distDir, 'manifest.webmanifest');
  if (fs.existsSync(manifestPath)) {
    res.type('application/manifest+json');
    res.sendFile(manifestPath);
    return;
  }
  next();
});

app.use(
  express.static(distDir, {
    index: 'index.html',
    extensions: ['html'],
  })
);

// SPA fallback: return index.html for any client route instead of 404
app.get('*', (_req, res) => {
  const indexPath = path.join(distDir, 'index.html');
  if (fs.existsSync(indexPath)) {
    res.status(200).sendFile(indexPath);
  } else {
    res.status(500).send('Build output missing. Run npm run build first.');
  }
});

app.listen(port, '0.0.0.0', () => {
  console.log(`KhataFlow Dukaan server listening on http://0.0.0.0:${port}`);
});
