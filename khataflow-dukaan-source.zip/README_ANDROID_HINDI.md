# KhataFlow Dukaan — बिना कंप्यूटर के फ़ोन से Android APK डाउनलोड और इंस्टॉल करने की विधि

इस प्रोजेक्ट में **Capacitor Android प्रोजेक्ट (`android/`)** और **स्वचालित GitHub Actions APK बिल्ड वर्कफ़्लो (`.github/workflows/build-android-apk.yml`)** पहले से तैयार हैं।  
आप अपने Android फ़ोन के Chrome ब्राउज़र से ही बिना किसी कंप्यूटर या Android Studio के असली इंस्टॉल होने वाली `.apk` फ़ाइल बना और डाउनलोड कर सकते हैं।

---

## चरण 1: सोर्स कोड ZIP को Unzip करें
1. ऐप से **KhataFlow Dukaan सोर्स कोड ZIP (`khataflow-dukaan-source.zip`)** डाउनलोड करें।
2. अपने फ़ोन के File Manager (या ZArchiver / Files by Google) में जाकर इस ZIP फ़ाइल को **Extract / Unzip** करें।

---

## चरण 2: GitHub पर अपलोड करें (फ़ोन ब्राउज़र से ही)
1. अपने फ़ोन के Chrome में **[github.com](https://github.com)** खोलें और लॉग-इन करें (अगर अकाउंट नहीं है तो मुफ्त में बनाएं)।
2. ऊपर दाईं ओर `+` आइकन पर टैप करके **New repository** चुनें।
3. Repository का नाम लिखें (उदाहरण: `khataflow-dukaan`) और **Create repository** पर टैप करें।
4. अब **uploading an existing file** लिंक पर टैप करें और निकाले गए प्रोजेक्ट की सभी फ़ाइलें और फ़ोल्डर्स (खासकर `src/`, `public/`, `android/`, `.github/`, `package.json`, `capacitor.config.ts`) अपलोड करके **Commit changes** दबाएं।
   > **टिप:** अगर फ़ोन ब्राउज़र में एक साथ ज़्यादा फ़ोल्डर अपलोड करने में दिक्कत आए, तो आप GitHub Mobile ऐप या Termux / Git का उपयोग कर सकते हैं — या पहले फ़ाइलें अपलोड करके `.github/workflows/build-android-apk.yml` फ़ोल्डर जरूर शामिल करें।

---

## चरण 3: GitHub Actions से APK अपने-आप बनवाएं
1. अपलोड होते ही अपने GitHub Repository पेज पर ऊपर **Actions** टैब पर टैप करें।
2. बाईं तरफ **Build KhataFlow Dukaan Android APK** नाम का वर्कफ़्लो दिखाई देगा।
3. वह अपने-आप चालू हो चुका होगा (अगर न दिखे तो **Run workflow** बटन दबाएं)।
4. लगभग **3 से 5 मिनट** इंतज़ार करें जब तक हरा टिक (✅) न आ जाए।

---

## चरण 4: APK डाउनलोड करके फ़ोन में इंस्टॉल करें
1. हरे टिक वाले **Build KhataFlow Dukaan Android APK** रन पर टैप करें।
2. पेज के सबसे नीचे **Artifacts** सेक्शन में जाएं।
3. वहाँ **`KhataFlow-Dukaan-APK`** दिखाई देगा — उस पर टैप करके डाउनलोड करें (एक छोटी ZIP फ़ाइल डाउनलोड होगी)।
4. डाउनलोड की गई `KhataFlow-Dukaan-APK.zip` को खोलें — इसके अंदर **`KhataFlow-Dukaan-debug.apk`** फ़ाइल मिलेगी।
5. **`KhataFlow-Dukaan-debug.apk`** पर टैप करें।
6. अगर Android पूछे तो **"Settings → Allow from this source / अज्ञात स्रोतों से इंस्टॉल की अनुमति दें"** चालू करें और **Install** दबाएं।

अब **KhataFlow Dukaan** आपके फ़ोन में असली Android ऐप की तरह इंस्टॉल हो चुका है और **बिना इंटरनेट (ऑफ़लाइन)** भी पूरा काम करेगा!

---

## लोकल कंप्यूटर से सीधे APK बनाने के कमांड (वैकल्पिक)
यदि आपके पास कंप्यूटर / Android Studio है:
```bash
npm install
npm run build
npx cap sync android
cd android
./gradlew assembleDebug
```
तैयार APK यहाँ मिलेगी:  
`android/app/build/outputs/apk/debug/app-debug.apk`
