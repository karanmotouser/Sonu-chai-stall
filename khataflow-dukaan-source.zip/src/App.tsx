import { App as CapApp } from '@capacitor/app';
import { Capacitor } from '@capacitor/core';
import React, { useEffect } from 'react';
import { AuthGate } from './components/AuthGate';
import { ErrorBoundary } from './components/ErrorBoundary';
import { LayoutShell } from './components/LayoutShell';
import { PrintModal } from './components/PrintModal';
import { DukaanProvider, useDukaan } from './context/DukaanContext';
import { BillingPosPage } from './pages/BillingPosPage';
import { CashbookPage } from './pages/CashbookPage';
import { CustomersPage } from './pages/CustomersPage';
import { DashboardPage } from './pages/DashboardPage';
import { ExpensesPage } from './pages/ExpensesPage';
import { PriceManagementPage } from './pages/PriceManagementPage';
import { ProductsPage } from './pages/ProductsPage';
import { PurchasePage } from './pages/PurchasePage';
import { ReportsPage } from './pages/ReportsPage';
import { ReturnsPage } from './pages/ReturnsPage';
import { SettingsPage } from './pages/SettingsPage';
import { StockPage } from './pages/StockPage';
import { SuppliersPage } from './pages/SuppliersPage';
import { UdhaarPage } from './pages/UdhaarPage';

const ActiveView: React.FC = () => {
  const { activeSection, setActiveSection, setEditingBillId } = useDukaan();

  useEffect(() => {
    if (!Capacitor.isNativePlatform()) return;
    const listenerPromise = CapApp.addListener('backButton', () => {
      if (activeSection !== 'dashboard') {
        setEditingBillId(null);
        setActiveSection('dashboard');
      } else {
        void CapApp.exitApp();
      }
    });
    return () => {
      void listenerPromise.then((h) => h.remove());
    };
  }, [activeSection, setActiveSection, setEditingBillId]);

  switch (activeSection) {
    case 'dashboard':
      return <DashboardPage />;
    case 'billing':
      return <BillingPosPage />;
    case 'products':
      return <ProductsPage />;
    case 'stock':
      return <StockPage />;
    case 'pricing':
      return <PriceManagementPage />;
    case 'purchase':
      return <PurchasePage />;
    case 'customers':
      return <CustomersPage />;
    case 'udhaar':
      return <UdhaarPage />;
    case 'suppliers':
      return <SuppliersPage />;
    case 'expenses':
      return <ExpensesPage />;
    case 'cashbook':
      return <CashbookPage />;
    case 'returns':
      return <ReturnsPage />;
    case 'reports':
      return <ReportsPage />;
    case 'settings':
      return <SettingsPage />;
    default:
      return <DashboardPage />;
  }
};

export default function App() {
  return (
    <ErrorBoundary>
      <DukaanProvider>
        <AuthGate>
          <LayoutShell>
            <ActiveView />
          </LayoutShell>
          <PrintModal />
        </AuthGate>
      </DukaanProvider>
    </ErrorBoundary>
  );
}
