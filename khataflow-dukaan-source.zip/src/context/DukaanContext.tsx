import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { Capacitor } from '@capacitor/core';
import { onAuthStateChanged, signInWithPopup, signOut, User } from 'firebase/auth';
import { collection, doc, onSnapshot, orderBy, query, where } from 'firebase/firestore';
import { auth, db, googleAuthProvider, handleFirestoreError, OperationType } from '../lib/firebase';
import { LOCAL_UID, subscribeLocalStore } from '../lib/localDb';
import { ensureShopProfile, updateShopProfile } from '../services/dukaanService';
import {
  AuditLog,
  Bill,
  CashbookEntry,
  Customer,
  Expense,
  Language,
  NavSection,
  PriceHistoryRecord,
  Product,
  Purchase,
  ReturnRecord,
  ShopProfile,
  StockMovement,
  Supplier,
  SupplierPayment,
  ThemeMode,
  UdhaarTransaction,
} from '../types/dukaan';

export interface ToastMessage {
  id: string;
  type: 'success' | 'error' | 'info';
  text: string;
}

export interface PrintPayload {
  title: string;
  content: React.ReactNode;
}

interface DukaanContextValue {
  user: User | null;
  authLoading: boolean;
  dataLoading: boolean;
  shopProfile: ShopProfile | null;
  lang: Language;
  setLang: (lang: Language) => void;
  theme: ThemeMode;
  toggleTheme: () => void;
  activeSection: NavSection;
  setActiveSection: (section: NavSection) => void;
  pinLocked: boolean;
  unlockWithPin: () => void;
  lockApp: () => void;
  signIn: () => Promise<void>;
  startLocalMode: () => void;
  isLocalMode: boolean;
  logout: () => Promise<void>;
  notify: (text: string, type?: ToastMessage['type']) => void;
  toasts: ToastMessage[];
  dismissToast: (id: string) => void;
  printPayload: PrintPayload | null;
  openPrintModal: (payload: PrintPayload) => void;
  closePrintModal: () => void;
  editingBillId: string | null;
  setEditingBillId: (id: string | null) => void;
  // Live Firestore collections
  products: Product[];
  priceHistory: PriceHistoryRecord[];
  bills: Bill[];
  purchases: Purchase[];
  customers: Customer[];
  udhaarTransactions: UdhaarTransaction[];
  suppliers: Supplier[];
  supplierPayments: SupplierPayment[];
  expenses: Expense[];
  stockMovements: StockMovement[];
  returns: ReturnRecord[];
  cashbookEntries: CashbookEntry[];
  auditLogs: AuditLog[];
}

const DukaanContext = createContext<DukaanContextValue | null>(null);

export const DukaanProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLocalMode, setIsLocalMode] = useState<boolean>(() => {
    const saved = localStorage.getItem('khataflow_local_mode');
    if (saved === 'true') return true;
    if (saved === 'false') return false;
    return Capacitor.isNativePlatform();
  });
  const [authLoading, setAuthLoading] = useState(true);
  const [dataLoading, setDataLoading] = useState(false);
  const [shopProfile, setShopProfile] = useState<ShopProfile | null>(null);

  const [lang, setLangState] = useState<Language>(() => {
    const saved = localStorage.getItem('khataflow_lang');
    return saved === 'en' ? 'en' : 'hi';
  });

  const [theme, setTheme] = useState<ThemeMode>(() => {
    const saved = localStorage.getItem('khataflow_theme');
    return saved === 'dark' ? 'dark' : 'light';
  });

  const [activeSection, setActiveSection] = useState<NavSection>('dashboard');
  const [pinLocked, setPinLocked] = useState(false);
  const [pinCheckedForUid, setPinCheckedForUid] = useState<string | null>(null);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const [printPayload, setPrintPayload] = useState<PrintPayload | null>(null);
  const [editingBillId, setEditingBillId] = useState<string | null>(null);

  const [products, setProducts] = useState<Product[]>([]);
  const [priceHistory, setPriceHistory] = useState<PriceHistoryRecord[]>([]);
  const [bills, setBills] = useState<Bill[]>([]);
  const [purchases, setPurchases] = useState<Purchase[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [udhaarTransactions, setUdhaarTransactions] = useState<UdhaarTransaction[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [supplierPayments, setSupplierPayments] = useState<SupplierPayment[]>([]);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [stockMovements, setStockMovements] = useState<StockMovement[]>([]);
  const [returns, setReturns] = useState<ReturnRecord[]>([]);
  const [cashbookEntries, setCashbookEntries] = useState<CashbookEntry[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);

  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    localStorage.setItem('khataflow_theme', theme);
  }, [theme]);

  const toggleTheme = useCallback(() => {
    setTheme((prev) => (prev === 'dark' ? 'light' : 'dark'));
  }, []);

  const dismissToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const notify = useCallback((text: string, type: ToastMessage['type'] = 'success') => {
    const id = `${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
    setToasts((prev) => [...prev, { id, type, text }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 3500);
  }, []);

  const setLang = useCallback(
    (next: Language) => {
      setLangState(next);
      localStorage.setItem('khataflow_lang', next);
      if (user && shopProfile) {
        void updateShopProfile(user.uid, { language: next });
      }
    },
    [user, shopProfile]
  );

  // Auth listener
  useEffect(() => {
    if (isLocalMode) {
      const localUser = {
        uid: LOCAL_UID,
        email: 'offline@khataflow.local',
        emailVerified: true,
        displayName: 'दुकान मालिक',
      } as unknown as User;
      setUser(localUser);
      setAuthLoading(false);
      return;
    }

    const unsub = onAuthStateChanged(auth, async (firebaseUser) => {
      setUser(firebaseUser);
      setAuthLoading(false);
      if (!firebaseUser) {
        setShopProfile(null);
        setProducts([]);
        setPriceHistory([]);
        setBills([]);
        setPurchases([]);
        setCustomers([]);
        setUdhaarTransactions([]);
        setSuppliers([]);
        setSupplierPayments([]);
        setExpenses([]);
        setStockMovements([]);
        setReturns([]);
        setCashbookEntries([]);
        setAuditLogs([]);
        setPinLocked(false);
        setPinCheckedForUid(null);
      }
    });
    return () => unsub();
  }, [isLocalMode]);

  // Firestore OR Local IndexedDB real-time listeners
  useEffect(() => {
    if (!user || !user.emailVerified) return;

    let cancelled = false;
    const uid = user.uid;
    const unsubscribers: (() => void)[] = [];

    if (uid === LOCAL_UID) {
      async function initLocal() {
        setDataLoading(true);
        try {
          const profile = await ensureShopProfile(uid, 'दुकान मालिक', '');
          if (cancelled) return;
          setShopProfile(profile);
          if (profile.pinHash && pinCheckedForUid !== uid) {
            setPinLocked(true);
            setPinCheckedForUid(uid);
          }
          unsubscribers.push(
            subscribeLocalStore<ShopProfile>('shops', 'createdAt', (list) => {
              const found = list.find((s) => s.id === uid);
              if (found) setShopProfile(found);
            }),
            subscribeLocalStore<Product>('products', 'name', setProducts),
            subscribeLocalStore<PriceHistoryRecord>('price_history', 'createdAt', setPriceHistory),
            subscribeLocalStore<Bill>('bills', 'createdAt', setBills),
            subscribeLocalStore<Purchase>('purchases', 'createdAt', setPurchases),
            subscribeLocalStore<Customer>('customers', 'name', setCustomers),
            subscribeLocalStore<UdhaarTransaction>('udhaar_transactions', 'createdAt', setUdhaarTransactions),
            subscribeLocalStore<Supplier>('suppliers', 'name', setSuppliers),
            subscribeLocalStore<SupplierPayment>('supplier_payments', 'createdAt', setSupplierPayments),
            subscribeLocalStore<Expense>('expenses', 'createdAt', setExpenses),
            subscribeLocalStore<StockMovement>('stock_movements', 'createdAt', setStockMovements),
            subscribeLocalStore<ReturnRecord>('returns', 'createdAt', setReturns),
            subscribeLocalStore<CashbookEntry>('cashbook_entries', 'createdAt', setCashbookEntries),
            subscribeLocalStore<AuditLog>('audit_logs', 'createdAt', setAuditLogs)
          );
        } finally {
          if (!cancelled) setDataLoading(false);
        }
      }
      void initLocal();
      return () => {
        cancelled = true;
        unsubscribers.forEach((fn) => fn());
      };
    }

    async function initAndSubscribe() {
      setDataLoading(true);
      try {
        const profile = await ensureShopProfile(
          uid,
          user!.displayName || '',
          user!.email || ''
        );
        if (cancelled) return;

        setShopProfile(profile);
        if (profile.language && !localStorage.getItem('khataflow_lang')) {
          setLangState(profile.language);
        }
        if (profile.pinHash && pinCheckedForUid !== uid) {
          setPinLocked(true);
          setPinCheckedForUid(uid);
        }

        // Shop profile live listener
        unsubscribers.push(
          onSnapshot(
            doc(db, 'shops', uid),
            (snap) => {
              if (snap.exists()) {
                setShopProfile({ id: snap.id, ...(snap.data() as Omit<ShopProfile, 'id'>) });
              }
            },
            (err) => handleFirestoreError(err, OperationType.GET, `shops/${uid}`)
          )
        );

        const subscribeCol = <T,>(
          colName: string,
          setter: React.Dispatch<React.SetStateAction<T[]>>,
          orderField = 'createdAt'
        ) => {
          const path = `shops/${uid}/${colName}`;
          const q = query(
            collection(db, 'shops', uid, colName),
            where('ownerId', '==', uid),
            orderBy(orderField, 'desc')
          );
          unsubscribers.push(
            onSnapshot(
              q,
              (snap) => {
                const list = snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<T, 'id'>) })) as T[];
                setter(list);
              },
              (err) => handleFirestoreError(err, OperationType.LIST, path)
            )
          );
        };

        subscribeCol<Product>('products', setProducts, 'name');
        subscribeCol<PriceHistoryRecord>('price_history', setPriceHistory, 'createdAt');
        subscribeCol<Bill>('bills', setBills, 'createdAt');
        subscribeCol<Purchase>('purchases', setPurchases, 'createdAt');
        subscribeCol<Customer>('customers', setCustomers, 'name');
        subscribeCol<UdhaarTransaction>('udhaar_transactions', setUdhaarTransactions, 'createdAt');
        subscribeCol<Supplier>('suppliers', setSuppliers, 'name');
        subscribeCol<SupplierPayment>('supplier_payments', setSupplierPayments, 'createdAt');
        subscribeCol<Expense>('expenses', setExpenses, 'createdAt');
        subscribeCol<StockMovement>('stock_movements', setStockMovements, 'createdAt');
        subscribeCol<ReturnRecord>('returns', setReturns, 'createdAt');
        subscribeCol<CashbookEntry>('cashbook_entries', setCashbookEntries, 'createdAt');
        subscribeCol<AuditLog>('audit_logs', setAuditLogs, 'createdAt');
      } finally {
        if (!cancelled) setDataLoading(false);
      }
    }

    void initAndSubscribe();

    return () => {
      cancelled = true;
      unsubscribers.forEach((fn) => fn());
    };
  }, [user, pinCheckedForUid]);

  const signIn = useCallback(async () => {
    try {
      localStorage.setItem('khataflow_local_mode', 'false');
      setIsLocalMode(false);
      await signInWithPopup(auth, googleAuthProvider);
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Sign-in failed', 'error');
    }
  }, [notify]);

  const startLocalMode = useCallback(() => {
    localStorage.setItem('khataflow_local_mode', 'true');
    setIsLocalMode(true);
  }, []);

  const logout = useCallback(async () => {
    if (isLocalMode) {
      localStorage.setItem('khataflow_local_mode', 'false');
      setIsLocalMode(false);
      setUser(null);
      return;
    }
    await signOut(auth);
  }, [isLocalMode]);

  const unlockWithPin = useCallback(() => setPinLocked(false), []);
  const lockApp = useCallback(() => {
    if (shopProfile?.pinHash) setPinLocked(true);
  }, [shopProfile]);

  const openPrintModal = useCallback((payload: PrintPayload) => setPrintPayload(payload), []);
  const closePrintModal = useCallback(() => setPrintPayload(null), []);

  const value = useMemo<DukaanContextValue>(
    () => ({
      user,
      authLoading,
      dataLoading,
      shopProfile,
      lang,
      setLang,
      theme,
      toggleTheme,
      activeSection,
      setActiveSection,
      pinLocked,
      unlockWithPin,
      lockApp,
      signIn,
      startLocalMode,
      isLocalMode,
      logout,
      notify,
      toasts,
      dismissToast,
      printPayload,
      openPrintModal,
      closePrintModal,
      editingBillId,
      setEditingBillId,
      products,
      priceHistory,
      bills,
      purchases,
      customers,
      udhaarTransactions,
      suppliers,
      supplierPayments,
      expenses,
      stockMovements,
      returns,
      cashbookEntries,
      auditLogs,
    }),
    [
      user,
      authLoading,
      dataLoading,
      shopProfile,
      lang,
      setLang,
      theme,
      toggleTheme,
      activeSection,
      pinLocked,
      unlockWithPin,
      lockApp,
      signIn,
      startLocalMode,
      isLocalMode,
      logout,
      notify,
      toasts,
      dismissToast,
      printPayload,
      openPrintModal,
      closePrintModal,
      editingBillId,
      products,
      priceHistory,
      bills,
      purchases,
      customers,
      udhaarTransactions,
      suppliers,
      supplierPayments,
      expenses,
      stockMovements,
      returns,
      cashbookEntries,
      auditLogs,
    ]
  );

  return <DukaanContext.Provider value={value}>{children}</DukaanContext.Provider>;
};

export function useDukaan(): DukaanContextValue {
  const ctx = useContext(DukaanContext);
  if (!ctx) throw new Error('useDukaan must be used inside DukaanProvider');
  return ctx;
}
