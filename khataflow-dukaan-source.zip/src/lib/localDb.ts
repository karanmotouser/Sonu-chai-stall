import { Timestamp } from 'firebase/firestore';

export const LOCAL_UID = 'local_dukaan';

export const LOCAL_STORES = [
  'shops',
  'products',
  'price_history',
  'bills',
  'purchases',
  'customers',
  'udhaar_transactions',
  'suppliers',
  'supplier_payments',
  'expenses',
  'stock_movements',
  'returns',
  'cashbook_entries',
  'audit_logs',
] as const;

export type LocalStoreName = (typeof LOCAL_STORES)[number];

const DB_NAME = 'khataflow_dukaan_local_db';
const DB_VERSION = 1;

let dbPromise: Promise<IDBDatabase> | null = null;
const storeListeners = new Map<LocalStoreName, Set<() => void>>();

function openLocalDb(): Promise<IDBDatabase> {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      for (const name of LOCAL_STORES) {
        if (!db.objectStoreNames.contains(name)) {
          db.createObjectStore(name, { keyPath: 'id' });
        }
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error || new Error('IndexedDB open failed'));
  });
  return dbPromise;
}

function hydrateTimestamps<T extends Record<string, unknown>>(obj: T): T {
  const copy: Record<string, unknown> = { ...obj };
  for (const key of ['createdAt', 'updatedAt'] as const) {
    const val = copy[key];
    if (val && typeof val === 'object' && 'seconds' in (val as Record<string, unknown>)) {
      const s = Number((val as { seconds: number }).seconds) || 0;
      const ns = Number((val as { nanoseconds?: number }).nanoseconds) || 0;
      copy[key] = new Timestamp(s, ns);
    } else if (typeof val === 'number') {
      copy[key] = Timestamp.fromMillis(val);
    }
  }
  return copy as T;
}

function serializeTimestamps<T extends Record<string, unknown>>(obj: T): T {
  const copy: Record<string, unknown> = { ...obj };
  for (const key of ['createdAt', 'updatedAt'] as const) {
    const val = copy[key];
    if (val && typeof val === 'object' && 'seconds' in (val as Record<string, unknown>)) {
      copy[key] = {
        seconds: (val as { seconds: number }).seconds,
        nanoseconds: (val as { nanoseconds?: number }).nanoseconds || 0,
      };
    }
  }
  return copy as T;
}

export function nowLocalTimestamp(): Timestamp {
  return Timestamp.now();
}

export function notifyLocalStore(name: LocalStoreName) {
  const set = storeListeners.get(name);
  if (set) {
    set.forEach((cb) => cb());
  }
}

export async function localGetAll<T extends { id: string }>(storeName: LocalStoreName): Promise<T[]> {
  const db = await openLocalDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readonly');
    const store = tx.objectStore(storeName);
    const req = store.getAll();
    req.onsuccess = () => {
      const items = (req.result as Record<string, unknown>[]).map((r) => hydrateTimestamps(r) as T);
      resolve(items);
    };
    req.onerror = () => reject(req.error);
  });
}

export async function localGetById<T extends { id: string }>(
  storeName: LocalStoreName,
  id: string
): Promise<T | null> {
  const db = await openLocalDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readonly');
    const store = tx.objectStore(storeName);
    const req = store.get(id);
    req.onsuccess = () => {
      const res = req.result as Record<string, unknown> | undefined;
      resolve(res ? (hydrateTimestamps(res) as T) : null);
    };
    req.onerror = () => reject(req.error);
  });
}

export async function localPut<T extends { id: string }>(
  storeName: LocalStoreName,
  item: T
): Promise<void> {
  const db = await openLocalDb();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction(storeName, 'readwrite');
    const store = tx.objectStore(storeName);
    store.put(serializeTimestamps(item as unknown as Record<string, unknown>));
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
  notifyLocalStore(storeName);
}

export async function localPutMany<T extends { id: string }>(
  storeName: LocalStoreName,
  items: T[]
): Promise<void> {
  if (items.length === 0) return;
  const db = await openLocalDb();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction(storeName, 'readwrite');
    const store = tx.objectStore(storeName);
    for (const item of items) {
      store.put(serializeTimestamps(item as unknown as Record<string, unknown>));
    }
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
  notifyLocalStore(storeName);
}

export async function localDelete(storeName: LocalStoreName, id: string): Promise<void> {
  const db = await openLocalDb();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction(storeName, 'readwrite');
    tx.objectStore(storeName).delete(id);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
  notifyLocalStore(storeName);
}

export function subscribeLocalStore<T extends { id: string }>(
  storeName: LocalStoreName,
  orderField: 'createdAt' | 'name',
  onUpdate: (items: T[]) => void
): () => void {
  let active = true;

  const load = async () => {
    try {
      const list = await localGetAll<T>(storeName);
      if (!active) return;
      list.sort((a, b) => {
        if (orderField === 'name') {
          const an = String((a as Record<string, unknown>).name || '');
          const bn = String((b as Record<string, unknown>).name || '');
          return bn.localeCompare(an);
        }
        const at = (a as Record<string, unknown>).createdAt as { seconds?: number } | undefined;
        const bt = (b as Record<string, unknown>).createdAt as { seconds?: number } | undefined;
        return (bt?.seconds || 0) - (at?.seconds || 0);
      });
      onUpdate(list);
    } catch (err) {
      console.error(`LocalDB read error (${storeName}):`, err);
    }
  };

  let set = storeListeners.get(storeName);
  if (!set) {
    set = new Set();
    storeListeners.set(storeName, set);
  }
  set.add(load);
  void load();

  return () => {
    active = false;
    storeListeners.get(storeName)?.delete(load);
  };
}
