import * as XLSX from 'xlsx';

export function formatINR(amount: number): string {
  const safe = Number.isFinite(amount) ? amount : 0;
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(safe);
}

export function formatNumber(num: number): string {
  const safe = Number.isFinite(num) ? num : 0;
  return new Intl.NumberFormat('en-IN', {
    maximumFractionDigits: 2,
  }).format(safe);
}

export function getTodayISO(): string {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

export function getMonthPrefix(dateStr?: string): string {
  return (dateStr || getTodayISO()).slice(0, 7);
}

export function getYearPrefix(dateStr?: string): string {
  return (dateStr || getTodayISO()).slice(0, 4);
}

export function isWithinLastDays(dateStr: string, days: number): boolean {
  if (!dateStr) return false;
  const target = new Date(dateStr + 'T00:00:00');
  const today = new Date(getTodayISO() + 'T00:00:00');
  const diffMs = today.getTime() - target.getTime();
  const diffDays = diffMs / (1000 * 60 * 60 * 24);
  return diffDays >= 0 && diffDays < days;
}

export function formatDisplayDate(dateStr: string, lang: 'hi' | 'en' = 'hi'): string {
  if (!dateStr) return '-';
  const d = new Date(dateStr + 'T00:00:00');
  if (Number.isNaN(d.getTime())) return dateStr;
  return d.toLocaleDateString(lang === 'hi' ? 'hi-IN' : 'en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
}

export function formatTimestamp(
  ts: { toDate?: () => Date; seconds?: number } | number | string | undefined | null,
  lang: 'hi' | 'en' = 'hi'
): string {
  if (!ts) return '-';
  let date: Date | null = null;
  if (typeof ts === 'number' || typeof ts === 'string') {
    date = new Date(ts);
  } else if (typeof ts.toDate === 'function') {
    date = ts.toDate();
  } else if (typeof ts.seconds === 'number') {
    date = new Date(ts.seconds * 1000);
  }
  if (!date || Number.isNaN(date.getTime())) return '-';
  return date.toLocaleString(lang === 'hi' ? 'hi-IN' : 'en-IN', {
    day: '2-digit',
    month: 'short',
    hour: '2-digit',
    minute: '2-digit',
  });
}

export function calculateProfitMargin(purchasePrice: number, sellingPrice: number): number {
  if (sellingPrice <= 0) return 0;
  return Number((((sellingPrice - purchasePrice) / sellingPrice) * 100).toFixed(2));
}

export function calculateMarkupPercent(purchasePrice: number, sellingPrice: number): number {
  if (purchasePrice <= 0) return sellingPrice > 0 ? 100 : 0;
  return Number((((sellingPrice - purchasePrice) / purchasePrice) * 100).toFixed(2));
}

export function generateDocId(prefix: string): string {
  const rand = Math.random().toString(36).slice(2, 8);
  return `${prefix}_${Date.now()}_${rand}`;
}

export function sanitizeId(raw: string): string {
  return raw.replace(/[^a-zA-Z0-9_-]/g, '_').slice(0, 120);
}

export async function hashPin(pin: string): Promise<string> {
  const enc = new TextEncoder().encode(`khataflow_salt_${pin}`);
  const hashBuffer = await crypto.subtle.digest('SHA-256', enc);
  return Array.from(new Uint8Array(hashBuffer))
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
}

export function exportToExcel(
  filename: string,
  sheetName: string,
  rows: Record<string, string | number | boolean>[]
): void {
  const worksheet = XLSX.utils.json_to_sheet(rows);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, sheetName.slice(0, 31));
  XLSX.writeFile(workbook, `${filename}.xlsx`);
}

export function buildWhatsAppUrl(phone: string, message: string): string {
  const digits = phone.replace(/\D/g, '');
  const formattedPhone = digits.length === 10 ? `91${digits}` : digits;
  const base = formattedPhone ? `https://wa.me/${formattedPhone}` : 'https://wa.me/';
  return `${base}?text=${encodeURIComponent(message)}`;
}

export async function compressImageFile(file: File, maxDim = 420, quality = 0.72): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('Failed to read image file'));
    reader.onload = () => {
      const img = new Image();
      img.onerror = () => reject(new Error('Invalid image file'));
      img.onload = () => {
        const canvas = document.createElement('canvas');
        let { width, height } = img;
        if (width > height && width > maxDim) {
          height = Math.round((height * maxDim) / width);
          width = maxDim;
        } else if (height > maxDim) {
          width = Math.round((width * maxDim) / height);
          height = maxDim;
        }
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          reject(new Error('Canvas not supported'));
          return;
        }
        ctx.drawImage(img, 0, 0, width, height);
        const dataUrl = canvas.toDataURL('image/jpeg', quality);
        resolve(dataUrl);
      };
      img.src = String(reader.result);
    };
    reader.readAsDataURL(file);
  });
}
