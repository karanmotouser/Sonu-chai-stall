import { Capacitor } from '@capacitor/core';
import { useEffect, useState } from 'react';

export interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed'; platform: string }>;
}

export interface SourceZipInfo {
  sizeBytes: number;
  sizeMB: string;
  fileCount: number;
}

let globalDeferredPrompt: BeforeInstallPromptEvent | null = null;
let globalIsInstalled = false;
const listeners = new Set<() => void>();

function notifyListeners() {
  listeners.forEach((cb) => cb());
}

if (typeof window !== 'undefined') {
  globalIsInstalled =
    Capacitor.isNativePlatform() ||
    window.matchMedia('(display-mode: standalone)').matches ||
    (window.navigator as unknown as { standalone?: boolean }).standalone === true;

  window.addEventListener('beforeinstallprompt', (e: Event) => {
    e.preventDefault();
    globalDeferredPrompt = e as BeforeInstallPromptEvent;
    notifyListeners();
  });

  window.addEventListener('appinstalled', () => {
    globalIsInstalled = true;
    globalDeferredPrompt = null;
    notifyListeners();
  });
}

export const SOURCE_ZIP_PATH = '/khataflow-dukaan-source.zip';

export function getSourceZipDirectUrl(): string {
  if (typeof window === 'undefined') return SOURCE_ZIP_PATH;
  return `${window.location.origin}${SOURCE_ZIP_PATH}`;
}

export function useSourceZipInfo(): SourceZipInfo {
  const [info, setInfo] = useState<SourceZipInfo>({
    sizeBytes: 8446298,
    sizeMB: '8.1',
    fileCount: 134,
  });

  useEffect(() => {
    if (Capacitor.isNativePlatform()) return;
    let active = true;
    fetch('/source-info.json', { cache: 'no-store' })
      .then((res) => (res.ok ? res.json() : null))
      .then((data: SourceZipInfo | null) => {
        if (active && data && typeof data.sizeBytes === 'number') {
          setInfo(data);
        }
      })
      .catch(() => {});
    return () => {
      active = false;
    };
  }, []);

  return info;
}

export async function downloadSourceZipWithProgress(
  onProgress?: (loadedMB: string, totalMB: string, pct: number) => void
): Promise<number> {
  const res = await fetch(`${SOURCE_ZIP_PATH}?dl=${Date.now()}`, { cache: 'no-store' });
  if (!res.ok) {
    throw new Error(`Download failed (HTTP ${res.status})`);
  }
  const contentType = (res.headers.get('content-type') || '').toLowerCase();
  if (contentType.includes('text/html')) {
    throw new Error('Server returned HTML instead of ZIP archive.');
  }

  const totalBytes = Number(res.headers.get('content-length') || 0);
  const reader = res.body?.getReader();

  let blob: Blob;
  if (reader) {
    const chunks: Uint8Array[] = [];
    let received = 0;
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      if (value) {
        chunks.push(value);
        received += value.byteLength;
        if (onProgress) {
          const loadedMB = (received / (1024 * 1024)).toFixed(1);
          const totalMB = totalBytes > 0 ? (totalBytes / (1024 * 1024)).toFixed(1) : loadedMB;
          const pct = totalBytes > 0 ? Math.min(100, Math.round((received / totalBytes) * 100)) : 50;
          onProgress(loadedMB, totalMB, pct);
        }
      }
    }
    blob = new Blob(chunks as unknown as BlobPart[], { type: 'application/zip' });
  } else {
    blob = await res.blob();
  }

  if (blob.size < 100_000) {
    throw new Error('Downloaded file was incomplete.');
  }

  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'khataflow-dukaan-source.zip';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 10000);
  return blob.size;
}

export function usePWAInstall() {
  const isNative = Capacitor.isNativePlatform();
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(
    globalDeferredPrompt
  );
  const [isInstalled, setIsInstalled] = useState<boolean>(globalIsInstalled || isNative);
  const [isIOS, setIsIOS] = useState(false);
  const [isAndroid, setIsAndroid] = useState(false);
  const [isInIframe, setIsInIframe] = useState(false);

  useEffect(() => {
    const sync = () => {
      setDeferredPrompt(globalDeferredPrompt);
      setIsInstalled(globalIsInstalled || isNative);
    };

    listeners.add(sync);

    const ua = window.navigator.userAgent.toLowerCase();
    setIsIOS(/iphone|ipad|ipod/.test(ua));
    setIsAndroid(/android/.test(ua));
    try {
      setIsInIframe(window.self !== window.top);
    } catch {
      setIsInIframe(true);
    }

    const standaloneMedia = window.matchMedia('(display-mode: standalone)');
    const handleDisplayChange = (e: MediaQueryListEvent) => {
      if (e.matches) {
        globalIsInstalled = true;
        sync();
      }
    };
    standaloneMedia.addEventListener('change', handleDisplayChange);

    sync();

    return () => {
      listeners.delete(sync);
      standaloneMedia.removeEventListener('change', handleDisplayChange);
    };
  }, [isNative]);

  const install = async (): Promise<boolean> => {
    if (!globalDeferredPrompt) return false;
    await globalDeferredPrompt.prompt();
    const { outcome } = await globalDeferredPrompt.userChoice;
    if (outcome === 'accepted') {
      globalIsInstalled = true;
      globalDeferredPrompt = null;
      notifyListeners();
      return true;
    }
    return false;
  };

  return {
    isNative,
    isInstallable: !isNative && !!deferredPrompt,
    isInstalled,
    isIOS,
    isAndroid,
    isInIframe,
    sourceZipUrl: SOURCE_ZIP_PATH,
    install,
  };
}

export function useOnlineStatus() {
  const [isOnline, setIsOnline] = useState(
    typeof navigator !== 'undefined' ? navigator.onLine : true
  );

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  return isOnline;
}
