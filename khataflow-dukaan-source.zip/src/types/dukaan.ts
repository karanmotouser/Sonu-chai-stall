import { Timestamp } from 'firebase/firestore';

export type Language = 'hi' | 'en';
export type ThemeMode = 'light' | 'dark';

export type NavSection =
  | 'dashboard'
  | 'billing'
  | 'products'
  | 'stock'
  | 'pricing'
  | 'purchase'
  | 'customers'
  | 'udhaar'
  | 'suppliers'
  | 'expenses'
  | 'cashbook'
  | 'returns'
  | 'reports'
  | 'settings';

export type ProductUnit =
  | 'Piece'
  | 'Kg'
  | 'Gram'
  | 'Litre'
  | 'ML'
  | 'Packet'
  | 'Box'
  | 'Dozen'
  | 'Bottle'
  | 'Bag';

export type PriceType = 'selling' | 'purchase' | 'mrp' | 'wholesale';
export type PaymentMode = 'cash' | 'upi' | 'card' | 'credit' | 'mixed';
export type PurchasePaymentMode = 'cash' | 'upi' | 'bank' | 'credit';
export type ExpenseCategory = 'electricity' | 'rent' | 'salary' | 'transport' | 'maintenance' | 'other';
export type ExpensePaymentMode = 'cash' | 'upi' | 'bank';

export interface ShopProfile {
  id: string;
  ownerId: string;
  shopName: string;
  ownerName: string;
  phone?: string;
  address?: string;
  gstin?: string;
  defaultGstRate: number;
  openingCashBalance: number;
  openingCashDate?: string;
  pinHash?: string;
  language: Language;
  lastBackupAt?: string;
  createdAt?: Timestamp;
  updatedAt?: Timestamp;
}

export interface Product {
  id: string;
  ownerId: string;
  name: string;
  category: string;
  barcode?: string;
  sku?: string;
  purchasePrice: number;
  sellingPrice: number;
  wholesalePrice?: number;
  mrp: number;
  stockQty: number;
  minStockAlert: number;
  damagedQty: number;
  unit: string;
  description?: string;
  photoUrl?: string;
  expiryDate?: string;
  gstRate: number;
  isActive: boolean;
  createdAt?: Timestamp;
  updatedAt?: Timestamp;
}

export interface PriceHistoryRecord {
  id: string;
  ownerId: string;
  productId: string;
  productName: string;
  priceType: PriceType;
  previousPrice: number;
  newPrice: number;
  changeReason: string;
  purchasePriceAtChange: number;
  sellingPriceAtChange: number;
  profitMarginPercent: number;
  batchId?: string;
  createdAt?: Timestamp;
}

export interface BillLineItem {
  productId: string;
  productName: string;
  unit: string;
  qty: number;
  unitPrice: number;
  purchasePriceAtSale: number;
  gstRate: number;
  gstAmount: number;
  lineTotal: number;
}

export interface Bill {
  id: string;
  ownerId: string;
  billNumber: string;
  customerId?: string;
  customerName: string;
  customerPhone?: string;
  items: BillLineItem[];
  subtotal: number;
  discountAmount: number;
  gstAmount: number;
  totalAmount: number;
  totalCost: number;
  grossProfit: number;
  paymentMode: PaymentMode;
  cashPaid: number;
  onlinePaid: number;
  cardPaid: number;
  creditAmount: number;
  paidAmount: number;
  status: 'completed' | 'edited' | 'cancelled';
  notes?: string;
  billDate: string; // YYYY-MM-DD
  createdAt?: Timestamp;
  updatedAt?: Timestamp;
}

export interface PurchaseLineItem {
  productId: string;
  productName: string;
  unit: string;
  qty: number;
  purchaseRate: number;
  lineTotal: number;
}

export interface Purchase {
  id: string;
  ownerId: string;
  purchaseNumber: string;
  supplierId: string;
  supplierName: string;
  items: PurchaseLineItem[];
  totalAmount: number;
  paidAmount: number;
  remainingAmount: number;
  paymentMode: PurchasePaymentMode;
  status: 'completed' | 'cancelled';
  purchaseDate: string; // YYYY-MM-DD
  notes?: string;
  createdAt?: Timestamp;
  updatedAt?: Timestamp;
}

export interface Customer {
  id: string;
  ownerId: string;
  name: string;
  phone: string;
  address?: string;
  totalUdhaar: number;
  amountReceived: number;
  remainingBalance: number;
  notes?: string;
  createdAt?: Timestamp;
  updatedAt?: Timestamp;
}

export interface UdhaarTransaction {
  id: string;
  ownerId: string;
  customerId: string;
  customerName: string;
  type: 'udhaar' | 'repayment' | 'bill_credit' | 'adjustment' | 'return_credit';
  amount: number;
  paymentMode: 'cash' | 'upi' | 'bank' | 'card' | 'credit';
  billId?: string;
  notes?: string;
  txDate: string;
  createdAt?: Timestamp;
}

export interface Supplier {
  id: string;
  ownerId: string;
  name: string;
  phone: string;
  address?: string;
  gstin?: string;
  totalPurchases: number;
  totalPaid: number;
  remainingOutstanding: number;
  notes?: string;
  createdAt?: Timestamp;
  updatedAt?: Timestamp;
}

export interface SupplierPayment {
  id: string;
  ownerId: string;
  supplierId: string;
  supplierName: string;
  purchaseId?: string;
  type: 'payment' | 'purchase_credit' | 'return_debit';
  amount: number;
  paymentMode: 'cash' | 'upi' | 'bank' | 'credit';
  notes?: string;
  paymentDate: string;
  createdAt?: Timestamp;
}

export interface Expense {
  id: string;
  ownerId: string;
  category: ExpenseCategory;
  title: string;
  amount: number;
  paymentMode: ExpensePaymentMode;
  expenseDate: string;
  notes?: string;
  createdAt?: Timestamp;
  updatedAt?: Timestamp;
}

export type StockMovementType =
  | 'sale'
  | 'purchase'
  | 'adjustment'
  | 'damage'
  | 'expiry'
  | 'customer_return'
  | 'supplier_return'
  | 'audit'
  | 'sale_cancel'
  | 'purchase_cancel';

export interface StockMovement {
  id: string;
  ownerId: string;
  productId: string;
  productName: string;
  type: StockMovementType;
  qtyChange: number;
  stockBefore: number;
  stockAfter: number;
  unitCost: number;
  referenceId?: string;
  reason: string;
  movementDate: string;
  createdAt?: Timestamp;
}

export interface ReturnLineItem {
  productId: string;
  productName: string;
  unit: string;
  qty: number;
  unitPrice: number;
  lineTotal: number;
}

export interface ReturnRecord {
  id: string;
  ownerId: string;
  returnType: 'customer_return' | 'supplier_return';
  referenceId?: string;
  referenceNumber?: string;
  partyId?: string;
  partyName: string;
  items: ReturnLineItem[];
  totalAmount: number;
  refundMode: 'cash' | 'upi' | 'credit_adjust' | 'none';
  stockCondition: 'restock' | 'damaged';
  notes?: string;
  returnDate: string;
  createdAt?: Timestamp;
}

export interface CashbookEntry {
  id: string;
  ownerId: string;
  entryDate: string;
  direction: 'in' | 'out';
  category:
    | 'sale'
    | 'purchase'
    | 'udhaar_repayment'
    | 'supplier_payment'
    | 'expense'
    | 'refund'
    | 'opening_adjust'
    | 'manual';
  paymentMode: 'cash' | 'upi' | 'bank' | 'card';
  amount: number;
  referenceId?: string;
  description: string;
  createdAt?: Timestamp;
}

export interface AuditLog {
  id: string;
  ownerId: string;
  action: string;
  entityType: string;
  entityId: string;
  summary: string;
  createdAt?: Timestamp;
}
