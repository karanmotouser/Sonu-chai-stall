import React, { useState } from 'react';
import {
  ArrowLeftRight,
  BarChart3,
  BookOpen,
  Boxes,
  IndianRupee,
  LayoutDashboard,
  Lock,
  Menu,
  Moon,
  Package,
  Receipt,
  Settings,
  ShoppingBag,
  Sun,
  TrendingUp,
  Truck,
  Users,
  Wallet,
  X,
} from 'lucide-react';
import { useDukaan } from '../context/DukaanContext';
import { NAV_ITEMS, t } from '../lib/i18n';
import { NavSection } from '../types/dukaan';
import { OfflineIndicator, PWAInstallButton } from './PWAInstallBanner';

const SECTION_ICONS: Record<NavSection, React.ComponentType<{ className?: string }>> = {
  dashboard: LayoutDashboard,
  billing: Receipt,
  products: Package,
  stock: Boxes,
  pricing: TrendingUp,
  purchase: ShoppingBag,
  customers: Users,
  udhaar: IndianRupee,
  suppliers: Truck,
  expenses: Wallet,
  cashbook: BookOpen,
  returns: ArrowLeftRight,
  reports: BarChart3,
  settings: Settings,
};

const MOBILE_PRIMARY: NavSection[] = ['dashboard', 'billing', 'products', 'udhaar'];

export const LayoutShell: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const {
    shopProfile,
    lang,
    setLang,
    theme,
    toggleTheme,
    activeSection,
    setActiveSection,
    toasts,
    dismissToast,
    lockApp,
    setEditingBillId,
  } = useDukaan();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [logoFailed, setLogoFailed] = useState(false);
  const labels = t(lang);

  const activeItem = NAV_ITEMS.find((n) => n.id === activeSection) || NAV_ITEMS[0];

  const handleNavigate = (sec: NavSection) => {
    if (sec !== 'billing') setEditingBillId(null);
    setActiveSection(sec);
    setMobileMenuOpen(false);
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex">
      {/* Desktop Sidebar (256px) */}
      <aside className="hidden lg:flex lg:flex-col lg:w-64 lg:fixed lg:inset-y-0 bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 z-30">
        <div className="h-16 px-4 flex items-center gap-3 border-b border-slate-200 dark:border-slate-800 shrink-0">
          {!logoFailed ? (
            <img
              src="/src/assets/images/dukaan_brand_emblem_1795069501237.jpg"
              alt="Shop emblem"
              referrerPolicy="no-referrer"
              onError={() => setLogoFailed(true)}
              className="w-9 h-9 rounded-lg object-cover border border-slate-200 dark:border-slate-700 shrink-0"
            />
          ) : (
            <div className="w-9 h-9 rounded-lg bg-emerald-700 text-white flex items-center justify-center font-bold shrink-0">
              ₹
            </div>
          )}
          <div className="min-w-0">
            <p className="text-sm font-bold truncate text-slate-900 dark:text-slate-100">
              {shopProfile?.shopName || labels.appTitle}
            </p>
            <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
              {shopProfile?.ownerName || labels.appSubtitle}
            </p>
          </div>
        </div>

        <nav className="flex-1 overflow-y-auto p-3 space-y-1">
          {NAV_ITEMS.map((item) => {
            const Icon = SECTION_ICONS[item.id];
            const isActive = activeSection === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => handleNavigate(item.id)}
                className={`w-full flex items-center gap-3 px-3 h-10 rounded-xl text-sm font-medium transition-colors cursor-pointer ${
                  isActive
                    ? 'bg-emerald-700 text-white'
                    : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                <Icon className="w-4 h-4 shrink-0" />
                <span className="truncate">{item[lang]}</span>
              </button>
            );
          })}
        </nav>

        <div className="p-3 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between gap-2 shrink-0">
          <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-lg">
            <button
              type="button"
              onClick={() => setLang('hi')}
              className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                lang === 'hi'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-sm'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              हिंदी
            </button>
            <button
              type="button"
              onClick={() => setLang('en')}
              className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                lang === 'en'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-sm'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              EN
            </button>
          </div>

          <div className="flex items-center gap-1">
            {shopProfile?.pinHash && (
              <button
                type="button"
                onClick={lockApp}
                title={lang === 'hi' ? 'पिन लॉक करें' : 'Lock App'}
                className="w-9 h-9 rounded-lg flex items-center justify-center text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
              >
                <Lock className="w-4 h-4" />
              </button>
            )}
            <button
              type="button"
              onClick={toggleTheme}
              aria-label="Toggle theme"
              className="w-9 h-9 rounded-lg flex items-center justify-center text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
            >
              {theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>
          </div>
        </div>
      </aside>

      {/* Main Viewport */}
      <div className="flex-1 lg:pl-64 flex flex-col min-w-0">
        {/* Sticky Top Header (Mobile <= 52px + Desktop 64px) */}
        <header className="sticky top-0 z-20 h-13 lg:h-16 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 px-4 lg:px-8 flex items-center justify-between gap-4 no-print">
          <div className="flex items-center gap-3 min-w-0">
            <h1 className="text-base lg:text-lg font-bold text-slate-900 dark:text-slate-100 truncate">
              {activeItem[lang]}
            </h1>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <PWAInstallButton compact />
            <button
              type="button"
              onClick={toggleTheme}
              aria-label="Toggle theme"
              className="lg:hidden w-10 h-10 rounded-xl flex items-center justify-center text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
            >
              {theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>
            <button
              type="button"
              onClick={() => setLang(lang === 'hi' ? 'en' : 'hi')}
              className="lg:hidden px-2.5 h-9 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 cursor-pointer whitespace-nowrap"
            >
              {lang === 'hi' ? 'EN' : 'हिंदी'}
            </button>
            <button
              type="button"
              onClick={() => handleNavigate('billing')}
              className="inline-flex items-center gap-1.5 px-3.5 lg:px-4 h-9 lg:h-10 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs lg:text-sm font-semibold transition-colors cursor-pointer whitespace-nowrap shrink-0"
            >
              <Receipt className="w-4 h-4" />
              <span>{lang === 'hi' ? 'नया बिल' : 'New Bill'}</span>
            </button>
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 p-4 lg:p-8 pb-24 lg:pb-10 max-w-7xl w-full mx-auto">
          {children}
        </main>
      </div>

      {/* Mobile Fixed Bottom Tab Bar */}
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-30 h-16 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 grid grid-cols-5 items-center no-print">
        {MOBILE_PRIMARY.map((secId) => {
          const item = NAV_ITEMS.find((n) => n.id === secId)!;
          const Icon = SECTION_ICONS[secId];
          const isActive = activeSection === secId;
          return (
            <button
              key={secId}
              type="button"
              onClick={() => handleNavigate(secId)}
              className={`flex flex-col items-center justify-center h-full min-h-[44px] gap-0.5 cursor-pointer ${
                isActive ? 'text-emerald-700 dark:text-emerald-400' : 'text-slate-500 dark:text-slate-400'
              }`}
            >
              <Icon className="w-5 h-5" />
              <span className="text-[10px] font-semibold truncate max-w-[64px]">
                {item[lang]}
              </span>
            </button>
          );
        })}
        <button
          type="button"
          onClick={() => setMobileMenuOpen(true)}
          className={`flex flex-col items-center justify-center h-full min-h-[44px] gap-0.5 cursor-pointer ${
            !MOBILE_PRIMARY.includes(activeSection)
              ? 'text-emerald-700 dark:text-emerald-400'
              : 'text-slate-500 dark:text-slate-400'
          }`}
        >
          <Menu className="w-5 h-5" />
          <span className="text-[10px] font-semibold">{labels.moreMenu}</span>
        </button>
      </nav>

      {/* Mobile All-14-Modules Bottom Sheet */}
      {mobileMenuOpen && (
        <div className="lg:hidden fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-end no-print">
          <div className="w-full bg-white dark:bg-slate-900 rounded-t-3xl border-t border-slate-200 dark:border-slate-800 max-h-[82vh] flex flex-col">
            <div className="w-10 h-1.5 bg-slate-300 dark:bg-slate-700 rounded-full mx-auto mt-3" />
            <div className="flex items-center justify-between px-5 py-3 border-b border-slate-200 dark:border-slate-800">
              <span className="font-bold text-slate-900 dark:text-slate-100">
                {shopProfile?.shopName || labels.moreMenu}
              </span>
              <button
                type="button"
                onClick={() => setMobileMenuOpen(false)}
                className="w-10 h-10 rounded-xl flex items-center justify-center text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="overflow-y-auto p-4 grid grid-cols-2 gap-2.5">
              {NAV_ITEMS.map((item) => {
                const Icon = SECTION_ICONS[item.id];
                const isActive = activeSection === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => handleNavigate(item.id)}
                    className={`flex items-center gap-2.5 p-3 min-h-[48px] rounded-xl border text-left text-sm font-medium transition-colors cursor-pointer ${
                      isActive
                        ? 'bg-emerald-700 border-emerald-700 text-white'
                        : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-200'
                    }`}
                  >
                    <Icon className="w-4 h-4 shrink-0" />
                    <span className="truncate">{item[lang]}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Toast Stack */}
      <div className="fixed bottom-20 lg:bottom-6 right-4 z-50 flex flex-col gap-2 max-w-sm w-[calc(100%-2rem)] pointer-events-none no-print">
        {toasts.map((toast) => (
          <div
            key={toast.id}
            className={`pointer-events-auto flex items-center justify-between gap-3 px-4 py-3 rounded-xl border text-sm font-medium shadow-lg ${
              toast.type === 'error'
                ? 'bg-red-50 dark:bg-red-950 border-red-200 dark:border-red-800 text-red-800 dark:text-red-200'
                : toast.type === 'info'
                  ? 'bg-slate-900 dark:bg-slate-800 border-slate-700 text-white'
                  : 'bg-emerald-50 dark:bg-emerald-950 border-emerald-200 dark:border-emerald-800 text-emerald-900 dark:text-emerald-100'
            }`}
          >
            <span>{toast.text}</span>
            <button
              type="button"
              onClick={() => dismissToast(toast.id)}
              className="text-xs opacity-70 hover:opacity-100 cursor-pointer"
            >
              ✕
            </button>
          </div>
        ))}
      </div>

      <OfflineIndicator />
    </div>
  );
};
