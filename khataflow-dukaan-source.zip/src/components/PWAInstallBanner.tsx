import React, { useState } from 'react';
import {
  Check,
  CheckCircle2,
  Copy,
  Database,
  Download,
  FileArchive,
  GitBranch,
  Smartphone,
  WifiOff,
  X,
} from 'lucide-react';
import { useDukaan } from '../context/DukaanContext';
import {
  downloadSourceZipWithProgress,
  getSourceZipDirectUrl,
  SOURCE_ZIP_PATH,
  useOnlineStatus,
  usePWAInstall,
  useSourceZipInfo,
} from '../hooks/usePWAInstall';
import { exportShopBackup } from '../services/dukaanService';

export const PWAInstallButton: React.FC<{ compact?: boolean }> = ({ compact = false }) => {
  const { lang, notify } = useDukaan();
  const { isNative, isInstallable, isInstalled, isIOS, isInIframe, install } = usePWAInstall();
  const [showGuide, setShowGuide] = useState(false);

  if (isNative || isInstalled) {
    return null;
  }

  const handleInstallClick = async () => {
    if (isInstallable) {
      const accepted = await install();
      if (accepted) {
        notify(
          lang === 'hi'
            ? 'ऐप फ़ोन के होम स्क्रीन पर इंस्टॉल हो गया!'
            : 'App installed on your home screen!'
        );
      }
      return;
    }
    setShowGuide(true);
  };

  return (
    <>
      <button
        type="button"
        onClick={handleInstallClick}
        className={`inline-flex items-center gap-1.5 rounded-xl font-semibold transition-colors cursor-pointer shrink-0 whitespace-nowrap ${
          isInstallable
            ? 'bg-amber-600 hover:bg-amber-700 text-white shadow-sm'
            : compact
              ? 'border border-emerald-600/40 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-200 hover:bg-emerald-100'
              : 'bg-emerald-700 hover:bg-emerald-800 text-white shadow-sm'
        } ${compact ? 'px-2.5 h-9 text-xs' : 'px-4 h-10 text-xs lg:text-sm'}`}
      >
        <Download className="w-4 h-4 shrink-0" />
        <span>
          {compact
            ? lang === 'hi'
              ? 'APK / इंस्टॉल'
              : 'APK / Install'
            : lang === 'hi'
              ? 'Android APK / ऐप इंस्टॉल'
              : 'Android APK / Install'}
        </span>
      </button>

      {showGuide && (
        <AndroidApkGuideModal
          lang={lang}
          isIOS={isIOS}
          isInIframe={isInIframe}
          onClose={() => setShowGuide(false)}
        />
      )}
    </>
  );
};

export const DashboardInstallCard: React.FC = () => {
  const { user, lang, notify, isLocalMode, setActiveSection } = useDukaan();
  const { isNative, isInstallable, isInstalled, isIOS, isInIframe, install } = usePWAInstall();
  const zipInfo = useSourceZipInfo();
  const [showGuide, setShowGuide] = useState(false);
  const [downloadingZip, setDownloadingZip] = useState(false);
  const [progressText, setProgressText] = useState('');
  const [downloadingData, setDownloadingData] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  const directZipUrl = getSourceZipDirectUrl();

  const handleDownloadFullZip = async () => {
    if (downloadingZip) return;
    setDownloadingZip(true);
    setProgressText('0.0 MB');
    try {
      const bytes = await downloadSourceZipWithProgress((loadedMB, totalMB, pct) => {
        setProgressText(`${loadedMB} / ${totalMB} MB (${pct}%)`);
      });
      const mb = (bytes / (1024 * 1024)).toFixed(1);
      notify(
        lang === 'hi'
          ? `पूरा प्रोजेक्ट ZIP (${mb} MB) डाउनलोड हो गया!`
          : `Full Source & Android ZIP (${mb} MB) downloaded!`
      );
    } catch (err) {
      notify(
        err instanceof Error
          ? err.message
          : lang === 'hi'
            ? 'ZIP डाउनलोड में समस्या आई, डायरेक्ट लिंक से प्रयास करें।'
            : 'ZIP download failed.',
        'error'
      );
    } finally {
      setDownloadingZip(false);
      setProgressText('');
    }
  };

  const handleDownloadShopData = async () => {
    if (!user || downloadingData) return;
    setDownloadingData(true);
    try {
      const data = await exportShopBackup(user.uid);
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `khataflow_dukaan_data_${new Date().toISOString().slice(0, 10)}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(() => URL.revokeObjectURL(url), 5000);
      notify(
        lang === 'hi'
          ? 'दुकान का पूरा डेटा बैकअप (JSON) डाउनलोड हो गया!'
          : 'Complete shop data backup downloaded!'
      );
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Backup export failed', 'error');
    } finally {
      setDownloadingData(false);
    }
  };

  const handleCopyZipLink = async () => {
    try {
      await navigator.clipboard.writeText(directZipUrl);
      setCopiedLink(true);
      notify(lang === 'hi' ? 'ZIP डाउनलोड लिंक कॉपी हो गया!' : 'Download link copied!');
      setTimeout(() => setCopiedLink(false), 2000);
    } catch {
      notify(directZipUrl, 'info');
    }
  };

  const handleInstallAction = async () => {
    if (isInstallable) {
      const ok = await install();
      if (ok) {
        notify(
          lang === 'hi'
            ? 'KhataFlow Dukaan आपके फ़ोन में इंस्टॉल हो गया!'
            : 'KhataFlow Dukaan installed to your home screen!'
        );
      }
      return;
    }
    setShowGuide(true);
  };

  return (
    <section className="bg-gradient-to-r from-emerald-800 via-emerald-700 to-teal-700 text-white rounded-2xl p-4 sm:p-5 shadow-sm border border-emerald-600/30">
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
        <div className="flex items-start gap-3.5 min-w-0">
          <div className="w-11 h-11 rounded-xl bg-white/15 border border-white/25 flex items-center justify-center shrink-0">
            <Smartphone className="w-6 h-6 text-white" />
          </div>
          <div className="min-w-0 space-y-1">
            <div className="flex flex-wrap items-center gap-2">
              <h2 className="text-sm sm:text-base font-bold">
                {isNative
                  ? lang === 'hi'
                    ? 'KhataFlow Dukaan Android ऐप सक्रिय है'
                    : 'KhataFlow Dukaan Android App Active'
                  : lang === 'hi'
                    ? `KhataFlow Dukaan पूरा पैकेज डाउनलोड (${zipInfo.sizeMB} MB)`
                    : `Download Full KhataFlow Dukaan Package (${zipInfo.sizeMB} MB)`}
              </h2>
              {(isNative || isLocalMode) && (
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-white/20 text-[11px] font-semibold">
                  <Database className="w-3.5 h-3.5" />
                  {lang === 'hi' ? 'लोकल डेटाबेस सुरक्षित' : 'Local Offline DB'}
                </span>
              )}
              {isInstalled && !isNative && (
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-white/20 text-[11px] font-semibold">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  {lang === 'hi' ? 'इंस्टॉल हो चुका है' : 'Installed'}
                </span>
              )}
            </div>
            <p className="text-xs text-emerald-50/90 leading-relaxed">
              {isNative
                ? lang === 'hi'
                  ? 'सारा दुकान डेटा (उत्पाद, बिल, उधार, सप्लायर और खर्च) सीधे फ़ोन की लोकल मेमोरी में सुरक्षित है — बिना इंटरनेट भी पूरी तरह चलता है।'
                  : 'All shop data is saved locally on your phone and works smoothly offline.'
                : lang === 'hi'
                  ? `इसमें पूरा सोर्स कोड + Android Capacitor प्रोजेक्ट + GitHub Actions APK बिल्ड (${zipInfo.fileCount} फ़ाइलें, ${zipInfo.sizeMB} MB) शामिल है। साथ ही नीचे से अपनी दुकान का पूरा डेटा बैकअप भी डाउनलोड कर सकते हैं।`
                  : `Includes full React source, Capacitor Android project & GitHub Actions APK builder (${zipInfo.fileCount} files, ${zipInfo.sizeMB} MB).`}
            </p>
          </div>
        </div>

        {!isNative && (
          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            <button
              type="button"
              onClick={handleDownloadFullZip}
              disabled={downloadingZip}
              className="inline-flex items-center gap-2 px-4 h-11 rounded-xl bg-amber-500 hover:bg-amber-400 disabled:opacity-75 text-slate-950 font-bold text-xs sm:text-sm shadow-md transition-colors cursor-pointer whitespace-nowrap"
            >
              <FileArchive className="w-4 h-4 shrink-0" />
              <span>
                {downloadingZip
                  ? `${lang === 'hi' ? 'डाउनलोड हो रहा है' : 'Downloading'} ${progressText}`
                  : lang === 'hi'
                    ? `पूरा प्रोजेक्ट ZIP (${zipInfo.sizeMB} MB)`
                    : `Download Full ZIP (${zipInfo.sizeMB} MB)`}
              </span>
            </button>

            <button
              type="button"
              onClick={handleDownloadShopData}
              disabled={downloadingData}
              className="inline-flex items-center gap-1.5 px-3.5 h-11 rounded-xl bg-white text-emerald-900 hover:bg-emerald-50 font-bold text-xs transition-colors cursor-pointer whitespace-nowrap"
            >
              <Database className="w-4 h-4 shrink-0" />
              <span>{lang === 'hi' ? 'दुकान डेटा बैकअप' : 'Shop Data Backup'}</span>
            </button>

            <button
              type="button"
              onClick={handleInstallAction}
              className="inline-flex items-center gap-1.5 px-3.5 h-11 rounded-xl bg-white/15 hover:bg-white/25 border border-white/25 text-white text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap"
            >
              <GitBranch className="w-4 h-4" />
              <span>
                {isInstallable
                  ? lang === 'hi'
                    ? 'अभी इंस्टॉल करें'
                    : 'Install App'
                  : lang === 'hi'
                    ? 'APK बनाने का तरीका'
                    : 'APK Build Guide'}
              </span>
            </button>
          </div>
        )}

        {isNative && (
          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={handleDownloadShopData}
              disabled={downloadingData}
              className="inline-flex items-center gap-1.5 px-3.5 h-10 rounded-xl bg-white text-emerald-900 hover:bg-emerald-50 text-xs font-bold transition-colors cursor-pointer whitespace-nowrap"
            >
              <Download className="w-4 h-4" />
              <span>{lang === 'hi' ? 'डेटा बैकअप डाउनलोड' : 'Export Data'}</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveSection('settings')}
              className="inline-flex items-center gap-1.5 px-3.5 h-10 rounded-xl bg-white/15 hover:bg-white/25 border border-white/25 text-white text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap"
            >
              <span>{lang === 'hi' ? 'सेटिंग्स' : 'Settings'}</span>
            </button>
          </div>
        )}
      </div>

      {/* Direct Full File URL Strip (Web Only) */}
      {!isNative && (
        <div className="mt-3.5 pt-3 border-t border-white/15 flex flex-wrap items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-2 min-w-0 flex-1">
            <span className="text-emerald-100/80 font-medium shrink-0">
              {lang === 'hi' ? 'डायरेक्ट ZIP लिंक:' : 'Direct ZIP Link:'}
            </span>
            <a
              href={SOURCE_ZIP_PATH}
              download="khataflow-dukaan-source.zip"
              className="font-mono text-[11px] sm:text-xs text-white underline underline-offset-2 truncate hover:text-amber-200"
            >
              {directZipUrl}
            </a>
          </div>
          <button
            type="button"
            onClick={handleCopyZipLink}
            className="inline-flex items-center gap-1 px-2.5 h-7 rounded-lg bg-white/15 hover:bg-white/25 text-white text-[11px] font-semibold cursor-pointer shrink-0"
          >
            {copiedLink ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
            {copiedLink ? (lang === 'hi' ? 'कॉपी हुआ' : 'Copied') : lang === 'hi' ? 'लिंक कॉपी' : 'Copy Link'}
          </button>
        </div>
      )}

      {showGuide && (
        <AndroidApkGuideModal
          lang={lang}
          isIOS={isIOS}
          isInIframe={isInIframe}
          onClose={() => setShowGuide(false)}
        />
      )}
    </section>
  );
};

const AndroidApkGuideModal: React.FC<{
  lang: 'hi' | 'en';
  isIOS: boolean;
  isInIframe: boolean;
  onClose: () => void;
}> = ({ lang, isIOS, onClose }) => {
  const { notify } = useDukaan();
  const zipInfo = useSourceZipInfo();
  const [busy, setBusy] = useState(false);
  const [progress, setProgress] = useState('');

  const handleModalDownload = async () => {
    if (busy) return;
    setBusy(true);
    try {
      const bytes = await downloadSourceZipWithProgress((loaded, total, pct) => {
        setProgress(`${loaded}/${total} MB (${pct}%)`);
      });
      notify(
        lang === 'hi'
          ? `पूरा प्रोजेक्ट ZIP (${(bytes / (1024 * 1024)).toFixed(1)} MB) डाउनलोड हो गया!`
          : 'Full project ZIP downloaded!'
      );
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Download failed', 'error');
    } finally {
      setBusy(false);
      setProgress('');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 text-slate-900 dark:text-slate-100">
      <div className="w-full max-w-lg rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between">
          <h3 className="text-base font-bold">
            {lang === 'hi'
              ? 'फ़ोन से Android APK डाउनलोड और इंस्टॉल करने की विधि'
              : 'Build & Install Android APK Without a Computer'}
          </h3>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-lg flex items-center justify-center hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {isIOS ? (
          <ol className="text-sm text-slate-600 dark:text-slate-300 space-y-2 list-decimal pl-5">
            <li>
              {lang === 'hi'
                ? 'iPhone/iPad पर Safari में Share बटन दबाकर "Add to Home Screen" चुनें।'
                : 'On iPhone/iPad, tap Share in Safari and choose "Add to Home Screen".'}
            </li>
          </ol>
        ) : (
          <ol className="text-sm text-slate-600 dark:text-slate-300 space-y-2.5 list-decimal pl-5 leading-relaxed">
            <li>
              {lang === 'hi'
                ? `नीचे "पूरा ZIP डाउनलोड करें (${zipInfo.sizeMB} MB)" बटन दबाएं — पूरा Capacitor Android प्रोजेक्ट डाउनलोड होकर फ़ोन में सेव होगा, फिर उसे Extract (Unzip) करें।`
                : `Download the complete Capacitor Android Source ZIP (${zipInfo.sizeMB} MB) below and extract it.`}
            </li>
            <li>
              {lang === 'hi'
                ? 'अपने फ़ोन के ब्राउज़र में GitHub.com खोलें, एक नया Repository बनाएं और निकाली गई सभी फ़ाइलें (android/, src/, public/, .github/workflows/build-android-apk.yml सहित) अपलोड करके Commit करें।'
                : 'Open GitHub.com in your phone browser, create a repository, and upload all files including .github/workflows/build-android-apk.yml.'}
            </li>
            <li>
              {lang === 'hi'
                ? 'GitHub Repository के "Actions" टैब में जाएं — "Build KhataFlow Dukaan Android APK" अपने-आप चलेगा (या "Run workflow" दबाएं)।'
                : 'Open the "Actions" tab in your GitHub repository — "Build KhataFlow Dukaan Android APK" runs automatically.'}
            </li>
            <li>
              {lang === 'hi'
                ? 'लगभग 3-5 मिनट बाद सबसे नीचे "Artifacts" सेक्शन में "KhataFlow-Dukaan-APK" पर टैप करके डाउनलोड करें, ZIP खोलें और .apk फ़ाइल फ़ोन में इंस्टॉल करें!'
                : 'In 3-5 minutes, tap "KhataFlow-Dukaan-APK" under Artifacts, unzip it, and install the .apk file on your Android phone.'}
            </li>
          </ol>
        )}

        <div className="p-3.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-900 flex flex-wrap items-center justify-between gap-3">
          <div className="text-xs text-emerald-900 dark:text-emerald-200">
            <p className="font-bold">
              {lang === 'hi'
                ? `पूर्ण Capacitor Android प्रोजेक्ट (${zipInfo.sizeMB} MB)`
                : `Complete Capacitor Android Project (${zipInfo.sizeMB} MB)`}
            </p>
            <p className="opacity-80">
              {lang === 'hi'
                ? `${zipInfo.fileCount} फ़ाइलें — android/, .github/workflows/ और हिंदी गाइड सहित`
                : `${zipInfo.fileCount} files — includes android/, GitHub workflow & Hindi guide`}
            </p>
          </div>
          <button
            type="button"
            onClick={handleModalDownload}
            disabled={busy}
            className="inline-flex items-center gap-1.5 px-3.5 h-10 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold shrink-0 cursor-pointer"
          >
            <FileArchive className="w-4 h-4" />
            {busy ? progress : lang === 'hi' ? `पूरा ZIP डाउनलोड (${zipInfo.sizeMB} MB)` : 'Download Full ZIP'}
          </button>
        </div>

        <button
          type="button"
          onClick={onClose}
          className="w-full h-10 rounded-xl bg-slate-900 dark:bg-slate-800 text-white text-sm font-semibold cursor-pointer"
        >
          {lang === 'hi' ? 'बंद करें' : 'Close'}
        </button>
      </div>
    </div>
  );
};

export const OfflineIndicator: React.FC = () => {
  const { lang } = useDukaan();
  const isOnline = useOnlineStatus();

  if (isOnline) return null;

  return (
    <div className="fixed bottom-20 lg:bottom-4 left-4 z-50 flex items-center gap-2 rounded-xl bg-amber-600 px-3.5 py-2 text-xs font-semibold text-white shadow-lg no-print">
      <WifiOff className="w-3.5 h-3.5 shrink-0" />
      <span>
        {lang === 'hi'
          ? 'ऑफ़लाइन मोड — सारा डेटा डिवाइस में सुरक्षित है'
          : 'Offline Mode — All data saved locally on device'}
      </span>
    </div>
  );
};
