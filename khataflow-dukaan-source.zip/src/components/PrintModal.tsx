import React from 'react';
import { Printer, X } from 'lucide-react';
import { useDukaan } from '../context/DukaanContext';
import { t } from '../lib/i18n';

export const PrintModal: React.FC = () => {
  const { printPayload, closePrintModal, lang } = useDukaan();
  const labels = t(lang);

  if (!printPayload) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-3xl w-full max-h-[90vh] flex flex-col overflow-hidden">
        <div className="flex items-center justify-between gap-4 px-5 py-3.5 border-b border-slate-200 dark:border-slate-800 no-print">
          <h3 className="font-bold text-slate-900 dark:text-slate-100 truncate">
            {printPayload.title}
          </h3>
          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => window.print()}
              className="inline-flex items-center gap-2 px-4 h-10 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-sm font-semibold transition-colors cursor-pointer whitespace-nowrap"
            >
              <Printer className="w-4 h-4" />
              {labels.printPdf}
            </button>
            <button
              type="button"
              onClick={closePrintModal}
              aria-label={labels.close}
              className="w-10 h-10 rounded-xl border border-slate-200 dark:border-slate-700 flex items-center justify-center text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div className="overflow-y-auto p-4 md:p-6 bg-slate-100 dark:bg-slate-950">
          <div
            id="print-section"
            className="bg-white text-slate-900 p-6 rounded-xl border border-slate-200 mx-auto max-w-2xl"
          >
            {printPayload.content}
          </div>
        </div>
      </div>
    </div>
  );
};
