import { Capacitor } from '@capacitor/core';
import React, { useState } from 'react';
import { FileArchive, Lock, LogIn, ShieldCheck, Store } from 'lucide-react';
import { useDukaan } from '../context/DukaanContext';
import { downloadSourceZipWithProgress, useSourceZipInfo } from '../hooks/usePWAInstall';
import { hashPin } from '../lib/formatters';
import { t } from '../lib/i18n';
import { PWAInstallButton } from './PWAInstallBanner';

export const AuthGate: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const {
    user,
    authLoading,
    signIn,
    startLocalMode,
    lang,
    setLang,
    pinLocked,
    shopProfile,
    unlockWithPin,
    notify,
  } = useDukaan();

  const [pinInput, setPinInput] = useState('');
  const [pinError, setPinError] = useState('');
  const [heroImgFailed, setHeroImgFailed] = useState(false);
  const [logoImgFailed, setLogoImgFailed] = useState(false);
  const [downloadingZip, setDownloadingZip] = useState(false);
  const [zipProgress, setZipProgress] = useState('');
  const zipInfo = useSourceZipInfo();
  const isNative = Capacitor.isNativePlatform();
  const labels = t(lang);

  const handleAuthDownloadZip = async () => {
    if (downloadingZip) return;
    setDownloadingZip(true);
    try {
      const bytes = await downloadSourceZipWithProgress((loaded, total, pct) => {
        setZipProgress(`${loaded}/${total} MB (${pct}%)`);
      });
      notify(
        lang === 'hi'
          ? `पूरा प्रोजेक्ट ZIP (${(bytes / (1024 * 1024)).toFixed(1)} MB) डाउनलोड हो गया!`
          : 'Full project ZIP downloaded!'
      );
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Download failed', 'error');
    } finally {
      setDownloadingZip(false);
      setZipProgress('');
    }
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50 dark:bg-slate-950">
        <div className="text-center space-y-3">
          <div className="w-10 h-10 border-4 border-emerald-600 border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="text-sm font-medium text-slate-600 dark:text-slate-300">{labels.loading}</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex flex-col justify-center p-4 md:p-8">
        <div className="max-w-5xl w-full mx-auto bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl overflow-hidden grid grid-cols-1 lg:grid-cols-2 items-stretch">
          {/* Left Hero Visual */}
          <div className="relative min-h-[240px] lg:min-h-[540px] bg-emerald-950 overflow-hidden">
            {!heroImgFailed ? (
              <img
                src="/src/assets/images/shop_storefront_hero_1795069501253.jpg"
                alt="Modern Indian retail kirana shop"
                referrerPolicy="no-referrer"
                onError={() => setHeroImgFailed(true)}
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-emerald-900 to-slate-900 p-8">
                <Store className="w-24 h-24 text-emerald-300/70" />
              </div>
            )}
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/35 to-transparent flex flex-col justify-end p-6 md:p-8 text-white">
              <p className="text-xs font-medium text-emerald-300 tracking-wide">
                {lang === 'hi' ? 'भारतीय रिटेल व्यापार के लिए' : 'Built for Indian Retail Shops'}
              </p>
              <h2 className="text-2xl md:text-3xl font-bold mt-1 leading-tight">
                {lang === 'hi'
                  ? 'पीओएस बिलिंग, स्टॉक, उधार और शुद्ध मुनाफा — सब एक जगह'
                  : 'POS Billing, Stock, Udhaar & Net Profit — All in One'}
              </h2>
            </div>
          </div>

          {/* Right Login Card */}
          <div className="p-6 md:p-10 flex flex-col justify-between gap-8">
            <div className="flex items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                {!logoImgFailed ? (
                  <img
                    src="/src/assets/images/dukaan_brand_emblem_1795069501237.jpg"
                    alt="KhataFlow Dukaan"
                    referrerPolicy="no-referrer"
                    onError={() => setLogoImgFailed(true)}
                    className="w-11 h-11 rounded-xl object-cover border border-slate-200 dark:border-slate-700"
                  />
                ) : (
                  <div className="w-11 h-11 rounded-xl bg-emerald-700 flex items-center justify-center text-white font-bold">
                    ₹
                  </div>
                )}
                <div>
                  <h1 className="text-xl font-bold text-slate-900 dark:text-slate-100">
                    {labels.appTitle}
                  </h1>
                  <p className="text-xs text-slate-500 dark:text-slate-400">{labels.appSubtitle}</p>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <PWAInstallButton compact />
                <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-lg shrink-0">
                  <button
                    type="button"
                    onClick={() => setLang('hi')}
                    className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                      lang === 'hi'
                        ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-sm'
                        : 'text-slate-600 dark:text-slate-400'
                    }`}
                  >
                    हिंदी
                  </button>
                  <button
                    type="button"
                    onClick={() => setLang('en')}
                    className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                      lang === 'en'
                        ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-sm'
                        : 'text-slate-600 dark:text-slate-400'
                    }`}
                  >
                    EN
                  </button>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h2 className="text-2xl font-bold text-slate-900 dark:text-slate-100">
                {lang === 'hi' ? 'अपनी दुकान का डिजिटल हिसाब शुरू करें' : 'Start Your Digital Shop Ledger'}
              </h2>
              <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
                {labels.signInDesc}
              </p>

              <ul className="space-y-2.5 text-sm text-slate-700 dark:text-slate-300 pt-2">
                <li className="flex items-center gap-2.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>
                    {lang === 'hi'
                      ? 'स्मार्ट मूल्य इतिहास (पुराना रेट कभी नहीं मिटता)'
                      : 'Smart Price History (never overwrites old rates)'}
                  </span>
                </li>
                <li className="flex items-center gap-2.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>
                    {lang === 'hi'
                      ? 'GST बिलिंग, WhatsApp शेयर, और PDF/Excel रिपोर्ट्स'
                      : 'GST Billing, WhatsApp Share, PDF & Excel Reports'}
                  </span>
                </li>
                <li className="flex items-center gap-2.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>
                    {lang === 'hi'
                      ? 'ग्राहक उधार, सप्लायर बकाया और दैनिक रोकड़ बही'
                      : 'Customer Udhaar, Supplier Payables & Daily Cashbook'}
                  </span>
                </li>
              </ul>
            </div>

            <div className="space-y-2.5">
              <button
                type="button"
                onClick={startLocalMode}
                className="w-full h-12 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-semibold text-sm flex items-center justify-center gap-2.5 transition-colors cursor-pointer"
              >
                <Store className="w-4 h-4" />
                {lang === 'hi'
                  ? 'ऑफ़लाइन / डिवाइस में दुकान शुरू करें (Offline Mode)'
                  : 'Start Offline on This Device (Local DB)'}
              </button>
              <button
                type="button"
                onClick={signIn}
                className="w-full h-11 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-900 dark:text-slate-100 font-semibold text-sm flex items-center justify-center gap-2.5 transition-colors cursor-pointer"
              >
                <LogIn className="w-4 h-4" />
                {labels.signInWithGoogle}
              </button>
              {!isNative && (
                <button
                  type="button"
                  onClick={handleAuthDownloadZip}
                  disabled={downloadingZip}
                  className="w-full h-11 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-colors cursor-pointer"
                >
                  <FileArchive className="w-4 h-4 shrink-0" />
                  <span>
                    {downloadingZip
                      ? `${lang === 'hi' ? 'डाउनलोड हो रहा है' : 'Downloading'} ${zipProgress}`
                      : lang === 'hi'
                        ? `पूरा Android + सोर्स कोड ZIP डाउनलोड करें (${zipInfo.sizeMB} MB)`
                        : `Download Full Android + Source ZIP (${zipInfo.sizeMB} MB)`}
                  </span>
                </button>
              )}
              <p className="text-xs text-center text-slate-500 dark:text-slate-400 pt-1">
                {lang === 'hi'
                  ? 'ऑफ़लाइन मोड में सारा डेटा आपके फ़ोन/ब्राउज़र में सुरक्षित सहेजा जाता है और ऐप बंद करने पर भी नहीं मिटता।'
                  : 'Offline mode saves all shop records permanently on your device even without internet.'}
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (pinLocked && shopProfile?.pinHash) {
    const handleUnlock = async (e: React.FormEvent) => {
      e.preventDefault();
      const enteredHash = await hashPin(pinInput.trim());
      if (enteredHash === shopProfile.pinHash) {
        setPinInput('');
        setPinError('');
        unlockWithPin();
      } else {
        setPinError(labels.pinWrong);
      }
    };

    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50 dark:bg-slate-950 p-4">
        <form
          onSubmit={handleUnlock}
          className="max-w-sm w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-5"
        >
          <div className="text-center space-y-2">
            <div className="w-12 h-12 rounded-2xl bg-emerald-50 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 flex items-center justify-center mx-auto">
              <Lock className="w-6 h-6" />
            </div>
            <h2 className="text-lg font-bold text-slate-900 dark:text-slate-100">{shopProfile.shopName}</h2>
            <p className="text-sm text-slate-500 dark:text-slate-400">{labels.pinTitle}</p>
          </div>

          <input
            type="password"
            inputMode="numeric"
            maxLength={8}
            value={pinInput}
            onChange={(e) => {
              setPinInput(e.target.value);
              setPinError('');
            }}
            placeholder="••••"
            autoFocus
            className="w-full h-12 text-center text-2xl font-mono tracking-[0.4em] rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-600"
          />

          {pinError && <p className="text-xs text-center font-medium text-red-600 dark:text-red-400">{pinError}</p>}

          <button
            type="submit"
            className="w-full h-11 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-semibold text-sm transition-colors cursor-pointer"
          >
            {labels.pinUnlock}
          </button>
        </form>
      </div>
    );
  }

  return <>{children}</>;
};
