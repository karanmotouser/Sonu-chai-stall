import { Capacitor } from '@capacitor/core';
import { SplashScreen } from '@capacitor/splash-screen';
import { StatusBar, Style } from '@capacitor/status-bar';
import { createRoot } from 'react-dom/client';
import { registerSW } from 'virtual:pwa-register';
import App from './App.tsx';
import './index.css';

if (Capacitor.isNativePlatform()) {
  void StatusBar.setOverlaysWebView({ overlay: false }).catch(() => {});
  void StatusBar.setBackgroundColor({ color: '#047857' }).catch(() => {});
  void StatusBar.setStyle({ style: Style.Dark }).catch(() => {});
  void SplashScreen.hide().catch(() => {});
} else {
  registerSW({ immediate: true });
}

createRoot(document.getElementById('root')!).render(<App />);
