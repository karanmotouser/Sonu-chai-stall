import React, { useMemo, useState } from 'react';
import { Edit3, ImagePlus, Package, Plus, Search, Trash2, X } from 'lucide-react';
import { useDukaan } from '../context/DukaanContext';
import { calculateProfitMargin, compressImageFile, formatINR } from '../lib/formatters';
import { PRODUCT_UNITS, t } from '../lib/i18n';
import { deleteProduct, saveProduct } from '../services/dukaanService';
import { Product } from '../types/dukaan';

const emptyForm = {
  id: '',
  name: '',
  category: 'Kirana',
  barcode: '',
  sku: '',
  purchasePrice: 0,
  sellingPrice: 0,
  wholesalePrice: 0,
  mrp: 0,
  stockQty: 0,
  minStockAlert: 5,
  unit: 'Piece',
  description: '',
  photoUrl: '',
  expiryDate: '',
  gstRate: 0,
};

export const ProductsPage: React.FC = () => {
  const { user, shopProfile, lang, products, notify } = useDukaan();
  const labels = t(lang);

  const [search, setSearch] = useState('');
  const [catFilter, setCatFilter] = useState('all');
  const [modalOpen, setModalOpen] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);

  const categories = useMemo(() => {
    const set = new Set(products.map((p) => p.category).filter(Boolean));
    return ['all', ...Array.from(set)];
  }, [products]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return products.filter((p) => {
      const matchCat = catFilter === 'all' || p.category === catFilter;
      const matchQ =
        !q ||
        p.name.toLowerCase().includes(q) ||
        (p.barcode || '').toLowerCase().includes(q) ||
        (p.sku || '').toLowerCase().includes(q) ||
        p.category.toLowerCase().includes(q);
      return matchCat && matchQ;
    });
  }, [products, search, catFilter]);

  const openAdd = () => {
    setForm({ ...emptyForm, gstRate: shopProfile?.defaultGstRate || 0 });
    setModalOpen(true);
  };

  const openEdit = (p: Product) => {
    setForm({
      id: p.id,
      name: p.name,
      category: p.category,
      barcode: p.barcode || '',
      sku: p.sku || '',
      purchasePrice: p.purchasePrice,
      sellingPrice: p.sellingPrice,
      wholesalePrice: p.wholesalePrice ?? p.sellingPrice,
      mrp: p.mrp,
      stockQty: p.stockQty,
      minStockAlert: p.minStockAlert,
      unit: p.unit,
      description: p.description || '',
      photoUrl: p.photoUrl || '',
      expiryDate: p.expiryDate || '',
      gstRate: p.gstRate,
    });
    setModalOpen(true);
  };

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const compressed = await compressImageFile(file);
      setForm((prev) => ({ ...prev, photoUrl: compressed }));
    } catch {
      notify(lang === 'hi' ? 'फोटो अपलोड विफल रहा।' : 'Photo upload failed.', 'error');
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || saving) return;
    if (!form.name.trim()) {
      notify(lang === 'hi' ? 'उत्पाद का नाम लिखें।' : 'Product name is required.', 'error');
      return;
    }
    setSaving(true);
    try {
      await saveProduct(user.uid, {
        ...form,
        id: form.id || undefined,
      });
      notify(
        form.id
          ? lang === 'hi'
            ? 'उत्पाद अपडेट हो गया!'
            : 'Product updated!'
          : lang === 'hi'
            ? 'नया उत्पाद जुड़ गया!'
            : 'Product added!'
      );
      setModalOpen(false);
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Save failed', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (p: Product) => {
    if (!user) return;
    try {
      await deleteProduct(user.uid, p.id, p.name);
      notify(lang === 'hi' ? 'उत्पाद हटाया गया।' : 'Product deleted.');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Delete failed', 'error');
    }
  };

  return (
    <div className="space-y-5">
      {/* Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-2.5 flex-1 min-w-[240px]">
          <div className="relative flex-1 min-w-[200px] max-w-md">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder={
                lang === 'hi' ? 'नाम, बारकोड, SKU या श्रेणी से खोजें...' : 'Search by name, barcode, SKU...'
              }
              className="w-full h-11 pl-10 pr-4 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm"
            />
          </div>
          <select
            value={catFilter}
            onChange={(e) => setCatFilter(e.target.value)}
            className="h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm"
          >
            {categories.map((c) => (
              <option key={c} value={c}>
                {c === 'all' ? (lang === 'hi' ? 'सभी श्रेणियाँ' : 'All Categories') : c}
              </option>
            ))}
          </select>
        </div>

        <button
          type="button"
          onClick={openAdd}
          className="inline-flex items-center gap-2 px-4 h-11 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-sm font-semibold cursor-pointer whitespace-nowrap"
        >
          <Plus className="w-4 h-4" />
          {lang === 'hi' ? 'नया उत्पाद जोड़ें' : 'Add Product'}
        </button>
      </div>

      {/* Product Grid / Table */}
      {filtered.length === 0 ? (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-10 text-center space-y-3">
          <Package className="w-10 h-10 mx-auto text-slate-400" />
          <p className="text-sm text-slate-500 dark:text-slate-400">{labels.noData}</p>
          <button
            type="button"
            onClick={openAdd}
            className="inline-flex items-center gap-2 px-4 h-10 rounded-xl bg-emerald-700 text-white text-xs font-semibold cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            {lang === 'hi' ? 'पहला उत्पाद जोड़ें' : 'Add First Product'}
          </button>
        </div>
      ) : (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-left text-xs text-slate-500 bg-slate-50/70 dark:bg-slate-950/50">
                  <th className="py-3 px-4">{lang === 'hi' ? 'उत्पाद' : 'Product'}</th>
                  <th className="py-3 px-3">{lang === 'hi' ? 'कोड / बारकोड' : 'SKU / Barcode'}</th>
                  <th className="py-3 px-3 text-right">{lang === 'hi' ? 'खरीद मूल्य' : 'Purchase'}</th>
                  <th className="py-3 px-3 text-right">{lang === 'hi' ? 'बिक्री मूल्य' : 'Selling'}</th>
                  <th className="py-3 px-3 text-right">MRP</th>
                  <th className="py-3 px-3 text-right">{lang === 'hi' ? 'मार्जिन' : 'Margin'}</th>
                  <th className="py-3 px-3 text-right">{lang === 'hi' ? 'स्टॉक' : 'Stock'}</th>
                  <th className="py-3 px-4 text-right">{lang === 'hi' ? 'कार्रवाई' : 'Actions'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filtered.map((p) => {
                  const margin = calculateProfitMargin(p.purchasePrice, p.sellingPrice);
                  return (
                    <tr key={p.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-3">
                          {p.photoUrl ? (
                            <img
                              src={p.photoUrl}
                              alt={p.name}
                              referrerPolicy="no-referrer"
                              className="w-10 h-10 rounded-lg object-cover border border-slate-200 dark:border-slate-700 shrink-0"
                            />
                          ) : (
                            <div className="w-10 h-10 rounded-lg bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-500 shrink-0">
                              <Package className="w-4 h-4" />
                            </div>
                          )}
                          <div className="min-w-0">
                            <p className="font-semibold text-slate-900 dark:text-slate-100 truncate">
                              {p.name}
                            </p>
                            <p className="text-xs text-slate-500">
                              {p.category} · GST {p.gstRate}%
                            </p>
                          </div>
                        </div>
                      </td>
                      <td className="py-3 px-3 font-mono text-xs text-slate-500">
                        {p.barcode || p.sku || '-'}
                      </td>
                      <td className="py-3 px-3 text-right font-mono tabular-nums">
                        {formatINR(p.purchasePrice)}
                      </td>
                      <td className="py-3 px-3 text-right font-mono tabular-nums font-semibold text-emerald-700 dark:text-emerald-400">
                        {formatINR(p.sellingPrice)}
                      </td>
                      <td className="py-3 px-3 text-right font-mono tabular-nums text-slate-500">
                        {formatINR(p.mrp)}
                      </td>
                      <td className="py-3 px-3 text-right font-mono tabular-nums text-xs">
                        {margin}%
                      </td>
                      <td
                        className={`py-3 px-3 text-right font-mono tabular-nums font-bold ${
                          p.stockQty <= 0
                            ? 'text-red-600'
                            : p.stockQty <= p.minStockAlert
                              ? 'text-amber-600'
                              : 'text-slate-900 dark:text-slate-100'
                        }`}
                      >
                        {p.stockQty} {p.unit}
                      </td>
                      <td className="py-3 px-4 text-right whitespace-nowrap">
                        <button
                          type="button"
                          onClick={() => openEdit(p)}
                          className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-sky-700 dark:text-sky-400 cursor-pointer"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDelete(p)}
                          className="p-2 rounded-lg hover:bg-red-50 dark:hover:bg-red-950 text-red-600 cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Add/Edit Product Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 bg-black/55 backdrop-blur-sm flex items-center justify-center p-4">
          <form
            onSubmit={handleSave}
            className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-2xl w-full max-h-[90vh] flex flex-col overflow-hidden"
          >
            <div className="flex items-center justify-between px-5 py-4 border-b border-slate-200 dark:border-slate-800">
              <h3 className="font-bold text-base">
                {form.id
                  ? lang === 'hi'
                    ? 'उत्पाद संपादित करें'
                    : 'Edit Product'
                  : lang === 'hi'
                    ? 'नया उत्पाद जोड़ें'
                    : 'Add New Product'}
              </h3>
              <button
                type="button"
                onClick={() => setModalOpen(false)}
                className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="overflow-y-auto p-5 space-y-4">
              {/* Photo Upload */}
              <div className="flex items-center gap-4">
                {form.photoUrl ? (
                  <img
                    src={form.photoUrl}
                    alt="Preview"
                    className="w-16 h-16 rounded-xl object-cover border border-slate-200 dark:border-slate-700"
                  />
                ) : (
                  <div className="w-16 h-16 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-400">
                    <Package className="w-6 h-6" />
                  </div>
                )}
                <label className="inline-flex items-center gap-2 px-3.5 h-10 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-semibold cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800">
                  <ImagePlus className="w-4 h-4" />
                  {lang === 'hi' ? 'फोटो चुनें' : 'Upload Photo'}
                  <input type="file" accept="image/*" onChange={handlePhotoUpload} className="hidden" />
                </label>
                {form.photoUrl && (
                  <button
                    type="button"
                    onClick={() => setForm((prev) => ({ ...prev, photoUrl: '' }))}
                    className="text-xs text-red-600 cursor-pointer"
                  >
                    {lang === 'hi' ? 'फोटो हटाएं' : 'Remove'}
                  </button>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                    {lang === 'hi' ? 'उत्पाद का नाम *' : 'Product Name *'}
                  </label>
                  <input
                    required
                    type="text"
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                    className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                    {lang === 'hi' ? 'श्रेणी (Category)' : 'Category'}
                  </label>
                  <input
                    type="text"
                    value={form.category}
                    onChange={(e) => setForm({ ...form, category: e.target.value })}
                    className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                    {lang === 'hi' ? 'बारकोड (Barcode)' : 'Barcode'}
                  </label>
                  <input
                    type="text"
                    value={form.barcode}
                    onChange={(e) => setForm({ ...form, barcode: e.target.value })}
                    className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                    {lang === 'hi' ? 'कोड / SKU' : 'Product Code / SKU'}
                  </label>
                  <input
                    type="text"
                    value={form.sku}
                    onChange={(e) => setForm({ ...form, sku: e.target.value })}
                    className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                    {lang === 'hi' ? 'खरीद मूल्य (Purchase Price ₹)' : 'Purchase Price (₹)'}
                  </label>
                  <input
                    required
                    type="number"
                    min="0"
                    step="any"
                    value={form.purchasePrice}
                    onChange={(e) => setForm({ ...form, purchasePrice: Number(e.target.value) || 0 })}
                    className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                    {lang === 'hi' ? 'बिक्री मूल्य (Selling Price ₹)' : 'Selling Price (₹)'}
                  </label>
                  <input
                    required
                    type="number"
                    min="0"
                    step="any"
                    value={form.sellingPrice}
                    onChange={(e) => setForm({ ...form, sellingPrice: Number(e.target.value) || 0 })}
                    className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                    {lang === 'hi' ? 'थोक मूल्य (Wholesale ₹)' : 'Wholesale Price (₹)'}
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="any"
                    value={form.wholesalePrice}
                    onChange={(e) => setForm({ ...form, wholesalePrice: Number(e.target.value) || 0 })}
                    className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                    MRP (₹)
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="any"
                    value={form.mrp}
                    onChange={(e) => setForm({ ...form, mrp: Number(e.target.value) || 0 })}
                    className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                    {lang === 'hi' ? 'वर्तमान स्टॉक मात्रा' : 'Current Stock Qty'}
                  </label>
                  <input
                    type="number"
                    step="any"
                    value={form.stockQty}
                    onChange={(e) => setForm({ ...form, stockQty: Number(e.target.value) || 0 })}
                    className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                    {lang === 'hi' ? 'न्यूनतम स्टॉक अलर्ट' : 'Min Stock Alert'}
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="any"
                    value={form.minStockAlert}
                    onChange={(e) => setForm({ ...form, minStockAlert: Number(e.target.value) || 0 })}
                    className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                    {lang === 'hi' ? 'इकाई (Unit)' : 'Unit'}
                  </label>
                  <select
                    value={form.unit}
                    onChange={(e) => setForm({ ...form, unit: e.target.value })}
                    className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm"
                  >
                    {PRODUCT_UNITS.map((u) => (
                      <option key={u.value} value={u.value}>
                        {u[lang]}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                    GST %
                  </label>
                  <input
                    type="number"
                    min="0"
                    max="50"
                    step="any"
                    value={form.gstRate}
                    onChange={(e) => setForm({ ...form, gstRate: Number(e.target.value) || 0 })}
                    className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                    {lang === 'hi' ? 'एक्सपायरी डेट (वैकल्पिक)' : 'Expiry Date (Optional)'}
                  </label>
                  <input
                    type="date"
                    value={form.expiryDate}
                    onChange={(e) => setForm({ ...form, expiryDate: e.target.value })}
                    className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm font-mono"
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                    {lang === 'hi' ? 'विवरण (Description)' : 'Description'}
                  </label>
                  <textarea
                    rows={2}
                    value={form.description}
                    onChange={(e) => setForm({ ...form, description: e.target.value })}
                    className="w-full p-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm"
                  />
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2.5 px-5 py-3.5 border-t border-slate-200 dark:border-slate-800">
              <button
                type="button"
                onClick={() => setModalOpen(false)}
                className="px-4 h-10 rounded-xl border border-slate-200 dark:border-slate-700 text-sm font-semibold cursor-pointer"
              >
                {labels.cancel}
              </button>
              <button
                type="submit"
                disabled={saving}
                className="px-5 h-10 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-sm font-semibold cursor-pointer"
              >
                {saving ? '...' : labels.save}
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
