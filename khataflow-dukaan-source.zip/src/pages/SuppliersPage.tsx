import React, { useMemo, useState } from 'react';
import { Edit3, FileText, IndianRupee, Plus, Search, Trash2, Truck, X } from 'lucide-react';
import { useDukaan } from '../context/DukaanContext';
import { formatINR, getTodayISO } from '../lib/formatters';
import { t } from '../lib/i18n';
import { deleteSupplier, recordSupplierPayment, saveSupplier } from '../services/dukaanService';
import { Supplier } from '../types/dukaan';

export const SuppliersPage: React.FC = () => {
  const { user, shopProfile, lang, suppliers, supplierPayments, notify, openPrintModal } = useDukaan();
  const labels = t(lang);

  const [search, setSearch] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [editId, setEditId] = useState('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [gstin, setGstin] = useState('');
  const [openingOutstanding, setOpeningOutstanding] = useState(0);
  const [saving, setSaving] = useState(false);

  // Payment modal
  const [paySupp, setPaySupp] = useState<Supplier | null>(null);
  const [payAmount, setPayAmount] = useState(0);
  const [payMode, setPayMode] = useState<'cash' | 'upi' | 'bank'>('cash');
  const [payDate, setPayDate] = useState(getTodayISO());
  const [payNotes, setPayNotes] = useState('');

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return suppliers;
    return suppliers.filter(
      (s) => s.name.toLowerCase().includes(q) || s.phone.includes(q) || (s.gstin || '').toLowerCase().includes(q)
    );
  }, [suppliers, search]);

  const openAdd = () => {
    setEditId('');
    setName('');
    setPhone('');
    setAddress('');
    setGstin('');
    setOpeningOutstanding(0);
    setModalOpen(true);
  };

  const openEdit = (s: Supplier) => {
    setEditId(s.id);
    setName(s.name);
    setPhone(s.phone);
    setAddress(s.address || '');
    setGstin(s.gstin || '');
    setOpeningOutstanding(0);
    setModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || saving) return;
    setSaving(true);
    try {
      await saveSupplier(user.uid, {
        id: editId || undefined,
        name,
        phone,
        address,
        gstin,
        openingOutstanding,
      });
      notify(editId ? (lang === 'hi' ? 'सप्लायर अपडेट हुआ!' : 'Supplier updated!') : (lang === 'hi' ? 'नया सप्लायर जुड़ा!' : 'Supplier added!'));
      setModalOpen(false);
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Save failed', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handlePayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !paySupp || saving || payAmount <= 0) return;
    setSaving(true);
    try {
      await recordSupplierPayment(user.uid, {
        supplierId: paySupp.id,
        amount: payAmount,
        paymentMode: payMode,
        paymentDate: payDate,
        notes: payNotes,
      });
      notify(lang === 'hi' ? 'सप्लायर भुगतान दर्ज हुआ!' : 'Supplier payment recorded!');
      setPaySupp(null);
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Payment failed', 'error');
    } finally {
      setSaving(false);
    }
  };

  const printSupplierLedger = (s: Supplier) => {
    const list = supplierPayments.filter((p) => p.supplierId === s.id);
    openPrintModal({
      title: `${s.name} · ${lang === 'hi' ? 'सप्लायर खाता' : 'Supplier Ledger'}`,
      content: (
        <div className="space-y-4 text-sm text-slate-900">
          <div className="flex justify-between border-b border-slate-300 pb-3">
            <div>
              <h2 className="text-lg font-bold">{shopProfile?.shopName}</h2>
              <p className="text-xs">{s.name} · {s.phone}</p>
            </div>
            <div className="text-right">
              <p className="text-xs text-slate-500">{lang === 'hi' ? 'बकाया देय' : 'Outstanding'}</p>
              <p className="text-lg font-bold font-mono text-red-700">{formatINR(s.remainingOutstanding)}</p>
            </div>
          </div>
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-slate-300 text-left">
                <th className="py-2">{lang === 'hi' ? 'तिथि' : 'Date'}</th>
                <th className="py-2">{lang === 'hi' ? 'प्रकार' : 'Type'}</th>
                <th className="py-2">{lang === 'hi' ? 'विवरण' : 'Notes'}</th>
                <th className="py-2 text-right">{lang === 'hi' ? 'राशि' : 'Amount'}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {list.map((p) => (
                <tr key={p.id}>
                  <td className="py-2 font-mono">{p.paymentDate}</td>
                  <td className="py-2">{p.type} ({p.paymentMode})</td>
                  <td className="py-2">{p.notes || '-'}</td>
                  <td className="py-2 text-right font-mono font-bold">{formatINR(p.amount)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ),
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="relative flex-1 min-w-[220px] max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={lang === 'hi' ? 'सप्लायर नाम या GSTIN खोजें...' : 'Search supplier name, phone or GSTIN...'}
            className="w-full h-11 pl-10 pr-4 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm"
          />
        </div>
        <button
          type="button"
          onClick={openAdd}
          className="inline-flex items-center gap-2 px-4 h-11 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-sm font-semibold cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          {lang === 'hi' ? 'नया सप्लायर जोड़ें' : 'Add Supplier'}
        </button>
      </div>

      {filtered.length === 0 ? (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-10 text-center space-y-3">
          <Truck className="w-10 h-10 mx-auto text-slate-400" />
          <p className="text-sm text-slate-500">{labels.noData}</p>
        </div>
      ) : (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-left text-xs text-slate-500 bg-slate-50/70 dark:bg-slate-950/50">
                  <th className="py-3 px-4">{lang === 'hi' ? 'सप्लायर' : 'Supplier'}</th>
                  <th className="py-3 px-3 text-right">{lang === 'hi' ? 'कुल खरीद' : 'Total Purchases'}</th>
                  <th className="py-3 px-3 text-right">{lang === 'hi' ? 'भुगतान किया' : 'Paid'}</th>
                  <th className="py-3 px-3 text-right">{lang === 'hi' ? 'बकाया देय' : 'Outstanding'}</th>
                  <th className="py-3 px-4 text-right">{lang === 'hi' ? 'कार्रवाई' : 'Actions'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filtered.map((s) => (
                  <tr key={s.id}>
                    <td className="py-3 px-4">
                      <p className="font-semibold">{s.name}</p>
                      <p className="text-xs font-mono text-slate-500">
                        {s.phone} {s.gstin ? `· ${s.gstin}` : ''}
                      </p>
                    </td>
                    <td className="py-3 px-3 text-right font-mono tabular-nums">{formatINR(s.totalPurchases)}</td>
                    <td className="py-3 px-3 text-right font-mono tabular-nums text-emerald-700 dark:text-emerald-400">
                      {formatINR(s.totalPaid)}
                    </td>
                    <td className="py-3 px-3 text-right font-mono tabular-nums font-bold text-red-600">
                      {formatINR(s.remainingOutstanding)}
                    </td>
                    <td className="py-3 px-4 text-right whitespace-nowrap">
                      <button
                        type="button"
                        onClick={() => {
                          setPaySupp(s);
                          setPayAmount(Math.max(0, s.remainingOutstanding));
                          setPayMode('cash');
                          setPayDate(getTodayISO());
                          setPayNotes('');
                        }}
                        className="inline-flex items-center gap-1 px-2.5 h-8 rounded-lg bg-emerald-700 text-white text-xs font-semibold mr-1 cursor-pointer"
                      >
                        <IndianRupee className="w-3.5 h-3.5" />
                        {lang === 'hi' ? 'भुगतान' : 'Pay'}
                      </button>
                      <button
                        type="button"
                        onClick={() => printSupplierLedger(s)}
                        className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                      >
                        <FileText className="w-4 h-4" />
                      </button>
                      <button
                        type="button"
                        onClick={() => openEdit(s)}
                        className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-sky-700 cursor-pointer"
                      >
                        <Edit3 className="w-4 h-4" />
                      </button>
                      <button
                        type="button"
                        onClick={async () => {
                          if (!user) return;
                          await deleteSupplier(user.uid, s.id);
                          notify(lang === 'hi' ? 'सप्लायर हटाया गया।' : 'Supplier deleted.');
                        }}
                        className="p-2 rounded-lg hover:bg-red-50 dark:hover:bg-red-950 text-red-600 cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Supplier Add/Edit Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 bg-black/55 backdrop-blur-sm flex items-center justify-center p-4">
          <form
            onSubmit={handleSave}
            className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-md w-full p-5 space-y-4"
          >
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-base">
                {editId ? (lang === 'hi' ? 'सप्लायर संपादित करें' : 'Edit Supplier') : (lang === 'hi' ? 'नया सप्लायर' : 'New Supplier')}
              </h3>
              <button
                type="button"
                onClick={() => setModalOpen(false)}
                className="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="space-y-3">
              <input
                required
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder={lang === 'hi' ? 'सप्लायर / फर्म का नाम *' : 'Supplier Name *'}
                className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm"
              />
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder={lang === 'hi' ? 'मोबाइल नंबर' : 'Phone'}
                className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono text-sm"
              />
              <input
                type="text"
                value={gstin}
                onChange={(e) => setGstin(e.target.value)}
                placeholder="GSTIN (Optional)"
                className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono text-sm"
              />
              <input
                type="text"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder={lang === 'hi' ? 'पता' : 'Address'}
                className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm"
              />
              {!editId && (
                <div>
                  <label className="block text-xs text-slate-500 mb-1">
                    {lang === 'hi' ? 'पिछला बकाया (Opening Payable ₹)' : 'Opening Outstanding (₹)'}
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="any"
                    value={openingOutstanding}
                    onChange={(e) => setOpeningOutstanding(Number(e.target.value) || 0)}
                    className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono text-sm"
                  />
                </div>
              )}
            </div>
            <button
              type="submit"
              disabled={saving}
              className="w-full h-11 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-semibold text-sm cursor-pointer"
            >
              {saving ? '...' : labels.save}
            </button>
          </form>
        </div>
      )}

      {/* Supplier Payment Modal */}
      {paySupp && (
        <div className="fixed inset-0 z-50 bg-black/55 backdrop-blur-sm flex items-center justify-center p-4">
          <form
            onSubmit={handlePayment}
            className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-md w-full p-5 space-y-4"
          >
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-base">
                {paySupp.name} · {lang === 'hi' ? 'भुगतान दर्ज करें' : 'Record Payment'}
              </h3>
              <button
                type="button"
                onClick={() => setPaySupp(null)}
                className="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="space-y-3">
              <input
                required
                type="number"
                min="1"
                step="any"
                value={payAmount}
                onChange={(e) => setPayAmount(Number(e.target.value) || 0)}
                className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono text-base font-bold"
              />
              <select
                value={payMode}
                onChange={(e) => setPayMode(e.target.value as 'cash' | 'upi' | 'bank')}
                className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm"
              >
                <option value="cash">{labels.cash}</option>
                <option value="upi">{labels.upi}</option>
                <option value="bank">{labels.bank}</option>
              </select>
              <input
                type="date"
                value={payDate}
                onChange={(e) => setPayDate(e.target.value)}
                className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono text-sm"
              />
              <input
                type="text"
                value={payNotes}
                onChange={(e) => setPayNotes(e.target.value)}
                placeholder={lang === 'hi' ? 'नोट / संदर्भ नं' : 'Notes / Reference'}
                className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm"
              />
            </div>
            <button
              type="submit"
              disabled={saving}
              className="w-full h-11 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-semibold text-sm cursor-pointer"
            >
              {saving ? '...' : labels.save}
            </button>
          </form>
        </div>
      )}
    </div>
  );
};
