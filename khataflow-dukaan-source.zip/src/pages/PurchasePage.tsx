import React, { useMemo, useState } from 'react';
import { Plus, ShoppingBag, Trash2, XCircle } from 'lucide-react';
import { useDukaan } from '../context/DukaanContext';
import { formatINR, getTodayISO } from '../lib/formatters';
import { t } from '../lib/i18n';
import { cancelPurchase, createPurchase } from '../services/dukaanService';
import { PurchaseLineItem, PurchasePaymentMode } from '../types/dukaan';

export const PurchasePage: React.FC = () => {
  const { user, lang, suppliers, products, purchases, notify, setActiveSection } = useDukaan();
  const labels = t(lang);

  const [supplierId, setSupplierId] = useState('');
  const [purchaseDate, setPurchaseDate] = useState(getTodayISO());
  const [selectedProductId, setSelectedProductId] = useState('');
  const [items, setItems] = useState<PurchaseLineItem[]>([]);
  const [paidAmount, setPaidAmount] = useState(0);
  const [paymentMode, setPaymentMode] = useState<PurchasePaymentMode>('cash');
  const [updateRates, setUpdateRates] = useState(true);
  const [notes, setNotes] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const totalAmount = useMemo(
    () => Math.round(items.reduce((s, i) => s + i.lineTotal, 0) * 100) / 100,
    [items]
  );

  const addItem = () => {
    const prod = products.find((p) => p.id === selectedProductId);
    if (!prod) return;
    setItems((prev) => {
      if (prev.some((i) => i.productId === prod.id)) return prev;
      return [
        ...prev,
        {
          productId: prod.id,
          productName: prod.name,
          unit: prod.unit,
          qty: 1,
          purchaseRate: prod.purchasePrice,
          lineTotal: prod.purchasePrice,
        },
      ];
    });
    setSelectedProductId('');
  };

  const updateRow = (idx: number, qty: number, rate: number) => {
    setItems((prev) =>
      prev.map((row, i) =>
        i === idx
          ? {
              ...row,
              qty: Math.max(0.01, qty),
              purchaseRate: Math.max(0, rate),
              lineTotal: Math.round(Math.max(0.01, qty) * Math.max(0, rate) * 100) / 100,
            }
          : row
      )
    );
  };

  const nextPurNum = `PUR-${purchases.length + 501}`;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || submitting) return;
    const supp = suppliers.find((s) => s.id === supplierId);
    if (!supp) {
      notify(lang === 'hi' ? 'कृपया सप्लायर चुनें।' : 'Please select a supplier.', 'error');
      return;
    }
    if (items.length === 0) {
      notify(lang === 'hi' ? 'कृपया कम से कम 1 उत्पाद जोड़ें।' : 'Add at least 1 product.', 'error');
      return;
    }

    setSubmitting(true);
    try {
      await createPurchase(user.uid, {
        purchaseNumber: nextPurNum,
        supplierId: supp.id,
        supplierName: supp.name,
        items,
        totalAmount,
        paidAmount: paymentMode === 'credit' ? 0 : Math.min(totalAmount, Math.max(0, paidAmount)),
        paymentMode,
        purchaseDate,
        notes,
        updateProductPurchaseRates: updateRates,
      });
      notify(lang === 'hi' ? 'खरीद दर्ज हुई और स्टॉक बढ़ गया!' : 'Purchase saved & stock increased!');
      setItems([]);
      setPaidAmount(0);
      setNotes('');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Purchase failed', 'error');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-8">
      <form
        onSubmit={handleSubmit}
        className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-5"
      >
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 dark:border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-emerald-700" />
            <h2 className="text-base font-bold">
              {lang === 'hi' ? `नई खरीद प्रविष्टि · ${nextPurNum}` : `New Stock Purchase · ${nextPurNum}`}
            </h2>
          </div>
          {suppliers.length === 0 && (
            <button
              type="button"
              onClick={() => setActiveSection('suppliers')}
              className="text-xs font-semibold text-emerald-700 hover:underline cursor-pointer"
            >
              + {lang === 'hi' ? 'पहले सप्लायर जोड़ें' : 'Add Supplier First'}
            </button>
          )}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div>
            <label className="block text-xs text-slate-500 mb-1">
              {lang === 'hi' ? 'सप्लायर चुनें *' : 'Select Supplier *'}
            </label>
            <select
              required
              value={supplierId}
              onChange={(e) => setSupplierId(e.target.value)}
              className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm"
            >
              <option value="">{lang === 'hi' ? '-- सप्लायर --' : '-- Supplier --'}</option>
              {suppliers.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} ({s.phone})
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-xs text-slate-500 mb-1">
              {lang === 'hi' ? 'खरीद तिथि' : 'Purchase Date'}
            </label>
            <input
              type="date"
              value={purchaseDate}
              onChange={(e) => setPurchaseDate(e.target.value)}
              className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono text-sm"
            />
          </div>
          <div>
            <label className="block text-xs text-slate-500 mb-1">
              {lang === 'hi' ? 'उत्पाद जोड़ें' : 'Add Product'}
            </label>
            <div className="flex gap-2">
              <select
                value={selectedProductId}
                onChange={(e) => setSelectedProductId(e.target.value)}
                className="flex-1 h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm"
              >
                <option value="">{lang === 'hi' ? '-- उत्पाद चुनें --' : '-- Select Product --'}</option>
                {products.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name} ({p.stockQty} {p.unit})
                  </option>
                ))}
              </select>
              <button
                type="button"
                onClick={addItem}
                className="px-3.5 h-11 rounded-xl bg-slate-900 dark:bg-slate-800 text-white text-xs font-semibold cursor-pointer"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {items.length > 0 && (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-left text-xs text-slate-500">
                  <th className="py-2 pr-2">{lang === 'hi' ? 'उत्पाद' : 'Product'}</th>
                  <th className="py-2 px-2 text-right">{lang === 'hi' ? 'मात्रा' : 'Qty'}</th>
                  <th className="py-2 px-2 text-right">{lang === 'hi' ? 'खरीद दर (₹)' : 'Rate (₹)'}</th>
                  <th className="py-2 pl-2 text-right">{lang === 'hi' ? 'कुल' : 'Total'}</th>
                  <th className="py-2 w-8" />
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {items.map((row, idx) => (
                  <tr key={row.productId}>
                    <td className="py-2.5 pr-2 font-medium">
                      {row.productName} <span className="text-xs text-slate-500">({row.unit})</span>
                    </td>
                    <td className="py-2.5 px-2 text-right">
                      <input
                        type="number"
                        min="0.01"
                        step="any"
                        value={row.qty}
                        onChange={(e) => updateRow(idx, Number(e.target.value) || 0, row.purchaseRate)}
                        className="w-24 h-9 px-2 text-right rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono text-xs"
                      />
                    </td>
                    <td className="py-2.5 px-2 text-right">
                      <input
                        type="number"
                        min="0"
                        step="any"
                        value={row.purchaseRate}
                        onChange={(e) => updateRow(idx, row.qty, Number(e.target.value) || 0)}
                        className="w-28 h-9 px-2 text-right rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono text-xs"
                      />
                    </td>
                    <td className="py-2.5 pl-2 text-right font-mono tabular-nums font-bold">
                      {formatINR(row.lineTotal)}
                    </td>
                    <td className="py-2.5 pl-2 text-right">
                      <button
                        type="button"
                        onClick={() => setItems((prev) => prev.filter((_, i) => i !== idx))}
                        className="text-red-500 p-1 cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 pt-3 border-t border-slate-200 dark:border-slate-800 items-end">
          <div>
            <label className="block text-xs text-slate-500 mb-1">
              {lang === 'hi' ? 'भुगतान माध्यम' : 'Payment Mode'}
            </label>
            <select
              value={paymentMode}
              onChange={(e) => setPaymentMode(e.target.value as PurchasePaymentMode)}
              className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm"
            >
              <option value="cash">{labels.cash}</option>
              <option value="upi">{labels.upi}</option>
              <option value="bank">{labels.bank}</option>
              <option value="credit">{labels.credit}</option>
            </select>
          </div>
          <div>
            <label className="block text-xs text-slate-500 mb-1">
              {lang === 'hi' ? 'जमा / भुगतान राशि (₹)' : 'Paid Amount (₹)'}
            </label>
            <input
              type="number"
              min="0"
              max={totalAmount}
              step="any"
              disabled={paymentMode === 'credit'}
              value={paymentMode === 'credit' ? 0 : paidAmount}
              onChange={(e) => setPaidAmount(Number(e.target.value) || 0)}
              className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono text-sm"
            />
          </div>
          <div>
            <p className="text-xs text-slate-500">{lang === 'hi' ? 'कुल खरीद / बाकी' : 'Total / Remaining'}</p>
            <p className="font-mono font-bold text-base">
              {formatINR(totalAmount)}{' '}
              <span className="text-xs text-amber-600">
                ({lang === 'hi' ? 'बाकी' : 'Due'}:{' '}
                {formatINR(
                  Math.max(0, totalAmount - (paymentMode === 'credit' ? 0 : Math.min(totalAmount, paidAmount)))
                )}
                )
              </span>
            </p>
          </div>
          <button
            type="submit"
            disabled={submitting || items.length === 0}
            className="h-11 rounded-xl bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white font-semibold text-sm cursor-pointer"
          >
            {submitting ? '...' : lang === 'hi' ? 'खरीद सेव करें' : 'Save Purchase'}
          </button>
        </div>

        <label className="inline-flex items-center gap-2 text-xs text-slate-600 dark:text-slate-400 cursor-pointer">
          <input
            type="checkbox"
            checked={updateRates}
            onChange={(e) => setUpdateRates(e.target.checked)}
            className="w-4 h-4 accent-emerald-700"
          />
          {lang === 'hi'
            ? 'खरीद दर बदलने पर उत्पाद का खरीद मूल्य और मूल्य इतिहास अपने-आप अपडेट करें'
            : 'Auto-update product purchase rate & log price history if rate changed'}
        </label>
      </form>

      {/* Purchase History */}
      <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-4">
        <h3 className="text-base font-bold">{lang === 'hi' ? 'खरीद इतिहास' : 'Purchase History'}</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 text-left text-xs text-slate-500">
                <th className="py-2.5 pr-3">#</th>
                <th className="py-2.5 pr-3">{lang === 'hi' ? 'तिथि' : 'Date'}</th>
                <th className="py-2.5 pr-3">{lang === 'hi' ? 'सप्लायर' : 'Supplier'}</th>
                <th className="py-2.5 pr-3 text-right">{lang === 'hi' ? 'कुल' : 'Total'}</th>
                <th className="py-2.5 pr-3 text-right">{lang === 'hi' ? 'भुगतान' : 'Paid'}</th>
                <th className="py-2.5 pr-3 text-right">{lang === 'hi' ? 'बाकी' : 'Due'}</th>
                <th className="py-2.5 text-right">{lang === 'hi' ? 'कार्रवाई' : 'Action'}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {purchases.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-slate-500">
                    {labels.noData}
                  </td>
                </tr>
              ) : (
                purchases.map((p) => (
                  <tr key={p.id}>
                    <td className="py-3 pr-3 font-mono font-semibold">{p.purchaseNumber}</td>
                    <td className="py-3 pr-3 font-mono text-xs text-slate-500">{p.purchaseDate}</td>
                    <td className="py-3 pr-3 font-medium">
                      {p.supplierName}{' '}
                      {p.status === 'cancelled' && (
                        <span className="text-xs text-red-600">({labels.cancelled})</span>
                      )}
                    </td>
                    <td className="py-3 pr-3 text-right font-mono tabular-nums">{formatINR(p.totalAmount)}</td>
                    <td className="py-3 pr-3 text-right font-mono tabular-nums text-emerald-700 dark:text-emerald-400">
                      {formatINR(p.paidAmount)}
                    </td>
                    <td className="py-3 pr-3 text-right font-mono tabular-nums text-red-600">
                      {formatINR(p.remainingAmount)}
                    </td>
                    <td className="py-3 text-right">
                      {p.status !== 'cancelled' && (
                        <button
                          type="button"
                          onClick={async () => {
                            if (!user) return;
                            await cancelPurchase(user.uid, p.id);
                            notify(lang === 'hi' ? 'खरीद रद्द हुई।' : 'Purchase cancelled.');
                          }}
                          className="p-2 text-red-600 hover:bg-red-50 dark:hover:bg-red-950 rounded-lg cursor-pointer"
                          title={lang === 'hi' ? 'खरीद रद्द करें' : 'Cancel Purchase'}
                        >
                          <XCircle className="w-4 h-4" />
                        </button>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
};
