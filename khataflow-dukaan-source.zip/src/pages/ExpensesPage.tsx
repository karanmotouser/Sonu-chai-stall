import React, { useMemo, useState } from 'react';
import { Edit3, Plus, Trash2, Wallet, X } from 'lucide-react';
import { useDukaan } from '../context/DukaanContext';
import { formatINR, getMonthPrefix, getTodayISO, isWithinLastDays } from '../lib/formatters';
import { EXPENSE_CATEGORIES, t } from '../lib/i18n';
import { deleteExpense, saveExpense } from '../services/dukaanService';
import { Expense, ExpenseCategory, ExpensePaymentMode } from '../types/dukaan';

export const ExpensesPage: React.FC = () => {
  const { user, lang, expenses, notify } = useDukaan();
  const labels = t(lang);

  const [catFilter, setCatFilter] = useState<'all' | ExpenseCategory>('all');
  const [period, setPeriod] = useState<'all' | 'day' | 'week' | 'month'>('all');
  const [modalOpen, setModalOpen] = useState(false);

  const [editId, setEditId] = useState('');
  const [category, setCategory] = useState<ExpenseCategory>('electricity');
  const [title, setTitle] = useState('');
  const [amount, setAmount] = useState(0);
  const [paymentMode, setPaymentMode] = useState<ExpensePaymentMode>('cash');
  const [expenseDate, setExpenseDate] = useState(getTodayISO());
  const [notes, setNotes] = useState('');
  const [saving, setSaving] = useState(false);

  const today = getTodayISO();
  const monthPrefix = getMonthPrefix(today);

  const summary = useMemo(() => {
    const daily = expenses.filter((e) => e.expenseDate === today).reduce((s, e) => s + e.amount, 0);
    const weekly = expenses
      .filter((e) => isWithinLastDays(e.expenseDate, 7))
      .reduce((s, e) => s + e.amount, 0);
    const monthly = expenses
      .filter((e) => e.expenseDate.startsWith(monthPrefix))
      .reduce((s, e) => s + e.amount, 0);
    return { daily, weekly, monthly };
  }, [expenses, today, monthPrefix]);

  const filtered = useMemo(() => {
    return expenses.filter((e) => {
      const matchCat = catFilter === 'all' || e.category === catFilter;
      const matchPeriod =
        period === 'all' ||
        (period === 'day' && e.expenseDate === today) ||
        (period === 'week' && isWithinLastDays(e.expenseDate, 7)) ||
        (period === 'month' && e.expenseDate.startsWith(monthPrefix));
      return matchCat && matchPeriod;
    });
  }, [expenses, catFilter, period, today, monthPrefix]);

  const openAdd = () => {
    setEditId('');
    setCategory('electricity');
    setTitle('');
    setAmount(0);
    setPaymentMode('cash');
    setExpenseDate(today);
    setNotes('');
    setModalOpen(true);
  };

  const openEdit = (e: Expense) => {
    setEditId(e.id);
    setCategory(e.category);
    setTitle(e.title);
    setAmount(e.amount);
    setPaymentMode(e.paymentMode);
    setExpenseDate(e.expenseDate);
    setNotes(e.notes || '');
    setModalOpen(true);
  };

  const handleSave = async (ev: React.FormEvent) => {
    ev.preventDefault();
    if (!user || saving) return;
    if (amount <= 0) {
      notify(lang === 'hi' ? 'खर्च राशि 0 से अधिक होनी चाहिए।' : 'Amount must be greater than 0.', 'error');
      return;
    }
    setSaving(true);
    try {
      await saveExpense(user.uid, {
        id: editId || undefined,
        category,
        title,
        amount,
        paymentMode,
        expenseDate,
        notes,
      });
      notify(lang === 'hi' ? 'खर्च सेव हो गया!' : 'Expense saved!');
      setModalOpen(false);
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Save failed', 'error');
    } finally {
      setSaving(false);
    }
  };

  const getCategoryLabel = (val: ExpenseCategory) =>
    EXPENSE_CATEGORIES.find((c) => c.value === val)?.[lang] || val;

  return (
    <div className="space-y-6">
      {/* Daily / Weekly / Monthly Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4">
          <p className="text-xs text-slate-500">{lang === 'hi' ? 'आज का खर्च' : "Today's Expenses"}</p>
          <p className="text-xl font-bold font-mono tabular-nums text-red-600 mt-1">
            {formatINR(summary.daily)}
          </p>
        </div>
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4">
          <p className="text-xs text-slate-500">{lang === 'hi' ? 'साप्ताहिक खर्च (7 दिन)' : 'Weekly Expenses (7d)'}</p>
          <p className="text-xl font-bold font-mono tabular-nums text-amber-600 mt-1">
            {formatINR(summary.weekly)}
          </p>
        </div>
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4">
          <p className="text-xs text-slate-500">{lang === 'hi' ? 'मासिक खर्च' : 'Monthly Expenses'}</p>
          <p className="text-xl font-bold font-mono tabular-nums text-slate-900 dark:text-slate-100 mt-1">
            {formatINR(summary.monthly)}
          </p>
        </div>
      </div>

      {/* Filters & Add Button */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-2">
          <select
            value={period}
            onChange={(e) => setPeriod(e.target.value as 'all' | 'day' | 'week' | 'month')}
            className="h-10 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-semibold"
          >
            <option value="all">{labels.all}</option>
            <option value="day">{labels.day}</option>
            <option value="week">{labels.week}</option>
            <option value="month">{labels.month}</option>
          </select>
          <select
            value={catFilter}
            onChange={(e) => setCatFilter(e.target.value as 'all' | ExpenseCategory)}
            className="h-10 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-semibold"
          >
            <option value="all">{lang === 'hi' ? 'सभी खर्च श्रेणियाँ' : 'All Categories'}</option>
            {EXPENSE_CATEGORIES.map((c) => (
              <option key={c.value} value={c.value}>
                {c[lang]}
              </option>
            ))}
          </select>
        </div>

        <button
          type="button"
          onClick={openAdd}
          className="inline-flex items-center gap-2 px-4 h-10 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          {lang === 'hi' ? 'नया खर्च जोड़ें' : 'Add Expense'}
        </button>
      </div>

      {/* Table */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 text-left text-xs text-slate-500 bg-slate-50/70 dark:bg-slate-950/50">
                <th className="py-3 px-4">{lang === 'hi' ? 'तिथि' : 'Date'}</th>
                <th className="py-3 px-3">{lang === 'hi' ? 'श्रेणी' : 'Category'}</th>
                <th className="py-3 px-3">{lang === 'hi' ? 'विवरण' : 'Title'}</th>
                <th className="py-3 px-3">{lang === 'hi' ? 'माध्यम' : 'Mode'}</th>
                <th className="py-3 px-3 text-right">{lang === 'hi' ? 'राशि' : 'Amount'}</th>
                <th className="py-3 px-4 text-right">{lang === 'hi' ? 'कार्रवाई' : 'Actions'}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-slate-500">
                    <Wallet className="w-6 h-6 mx-auto mb-1 opacity-50" />
                    {labels.noData}
                  </td>
                </tr>
              ) : (
                filtered.map((ex) => (
                  <tr key={ex.id}>
                    <td className="py-3 px-4 font-mono text-xs text-slate-500">{ex.expenseDate}</td>
                    <td className="py-3 px-3 text-xs font-medium">{getCategoryLabel(ex.category)}</td>
                    <td className="py-3 px-3">
                      <p className="font-semibold">{ex.title}</p>
                      {ex.notes && <p className="text-xs text-slate-500">{ex.notes}</p>}
                    </td>
                    <td className="py-3 px-3 text-xs">{labels[ex.paymentMode]}</td>
                    <td className="py-3 px-3 text-right font-mono tabular-nums font-bold text-red-600">
                      {formatINR(ex.amount)}
                    </td>
                    <td className="py-3 px-4 text-right whitespace-nowrap">
                      <button
                        type="button"
                        onClick={() => openEdit(ex)}
                        className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-sky-700 cursor-pointer"
                      >
                        <Edit3 className="w-4 h-4" />
                      </button>
                      <button
                        type="button"
                        onClick={async () => {
                          if (!user) return;
                          await deleteExpense(user.uid, ex.id);
                          notify(lang === 'hi' ? 'खर्च हटाया गया।' : 'Expense deleted.');
                        }}
                        className="p-2 rounded-lg hover:bg-red-50 dark:hover:bg-red-950 text-red-600 cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add/Edit Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 bg-black/55 backdrop-blur-sm flex items-center justify-center p-4">
          <form
            onSubmit={handleSave}
            className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-md w-full p-5 space-y-4"
          >
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-base">
                {editId ? (lang === 'hi' ? 'खर्च संपादित करें' : 'Edit Expense') : (lang === 'hi' ? 'नया खर्च' : 'New Expense')}
              </h3>
              <button
                type="button"
                onClick={() => setModalOpen(false)}
                className="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="space-y-3">
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as ExpenseCategory)}
                className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm"
              >
                {EXPENSE_CATEGORIES.map((c) => (
                  <option key={c.value} value={c.value}>
                    {c[lang]}
                  </option>
                ))}
              </select>
              <input
                required
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder={lang === 'hi' ? 'खर्च का विवरण (जैसे: जून बिजली बिल) *' : 'Expense title *'}
                className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm"
              />
              <input
                required
                type="number"
                min="1"
                step="any"
                value={amount}
                onChange={(e) => setAmount(Number(e.target.value) || 0)}
                placeholder={lang === 'hi' ? 'राशि (₹)' : 'Amount (₹)'}
                className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono text-base font-bold"
              />
              <select
                value={paymentMode}
                onChange={(e) => setPaymentMode(e.target.value as ExpensePaymentMode)}
                className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm"
              >
                <option value="cash">{labels.cash}</option>
                <option value="upi">{labels.upi}</option>
                <option value="bank">{labels.bank}</option>
              </select>
              <input
                type="date"
                value={expenseDate}
                onChange={(e) => setExpenseDate(e.target.value)}
                className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono text-sm"
              />
              <input
                type="text"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder={lang === 'hi' ? 'नोट (वैकल्पिक)' : 'Notes (Optional)'}
                className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm"
              />
            </div>
            <button
              type="submit"
              disabled={saving}
              className="w-full h-11 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-semibold text-sm cursor-pointer"
            >
              {saving ? '...' : labels.save}
            </button>
          </form>
        </div>
      )}
    </div>
  );
};
