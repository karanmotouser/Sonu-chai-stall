import React, { useEffect, useState } from 'react';
import { Check, Copy, Database, Download, FileArchive, Lock, LogOut, Moon, Save, Shield, Sun, Upload } from 'lucide-react';
import { PWAInstallButton } from '../components/PWAInstallBanner';
import { useDukaan } from '../context/DukaanContext';
import {
  downloadSourceZipWithProgress,
  getSourceZipDirectUrl,
  SOURCE_ZIP_PATH,
  useSourceZipInfo,
} from '../hooks/usePWAInstall';
import { hashPin } from '../lib/formatters';
import { t } from '../lib/i18n';
import { exportShopBackup, importShopBackup, updateShopProfile } from '../services/dukaanService';

export const SettingsPage: React.FC = () => {
  const {
    user,
    isLocalMode,
    shopProfile,
    lang,
    setLang,
    theme,
    toggleTheme,
    logout,
    notify,
    auditLogs,
  } = useDukaan();
  const labels = t(lang);
  const zipInfo = useSourceZipInfo();
  const directZipUrl = getSourceZipDirectUrl();

  const [shopName, setShopName] = useState(shopProfile?.shopName || '');
  const [ownerName, setOwnerName] = useState(shopProfile?.ownerName || '');
  const [phone, setPhone] = useState(shopProfile?.phone || '');
  const [address, setAddress] = useState(shopProfile?.address || '');
  const [gstin, setGstin] = useState(shopProfile?.gstin || '');
  const [defaultGstRate, setDefaultGstRate] = useState(shopProfile?.defaultGstRate || 0);
  const [openingCashBalance, setOpeningCashBalance] = useState(shopProfile?.openingCashBalance || 0);
  const [saving, setSaving] = useState(false);

  const [newPin, setNewPin] = useState('');
  const [busyBackup, setBusyBackup] = useState(false);
  const [downloadingZip, setDownloadingZip] = useState(false);
  const [zipProgress, setZipProgress] = useState('');
  const [copiedLink, setCopiedLink] = useState(false);

  useEffect(() => {
    if (!shopProfile) return;
    setShopName(shopProfile.shopName);
    setOwnerName(shopProfile.ownerName);
    setPhone(shopProfile.phone || '');
    setAddress(shopProfile.address || '');
    setGstin(shopProfile.gstin || '');
    setDefaultGstRate(shopProfile.defaultGstRate);
    setOpeningCashBalance(shopProfile.openingCashBalance);
  }, [shopProfile]);

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || saving) return;
    setSaving(true);
    try {
      await updateShopProfile(user.uid, {
        shopName,
        ownerName,
        phone,
        address,
        gstin,
        defaultGstRate,
        openingCashBalance,
      });
      notify(lang === 'hi' ? 'दुकान सेटिंग्स सेव हो गईं!' : 'Shop settings saved!');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Save failed', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleSetPin = async () => {
    if (!user) return;
    if (newPin.trim().length < 4) {
      notify(lang === 'hi' ? 'कम से कम 4 अंकों का पिन डालें।' : 'Enter at least a 4-digit PIN.', 'error');
      return;
    }
    const hashed = await hashPin(newPin.trim());
    await updateShopProfile(user.uid, { pinHash: hashed });
    setNewPin('');
    notify(lang === 'hi' ? 'सुरक्षा पिन सक्रिय हो गया!' : 'Security PIN enabled!');
  };

  const handleRemovePin = async () => {
    if (!user) return;
    await updateShopProfile(user.uid, { pinHash: '' });
    notify(lang === 'hi' ? 'पिन लॉक हटाया गया।' : 'PIN lock removed.');
  };

  const handleDownloadSourceZip = async () => {
    if (downloadingZip) return;
    setDownloadingZip(true);
    try {
      const bytes = await downloadSourceZipWithProgress((loaded, total, pct) => {
        setZipProgress(`${loaded}/${total} MB (${pct}%)`);
      });
      notify(
        lang === 'hi'
          ? `पूरा सोर्स कोड + Android प्रोजेक्ट (${(bytes / (1024 * 1024)).toFixed(1)} MB) डाउनलोड हो गया!`
          : 'Complete source & Android ZIP downloaded!'
      );
    } catch (err) {
      notify(err instanceof Error ? err.message : 'ZIP download failed', 'error');
    } finally {
      setDownloadingZip(false);
      setZipProgress('');
    }
  };

  const handleExportBackup = async () => {
    if (!user || busyBackup) return;
    setBusyBackup(true);
    try {
      const data = await exportShopBackup(user.uid);
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `khataflow_backup_${new Date().toISOString().slice(0, 10)}.json`;
      a.click();
      URL.revokeObjectURL(url);
      notify(lang === 'hi' ? 'पूरा डेटा बैकअप डाउनलोड हो गया!' : 'Full JSON backup downloaded!');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Backup export failed', 'error');
    } finally {
      setBusyBackup(false);
    }
  };

  const handleImportBackup = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user) return;
    setBusyBackup(true);
    try {
      const text = await file.text();
      const parsed = JSON.parse(text) as Record<string, unknown>;
      const count = await importShopBackup(user.uid, parsed);
      notify(
        lang === 'hi'
          ? `बैकअप से ${count} रिकॉर्ड सफलतापूर्वक पुनर्स्थापित हुए!`
          : `Restored ${count} records from backup!`
      );
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Backup import failed', 'error');
    } finally {
      setBusyBackup(false);
      e.target.value = '';
    }
  };

  return (
    <div className="space-y-6 max-w-4xl">
      {/* Shop Profile Form */}
      <form
        onSubmit={handleSaveProfile}
        className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-4"
      >
        <h2 className="text-base font-bold">
          {lang === 'hi' ? 'दुकान एवं मालिक प्रोफ़ाइल' : 'Shop & Owner Profile'}
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
          <div>
            <label className="block text-xs text-slate-500 mb-1">
              {lang === 'hi' ? 'दुकान का नाम *' : 'Shop Name *'}
            </label>
            <input
              required
              type="text"
              value={shopName}
              onChange={(e) => setShopName(e.target.value)}
              className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs text-slate-500 mb-1">
              {lang === 'hi' ? 'मालिक का नाम *' : 'Owner Name *'}
            </label>
            <input
              required
              type="text"
              value={ownerName}
              onChange={(e) => setOwnerName(e.target.value)}
              className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs text-slate-500 mb-1">
              {lang === 'hi' ? 'मोबाइल नंबर' : 'Phone'}
            </label>
            <input
              type="tel"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono text-sm"
            />
          </div>
          <div>
            <label className="block text-xs text-slate-500 mb-1">GSTIN</label>
            <input
              type="text"
              value={gstin}
              onChange={(e) => setGstin(e.target.value)}
              className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono text-sm"
            />
          </div>
          <div>
            <label className="block text-xs text-slate-500 mb-1">
              {lang === 'hi' ? 'डिफ़ॉल्ट GST %' : 'Default GST %'}
            </label>
            <input
              type="number"
              min="0"
              max="50"
              step="any"
              value={defaultGstRate}
              onChange={(e) => setDefaultGstRate(Number(e.target.value) || 0)}
              className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono text-sm"
            />
          </div>
          <div>
            <label className="block text-xs text-slate-500 mb-1">
              {lang === 'hi' ? 'ओपनिंग कैश बैलेंस (₹)' : 'Opening Cash Balance (₹)'}
            </label>
            <input
              type="number"
              step="any"
              value={openingCashBalance}
              onChange={(e) => setOpeningCashBalance(Number(e.target.value) || 0)}
              className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono text-sm"
            />
          </div>
          <div className="sm:col-span-2">
            <label className="block text-xs text-slate-500 mb-1">{lang === 'hi' ? 'दुकान का पता' : 'Shop Address'}</label>
            <input
              type="text"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm"
            />
          </div>
        </div>
        <button
          type="submit"
          disabled={saving}
          className="inline-flex items-center gap-2 px-5 h-11 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-sm font-semibold cursor-pointer"
        >
          <Save className="w-4 h-4" />
          {saving ? '...' : labels.save}
        </button>
      </form>

      {/* Appearance & Language */}
      <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h3 className="font-bold text-sm">{lang === 'hi' ? 'भाषा और थीम' : 'Language & Appearance'}</h3>
          <p className="text-xs text-slate-500">
            {lang === 'hi' ? 'हिंदी / English और लाइट / डार्क मोड चुनें' : 'Switch Hindi/English or Light/Dark mode'}
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex p-1 bg-slate-100 dark:bg-slate-800 rounded-xl">
            <button
              type="button"
              onClick={() => setLang('hi')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer ${
                lang === 'hi' ? 'bg-white dark:bg-slate-900 shadow-sm' : ''
              }`}
            >
              हिंदी
            </button>
            <button
              type="button"
              onClick={() => setLang('en')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer ${
                lang === 'en' ? 'bg-white dark:bg-slate-900 shadow-sm' : ''
              }`}
            >
              English
            </button>
          </div>
          <button
            type="button"
            onClick={toggleTheme}
            className="inline-flex items-center gap-2 px-3.5 h-10 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-semibold cursor-pointer"
          >
            {theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            {theme === 'dark' ? (lang === 'hi' ? 'लाइट मोड' : 'Light Mode') : (lang === 'hi' ? 'डार्क मोड' : 'Dark Mode')}
          </button>
          <PWAInstallButton />
        </div>
      </section>

      {/* Storage Mode & Android APK Source Code ZIP */}
      <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Database className="w-4 h-4 text-emerald-700" />
            <h3 className="font-bold text-sm">
              {lang === 'hi'
                ? `ऑफ़लाइन डेटाबेस व पूरा Android पैकेज (${zipInfo.sizeMB} MB)`
                : `Offline Database & Full Android Package (${zipInfo.sizeMB} MB)`}
            </h3>
          </div>
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-300 text-xs font-semibold">
            {isLocalMode
              ? lang === 'hi'
                ? 'लोकल IndexedDB (ऑफ़लाइन)'
                : 'Local IndexedDB (Offline)'
              : lang === 'hi'
                ? 'क्लाउड सिंक (Google)'
                : 'Cloud Sync (Google)'}
          </span>
        </div>
        <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
          {lang === 'hi'
            ? `आपके उत्पाद, बिक्री बिल, खरीद, ग्राहक उधार, सप्लायर और खर्च ऐप बंद करने के बाद भी सुरक्षित रहते हैं। नीचे से पूरा ${zipInfo.sizeMB} MB का सोर्स कोड + Capacitor Android प्रोजेक्ट (${zipInfo.fileCount} फ़ाइलें) सीधे डाउनलोड करें।`
            : `All products, bills, purchases, udhaar, suppliers, and expenses persist across app restarts. Download the complete ${zipInfo.sizeMB} MB Capacitor Android project (${zipInfo.fileCount} files) directly below.`}
        </p>
        <div className="flex flex-wrap items-center gap-2.5 pt-1">
          <button
            type="button"
            onClick={handleDownloadSourceZip}
            disabled={downloadingZip}
            className="inline-flex items-center gap-2 px-4 h-10 rounded-xl bg-emerald-700 hover:bg-emerald-800 disabled:opacity-75 text-white text-xs font-semibold cursor-pointer"
          >
            <FileArchive className="w-4 h-4" />
            {downloadingZip
              ? `${lang === 'hi' ? 'डाउनलोड हो रहा है' : 'Downloading'} ${zipProgress}`
              : lang === 'hi'
                ? `पूरा प्रोजेक्ट ZIP डाउनलोड करें (${zipInfo.sizeMB} MB)`
                : `Download Full Project ZIP (${zipInfo.sizeMB} MB)`}
          </button>

          <a
            href={SOURCE_ZIP_PATH}
            download="khataflow-dukaan-source.zip"
            className="inline-flex items-center gap-1.5 px-3.5 h-10 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-semibold"
          >
            <Download className="w-3.5 h-3.5" />
            {lang === 'hi' ? 'डायरेक्ट फ़ाइल लिंक' : 'Direct File Link'}
          </a>

          <button
            type="button"
            onClick={() => {
              void navigator.clipboard?.writeText(directZipUrl);
              setCopiedLink(true);
              notify(lang === 'hi' ? 'डायरेक्ट ZIP लिंक कॉपी हो गया!' : 'Direct ZIP link copied!');
              setTimeout(() => setCopiedLink(false), 2000);
            }}
            className="inline-flex items-center gap-1.5 px-3.5 h-10 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-semibold cursor-pointer"
          >
            {copiedLink ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
            {copiedLink ? (lang === 'hi' ? 'कॉपी हुआ' : 'Copied') : lang === 'hi' ? 'लिंक कॉपी' : 'Copy Link'}
          </button>
        </div>
      </section>

      {/* PIN Security & Backup / Restore */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-4">
          <div className="flex items-center gap-2">
            <Shield className="w-4 h-4 text-emerald-700" />
            <h3 className="font-bold text-sm">{lang === 'hi' ? 'ऐप पिन सुरक्षा (PIN Lock)' : 'App PIN Protection'}</h3>
          </div>
          <div className="flex gap-2">
            <input
              type="password"
              inputMode="numeric"
              maxLength={8}
              value={newPin}
              onChange={(e) => setNewPin(e.target.value)}
              placeholder={lang === 'hi' ? 'नया 4-8 अंकों का पिन' : 'New 4-8 digit PIN'}
              className="flex-1 h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono text-sm"
            />
            <button
              type="button"
              onClick={handleSetPin}
              className="px-4 h-11 rounded-xl bg-slate-900 dark:bg-slate-800 text-white text-xs font-semibold cursor-pointer inline-flex items-center gap-1.5"
            >
              <Lock className="w-3.5 h-3.5" />
              {lang === 'hi' ? 'सेट करें' : 'Set PIN'}
            </button>
          </div>
          {shopProfile?.pinHash && (
            <button
              type="button"
              onClick={handleRemovePin}
              className="text-xs font-semibold text-red-600 hover:underline cursor-pointer"
            >
              {lang === 'hi' ? 'मौजूदा पिन लॉक हटाएं' : 'Remove existing PIN lock'}
            </button>
          )}
        </section>

        <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-4">
          <h3 className="font-bold text-sm">{lang === 'hi' ? 'डेटा बैकअप और रीस्टोर' : 'Backup & Restore'}</h3>
          <p className="text-xs text-slate-500">
            {shopProfile?.lastBackupAt
              ? `${lang === 'hi' ? 'अंतिम बैकअप' : 'Last Backup'}: ${new Date(shopProfile.lastBackupAt).toLocaleString()}`
              : lang === 'hi'
                ? 'क्लाउड डेटा स्वचालित सहेजा जाता है। अतिरिक्त सुरक्षा के लिए JSON बैकअप डाउनलोड करें।'
                : 'Cloud data auto-saves. Download a JSON backup anytime for offline safety.'}
          </p>
          <div className="flex flex-wrap gap-2.5">
            <button
              type="button"
              disabled={busyBackup}
              onClick={handleExportBackup}
              className="inline-flex items-center gap-2 px-4 h-10 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold cursor-pointer"
            >
              <Download className="w-4 h-4" />
              {lang === 'hi' ? 'बैकअप डाउनलोड (JSON)' : 'Export Backup'}
            </button>
            <label className="inline-flex items-center gap-2 px-4 h-10 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-semibold cursor-pointer">
              <Upload className="w-4 h-4" />
              {lang === 'hi' ? 'बैकअप इम्पोर्ट करें' : 'Import Backup'}
              <input type="file" accept="application/json" onChange={handleImportBackup} className="hidden" />
            </label>
          </div>
        </section>
      </div>

      {/* Audit Logs */}
      <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="font-bold text-sm">{lang === 'hi' ? 'सिस्टम ऑडिट लॉग' : 'Recent Audit Logs'}</h3>
          <button
            type="button"
            onClick={logout}
            className="inline-flex items-center gap-1.5 px-3.5 h-9 rounded-xl border border-red-200 dark:border-red-900 text-red-600 text-xs font-semibold hover:bg-red-50 dark:hover:bg-red-950/30 cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" />
            {labels.logout}
          </button>
        </div>
        <div className="max-h-56 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800 text-xs">
          {auditLogs.slice(0, 30).map((log) => (
            <div key={log.id} className="py-2 flex items-center justify-between gap-3">
              <span className="font-mono font-semibold text-slate-700 dark:text-slate-300">{log.action}</span>
              <span className="text-slate-600 dark:text-slate-400 truncate flex-1">{log.summary}</span>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};
