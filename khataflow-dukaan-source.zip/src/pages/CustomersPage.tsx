import React, { useMemo, useState } from 'react';
import { Edit3, FileText, Plus, Search, Trash2, Users, X } from 'lucide-react';
import { useDukaan } from '../context/DukaanContext';
import { formatINR } from '../lib/formatters';
import { t } from '../lib/i18n';
import { deleteCustomer, saveCustomer } from '../services/dukaanService';
import { Customer } from '../types/dukaan';

export const CustomersPage: React.FC = () => {
  const {
    user,
    shopProfile,
    lang,
    customers,
    udhaarTransactions,
    notify,
    openPrintModal,
    setActiveSection,
  } = useDukaan();
  const labels = t(lang);

  const [search, setSearch] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [editId, setEditId] = useState('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [notes, setNotes] = useState('');
  const [initialUdhaar, setInitialUdhaar] = useState(0);
  const [saving, setSaving] = useState(false);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return customers;
    return customers.filter(
      (c) =>
        c.name.toLowerCase().includes(q) ||
        c.phone.includes(q) ||
        (c.address || '').toLowerCase().includes(q)
    );
  }, [customers, search]);

  const openAdd = () => {
    setEditId('');
    setName('');
    setPhone('');
    setAddress('');
    setNotes('');
    setInitialUdhaar(0);
    setModalOpen(true);
  };

  const openEdit = (c: Customer) => {
    setEditId(c.id);
    setName(c.name);
    setPhone(c.phone);
    setAddress(c.address || '');
    setNotes(c.notes || '');
    setInitialUdhaar(0);
    setModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || saving) return;
    if (!name.trim()) return;
    setSaving(true);
    try {
      await saveCustomer(user.uid, {
        id: editId || undefined,
        name,
        phone,
        address,
        notes,
        initialUdhaar,
      });
      notify(editId ? (lang === 'hi' ? 'ग्राहक अपडेट हुआ!' : 'Customer updated!') : (lang === 'hi' ? 'नया ग्राहक जुड़ गया!' : 'Customer added!'));
      setModalOpen(false);
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Save failed', 'error');
    } finally {
      setSaving(false);
    }
  };

  const printLedger = (c: Customer) => {
    const txs = udhaarTransactions.filter((u) => u.customerId === c.id);
    openPrintModal({
      title: `${lang === 'hi' ? 'ग्राहक खाता' : 'Customer Ledger'}: ${c.name}`,
      content: (
        <div className="space-y-4 text-sm text-slate-900">
          <div className="border-b border-slate-300 pb-3 flex justify-between">
            <div>
              <h2 className="text-lg font-bold">{shopProfile?.shopName}</h2>
              <p className="text-xs text-slate-600">{lang === 'hi' ? 'ग्राहक खाता बही' : 'Customer Ledger Statement'}</p>
            </div>
            <div className="text-right text-xs">
              <p className="font-bold text-sm">{c.name}</p>
              <p>{c.phone}</p>
              {c.address && <p>{c.address}</p>}
            </div>
          </div>
          <div className="grid grid-cols-3 gap-3 bg-slate-100 p-3 rounded-lg text-xs">
            <div>
              <p className="text-slate-500">{lang === 'hi' ? 'कुल उधार' : 'Total Udhaar'}</p>
              <p className="font-mono font-bold text-sm">{formatINR(c.totalUdhaar)}</p>
            </div>
            <div>
              <p className="text-slate-500">{lang === 'hi' ? 'जमा राशि' : 'Received'}</p>
              <p className="font-mono font-bold text-sm text-emerald-700">{formatINR(c.amountReceived)}</p>
            </div>
            <div>
              <p className="text-slate-500">{lang === 'hi' ? 'शेष बकाया' : 'Remaining'}</p>
              <p className="font-mono font-bold text-sm text-red-700">{formatINR(c.remainingBalance)}</p>
            </div>
          </div>
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-slate-300 text-left">
                <th className="py-2">{lang === 'hi' ? 'तिथि' : 'Date'}</th>
                <th className="py-2">{lang === 'hi' ? 'प्रकार' : 'Type'}</th>
                <th className="py-2">{lang === 'hi' ? 'विवरण' : 'Notes'}</th>
                <th className="py-2 text-right">{lang === 'hi' ? 'राशि' : 'Amount'}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {txs.map((tx) => (
                <tr key={tx.id}>
                  <td className="py-2 font-mono">{tx.txDate}</td>
                  <td className="py-2">{tx.type}</td>
                  <td className="py-2">{tx.notes || '-'}</td>
                  <td className="py-2 text-right font-mono font-semibold">{formatINR(tx.amount)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ),
    });
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="relative flex-1 min-w-[220px] max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={lang === 'hi' ? 'नाम या मोबाइल से खोजें...' : 'Search customer name or phone...'}
            className="w-full h-11 pl-10 pr-4 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm"
          />
        </div>
        <button
          type="button"
          onClick={openAdd}
          className="inline-flex items-center gap-2 px-4 h-11 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-sm font-semibold cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          {lang === 'hi' ? 'नया ग्राहक जोड़ें' : 'Add Customer'}
        </button>
      </div>

      {filtered.length === 0 ? (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-10 text-center space-y-3">
          <Users className="w-10 h-10 mx-auto text-slate-400" />
          <p className="text-sm text-slate-500">{labels.noData}</p>
        </div>
      ) : (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-left text-xs text-slate-500 bg-slate-50/70 dark:bg-slate-950/50">
                  <th className="py-3 px-4">{lang === 'hi' ? 'ग्राहक' : 'Customer'}</th>
                  <th className="py-3 px-3">{lang === 'hi' ? 'मोबाइल' : 'Phone'}</th>
                  <th className="py-3 px-3 text-right">{lang === 'hi' ? 'कुल उधार' : 'Total Udhaar'}</th>
                  <th className="py-3 px-3 text-right">{lang === 'hi' ? 'प्राप्त' : 'Received'}</th>
                  <th className="py-3 px-3 text-right">{lang === 'hi' ? 'शेष बकाया' : 'Balance'}</th>
                  <th className="py-3 px-4 text-right">{lang === 'hi' ? 'कार्रवाई' : 'Actions'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filtered.map((c) => (
                  <tr key={c.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                    <td className="py-3 px-4">
                      <p className="font-semibold">{c.name}</p>
                      {c.address && <p className="text-xs text-slate-500">{c.address}</p>}
                    </td>
                    <td className="py-3 px-3 font-mono text-xs">{c.phone || '-'}</td>
                    <td className="py-3 px-3 text-right font-mono tabular-nums">{formatINR(c.totalUdhaar)}</td>
                    <td className="py-3 px-3 text-right font-mono tabular-nums text-emerald-700 dark:text-emerald-400">
                      {formatINR(c.amountReceived)}
                    </td>
                    <td
                      className={`py-3 px-3 text-right font-mono tabular-nums font-bold ${
                        c.remainingBalance > 0 ? 'text-red-600' : 'text-emerald-700 dark:text-emerald-400'
                      }`}
                    >
                      {formatINR(c.remainingBalance)}
                    </td>
                    <td className="py-3 px-4 text-right whitespace-nowrap">
                      <button
                        type="button"
                        onClick={() => printLedger(c)}
                        title={lang === 'hi' ? 'खाता बही प्रिंट' : 'Ledger'}
                        className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                      >
                        <FileText className="w-4 h-4" />
                      </button>
                      <button
                        type="button"
                        onClick={() => setActiveSection('udhaar')}
                        className="px-2.5 h-8 rounded-lg text-xs font-semibold text-emerald-700 dark:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-950/30 cursor-pointer"
                      >
                        {lang === 'hi' ? 'लेन-देन' : 'Udhaar'}
                      </button>
                      <button
                        type="button"
                        onClick={() => openEdit(c)}
                        className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-sky-700 cursor-pointer"
                      >
                        <Edit3 className="w-4 h-4" />
                      </button>
                      <button
                        type="button"
                        onClick={async () => {
                          if (!user) return;
                          await deleteCustomer(user.uid, c.id);
                          notify(lang === 'hi' ? 'ग्राहक हटाया गया।' : 'Customer deleted.');
                        }}
                        className="p-2 rounded-lg hover:bg-red-50 dark:hover:bg-red-950 text-red-600 cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {modalOpen && (
        <div className="fixed inset-0 z-50 bg-black/55 backdrop-blur-sm flex items-center justify-center p-4">
          <form
            onSubmit={handleSave}
            className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-md w-full p-5 space-y-4"
          >
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-base">
                {editId ? (lang === 'hi' ? 'ग्राहक संपादित करें' : 'Edit Customer') : (lang === 'hi' ? 'नया ग्राहक' : 'New Customer')}
              </h3>
              <button
                type="button"
                onClick={() => setModalOpen(false)}
                className="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="space-y-3">
              <input
                required
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder={lang === 'hi' ? 'ग्राहक का नाम *' : 'Customer Name *'}
                className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm"
              />
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder={lang === 'hi' ? 'मोबाइल नंबर' : 'Phone Number'}
                className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono text-sm"
              />
              <input
                type="text"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder={lang === 'hi' ? 'पता (वैकल्पिक)' : 'Address (Optional)'}
                className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm"
              />
              {!editId && (
                <div>
                  <label className="block text-xs text-slate-500 mb-1">
                    {lang === 'hi' ? 'पिछला बकाया उधार (Opening Balance ₹)' : 'Opening Udhaar Balance (₹)'}
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="any"
                    value={initialUdhaar}
                    onChange={(e) => setInitialUdhaar(Number(e.target.value) || 0)}
                    className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono text-sm"
                  />
                </div>
              )}
            </div>
            <button
              type="submit"
              disabled={saving}
              className="w-full h-11 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-semibold text-sm cursor-pointer"
            >
              {saving ? '...' : labels.save}
            </button>
          </form>
        </div>
      )}
    </div>
  );
};
