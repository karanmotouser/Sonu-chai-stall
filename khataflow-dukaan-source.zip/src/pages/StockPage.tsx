import React, { useMemo, useState } from 'react';
import { AlertTriangle, ClipboardCheck, History, Search, Sliders, X } from 'lucide-react';
import { useDukaan } from '../context/DukaanContext';
import { formatINR, formatNumber, getTodayISO } from '../lib/formatters';
import { t } from '../lib/i18n';
import { adjustStock } from '../services/dukaanService';
import { Product } from '../types/dukaan';

type StockTab = 'all' | 'low' | 'out' | 'expiring' | 'history';

export const StockPage: React.FC = () => {
  const { user, lang, products, stockMovements, notify } = useDukaan();
  const labels = t(lang);

  const [tab, setTab] = useState<StockTab>('all');
  const [search, setSearch] = useState('');
  const [selectedProd, setSelectedProd] = useState<Product | null>(null);
  const [adjType, setAdjType] = useState<'adjustment' | 'damage' | 'expiry' | 'audit'>('audit');
  const [newStockQty, setNewStockQty] = useState(0);
  const [qtyDelta, setQtyDelta] = useState(0);
  const [reason, setReason] = useState('');
  const [saving, setSaving] = useState(false);

  const today = getTodayISO();

  const stats = useMemo(() => {
    const totalValuation = products.reduce(
      (s, p) => s + Math.max(0, p.stockQty) * p.purchasePrice,
      0
    );
    const lowStock = products.filter((p) => p.stockQty > 0 && p.stockQty <= p.minStockAlert);
    const outOfStock = products.filter((p) => p.stockQty <= 0);
    const expiring = products.filter((p) => {
      if (!p.expiryDate) return false;
      const diff =
        (new Date(p.expiryDate + 'T00:00:00').getTime() - new Date(today + 'T00:00:00').getTime()) /
        (1000 * 60 * 60 * 24);
      return diff <= 30;
    });
    const totalDamaged = products.reduce((s, p) => s + (p.damagedQty || 0), 0);
    return { totalValuation, lowStock, outOfStock, expiring, totalDamaged };
  }, [products, today]);

  const filteredProducts = useMemo(() => {
    const q = search.trim().toLowerCase();
    const base =
      tab === 'low'
        ? stats.lowStock
        : tab === 'out'
          ? stats.outOfStock
          : tab === 'expiring'
            ? stats.expiring
            : products;
    if (!q) return base;
    return base.filter(
      (p) =>
        p.name.toLowerCase().includes(q) ||
        p.category.toLowerCase().includes(q) ||
        (p.barcode || '').toLowerCase().includes(q)
    );
  }, [tab, stats, products, search]);

  const openAdjust = (p: Product, type: 'adjustment' | 'damage' | 'expiry' | 'audit') => {
    setSelectedProd(p);
    setAdjType(type);
    setNewStockQty(p.stockQty);
    setQtyDelta(0);
    setReason('');
  };

  const handleAdjustSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !selectedProd || saving) return;
    setSaving(true);
    try {
      await adjustStock(user.uid, {
        productId: selectedProd.id,
        type: adjType,
        newStockQty: adjType === 'audit' ? newStockQty : undefined,
        qtyDelta: adjType === 'audit' ? undefined : adjType === 'damage' || adjType === 'expiry' ? -Math.abs(qtyDelta) : qtyDelta,
        reason: reason.trim() || adjType,
        movementDate: today,
      });
      notify(lang === 'hi' ? 'स्टॉक सफलतापूर्वक अपडेट हुआ!' : 'Stock adjusted successfully!');
      setSelectedProd(null);
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Stock adjustment failed', 'error');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Valuation & Alert KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4">
          <p className="text-xs text-slate-500">{lang === 'hi' ? 'कुल स्टॉक मूल्य' : 'Total Stock Valuation'}</p>
          <p className="text-xl font-bold font-mono tabular-nums text-emerald-700 dark:text-emerald-400 mt-1">
            {formatINR(stats.totalValuation)}
          </p>
        </div>
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4">
          <p className="text-xs text-slate-500">{lang === 'hi' ? 'कम स्टॉक अलर्ट' : 'Low Stock'}</p>
          <p className="text-xl font-bold font-mono tabular-nums text-amber-600 mt-1">
            {formatNumber(stats.lowStock.length)}
          </p>
        </div>
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4">
          <p className="text-xs text-slate-500">{lang === 'hi' ? 'स्टॉक खत्म (Out of Stock)' : 'Out of Stock'}</p>
          <p className="text-xl font-bold font-mono tabular-nums text-red-600 mt-1">
            {formatNumber(stats.outOfStock.length)}
          </p>
        </div>
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4">
          <p className="text-xs text-slate-500">{lang === 'hi' ? 'खराब / क्षतिग्रस्त' : 'Damaged Units'}</p>
          <p className="text-xl font-bold font-mono tabular-nums text-slate-800 dark:text-slate-200 mt-1">
            {formatNumber(stats.totalDamaged)}
          </p>
        </div>
      </div>

      {/* Tabs & Search */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-100 dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800">
          {(
            [
              ['all', lang === 'hi' ? 'सभी स्टॉक' : 'All Stock'],
              ['low', `${lang === 'hi' ? 'कम स्टॉक' : 'Low'} (${stats.lowStock.length})`],
              ['out', `${lang === 'hi' ? 'खत्म' : 'Out'} (${stats.outOfStock.length})`],
              ['expiring', `${lang === 'hi' ? 'एक्सपायरी' : 'Expiring'} (${stats.expiring.length})`],
              ['history', lang === 'hi' ? 'आवक/जावक इतिहास' : 'Stock Movements'],
            ] as [StockTab, string][]
          ).map(([id, label]) => (
            <button
              key={id}
              type="button"
              onClick={() => setTab(id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                tab === id
                  ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 shadow-sm'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              {label}
            </button>
          ))}
        </div>

        <div className="relative w-full sm:w-64">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={labels.search}
            className="w-full h-10 pl-9 pr-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm"
          />
        </div>
      </div>

      {/* Table Content */}
      {tab !== 'history' ? (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-left text-xs text-slate-500 bg-slate-50/70 dark:bg-slate-950/50">
                  <th className="py-3 px-4">{lang === 'hi' ? 'उत्पाद' : 'Product'}</th>
                  <th className="py-3 px-3 text-right">{lang === 'hi' ? 'वर्तमान स्टॉक' : 'Current Stock'}</th>
                  <th className="py-3 px-3 text-right">{lang === 'hi' ? 'खराब' : 'Damaged'}</th>
                  <th className="py-3 px-3 text-right">{lang === 'hi' ? 'स्टॉक मूल्य' : 'Valuation'}</th>
                  <th className="py-3 px-3">{lang === 'hi' ? 'एक्सपायरी' : 'Expiry'}</th>
                  <th className="py-3 px-4 text-right">{lang === 'hi' ? 'ऑडिट / समायोजन' : 'Audit / Adjust'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filteredProducts.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-8 text-center text-slate-500">
                      {labels.noData}
                    </td>
                  </tr>
                ) : (
                  filteredProducts.map((p) => (
                    <tr key={p.id}>
                      <td className="py-3 px-4">
                        <p className="font-semibold">{p.name}</p>
                        <p className="text-xs text-slate-500">
                          {p.category} · {lang === 'hi' ? 'न्यूनतम' : 'Min'}: {p.minStockAlert} {p.unit}
                        </p>
                      </td>
                      <td
                        className={`py-3 px-3 text-right font-mono tabular-nums font-bold ${
                          p.stockQty <= 0
                            ? 'text-red-600'
                            : p.stockQty <= p.minStockAlert
                              ? 'text-amber-600'
                              : 'text-emerald-700 dark:text-emerald-400'
                        }`}
                      >
                        {p.stockQty} {p.unit}
                      </td>
                      <td className="py-3 px-3 text-right font-mono tabular-nums text-slate-500">
                        {p.damagedQty || 0}
                      </td>
                      <td className="py-3 px-3 text-right font-mono tabular-nums font-medium">
                        {formatINR(Math.max(0, p.stockQty) * p.purchasePrice)}
                      </td>
                      <td className="py-3 px-3 font-mono text-xs text-slate-500">
                        {p.expiryDate || '-'}
                      </td>
                      <td className="py-3 px-4 text-right whitespace-nowrap">
                        <div className="inline-flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => openAdjust(p, 'audit')}
                            className="inline-flex items-center gap-1 px-2.5 h-8 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-medium hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                          >
                            <ClipboardCheck className="w-3.5 h-3.5" />
                            {lang === 'hi' ? 'ऑडिट' : 'Audit'}
                          </button>
                          <button
                            type="button"
                            onClick={() => openAdjust(p, 'damage')}
                            className="inline-flex items-center gap-1 px-2.5 h-8 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-medium text-amber-700 dark:text-amber-400 hover:bg-amber-50 dark:hover:bg-amber-950/30 cursor-pointer"
                          >
                            <AlertTriangle className="w-3.5 h-3.5" />
                            {lang === 'hi' ? 'क्षति' : 'Damage'}
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-left text-xs text-slate-500 bg-slate-50/70 dark:bg-slate-950/50">
                  <th className="py-3 px-4">{lang === 'hi' ? 'तिथि' : 'Date'}</th>
                  <th className="py-3 px-3">{lang === 'hi' ? 'उत्पाद' : 'Product'}</th>
                  <th className="py-3 px-3">{lang === 'hi' ? 'प्रकार' : 'Type'}</th>
                  <th className="py-3 px-3 text-right">{lang === 'hi' ? 'बदलाव' : 'Change'}</th>
                  <th className="py-3 px-3 text-right">{lang === 'hi' ? 'पहले -> बाद' : 'Before -> After'}</th>
                  <th className="py-3 px-4">{lang === 'hi' ? 'कारण' : 'Reason'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {stockMovements.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-8 text-center text-slate-500">
                      <History className="w-6 h-6 mx-auto mb-1 opacity-50" />
                      {labels.noData}
                    </td>
                  </tr>
                ) : (
                  stockMovements.slice(0, 100).map((m) => (
                    <tr key={m.id}>
                      <td className="py-2.5 px-4 font-mono text-xs text-slate-500 whitespace-nowrap">
                        {m.movementDate}
                      </td>
                      <td className="py-2.5 px-3 font-medium">{m.productName}</td>
                      <td className="py-2.5 px-3 text-xs text-slate-600 dark:text-slate-400">
                        {m.type}
                      </td>
                      <td
                        className={`py-2.5 px-3 text-right font-mono tabular-nums font-bold ${
                          m.qtyChange > 0
                            ? 'text-emerald-700 dark:text-emerald-400'
                            : m.qtyChange < 0
                              ? 'text-red-600'
                              : 'text-slate-500'
                        }`}
                      >
                        {m.qtyChange > 0 ? `+${m.qtyChange}` : m.qtyChange}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono tabular-nums text-xs">
                        {m.stockBefore} → {m.stockAfter}
                      </td>
                      <td className="py-2.5 px-4 text-xs text-slate-500">{m.reason}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Stock Adjustment / Audit / Damage Modal */}
      {selectedProd && (
        <div className="fixed inset-0 z-50 bg-black/55 backdrop-blur-sm flex items-center justify-center p-4">
          <form
            onSubmit={handleAdjustSubmit}
            className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-md w-full p-5 space-y-4"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Sliders className="w-4 h-4 text-emerald-700" />
                <h3 className="font-bold text-base">{selectedProd.name}</h3>
              </div>
              <button
                type="button"
                onClick={() => setSelectedProd(null)}
                className="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2">
              {(['audit', 'adjustment', 'damage', 'expiry'] as const).map((tKey) => (
                <button
                  key={tKey}
                  type="button"
                  onClick={() => setAdjType(tKey)}
                  className={`h-9 rounded-xl text-xs font-semibold border cursor-pointer ${
                    adjType === tKey
                      ? 'bg-emerald-700 border-emerald-700 text-white'
                      : 'border-slate-200 dark:border-slate-700'
                  }`}
                >
                  {tKey === 'audit'
                    ? lang === 'hi'
                      ? 'भौतिक ऑडिट'
                      : 'Physical Audit'
                    : tKey === 'adjustment'
                      ? lang === 'hi'
                        ? 'स्टॉक समायोजन'
                        : 'Adjustment'
                      : tKey === 'damage'
                        ? lang === 'hi'
                          ? 'क्षतिग्रस्त माल'
                          : 'Damaged'
                        : lang === 'hi'
                          ? 'एक्सपायरी'
                          : 'Expired'}
                </button>
              ))}
            </div>

            {adjType === 'audit' ? (
              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                  {lang === 'hi'
                    ? `वास्तविक गिना गया स्टॉक (वर्तमान: ${selectedProd.stockQty})`
                    : `Physical Counted Stock (Current: ${selectedProd.stockQty})`}
                </label>
                <input
                  type="number"
                  step="any"
                  value={newStockQty}
                  onChange={(e) => setNewStockQty(Number(e.target.value) || 0)}
                  className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono text-sm"
                />
              </div>
            ) : (
              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                  {adjType === 'adjustment'
                    ? lang === 'hi'
                      ? 'मात्रा जोड़ें/घटाएं (+/-)'
                      : 'Quantity Change (+/-)'
                    : lang === 'hi'
                      ? 'खराब / एक्सपायर मात्रा'
                      : 'Damaged / Expired Qty'}
                </label>
                <input
                  type="number"
                  step="any"
                  value={qtyDelta}
                  onChange={(e) => setQtyDelta(Number(e.target.value) || 0)}
                  className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono text-sm"
                />
              </div>
            )}

            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                {lang === 'hi' ? 'कारण / टिप्पणी' : 'Reason / Notes'}
              </label>
              <input
                required
                type="text"
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                placeholder={lang === 'hi' ? 'जैसे: गोदाम गिनती, टूटा पैकेट...' : 'e.g., Shelf count, torn packet'}
                className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm"
              />
            </div>

            <button
              type="submit"
              disabled={saving}
              className="w-full h-11 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-semibold text-sm cursor-pointer"
            >
              {saving ? '...' : labels.save}
            </button>
          </form>
        </div>
      )}
    </div>
  );
};
