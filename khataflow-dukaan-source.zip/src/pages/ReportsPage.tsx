import React, { useMemo, useState } from 'react';
import { FileSpreadsheet, Printer, Search } from 'lucide-react';
import { useDukaan } from '../context/DukaanContext';
import {
  exportToExcel,
  formatINR,
  getMonthPrefix,
  getTodayISO,
  getYearPrefix,
  isWithinLastDays,
} from '../lib/formatters';
import { t } from '../lib/i18n';

export const ReportsPage: React.FC = () => {
  const {
    lang,
    shopProfile,
    bills,
    purchases,
    expenses,
    customers,
    suppliers,
    products,
    priceHistory,
    cashbookEntries,
    openPrintModal,
  } = useDukaan();

  const labels = t(lang);
  const today = getTodayISO();
  const monthPrefix = getMonthPrefix(today);
  const yearPrefix = getYearPrefix(today);

  const [fromDate, setFromDate] = useState(monthPrefix + '-01');
  const [toDate, setToDate] = useState(today);
  const [searchFilter, setSearchFilter] = useState('');
  const [plPeriod, setPlPeriod] = useState<'day' | 'week' | 'month' | 'year' | 'custom'>('month');

  // Profit & Loss computation using exact COGS (purchasePriceAtSale) and excluding unpaid credit from cash received
  const plStats = useMemo(() => {
    const matchPeriod = (d: string) => {
      if (plPeriod === 'day') return d === today;
      if (plPeriod === 'week') return isWithinLastDays(d, 7);
      if (plPeriod === 'month') return d.startsWith(monthPrefix);
      if (plPeriod === 'year') return d.startsWith(yearPrefix);
      return d >= fromDate && d <= toDate;
    };

    const periodBills = bills.filter((b) => b.status !== 'cancelled' && matchPeriod(b.billDate));
    const periodExpenses = expenses.filter((e) => matchPeriod(e.expenseDate));

    const totalBilledRevenue = periodBills.reduce((s, b) => s + (b.totalAmount - b.gstAmount), 0);
    const totalGstCollected = periodBills.reduce((s, b) => s + b.gstAmount, 0);
    const totalCogs = periodBills.reduce((s, b) => s + b.totalCost, 0);
    const grossProfit = totalBilledRevenue - totalCogs;
    const totalExp = periodExpenses.reduce((s, e) => s + e.amount, 0);
    const netProfit = grossProfit - totalExp;
    const actualCashAndOnlineReceived = periodBills.reduce((s, b) => s + b.paidAmount, 0);
    const unpaidCreditInSales = periodBills.reduce((s, b) => s + b.creditAmount, 0);

    // Product-wise profit map
    const prodProfitMap = new Map<string, { name: string; qty: number; revenue: number; cost: number; profit: number }>();
    periodBills.forEach((b) => {
      b.items.forEach((item) => {
        const cur = prodProfitMap.get(item.productId) || {
          name: item.productName,
          qty: 0,
          revenue: 0,
          cost: 0,
          profit: 0,
        };
        const rev = item.lineTotal - item.gstAmount;
        const cost = item.purchasePriceAtSale * item.qty;
        cur.qty += item.qty;
        cur.revenue += rev;
        cur.cost += cost;
        cur.profit += rev - cost;
        prodProfitMap.set(item.productId, cur);
      });
    });

    const productWise = Array.from(prodProfitMap.values()).sort((a, b) => b.profit - a.profit);

    return {
      totalBilledRevenue,
      totalGstCollected,
      totalCogs,
      grossProfit,
      totalExp,
      netProfit,
      actualCashAndOnlineReceived,
      unpaidCreditInSales,
      productWise,
    };
  }, [bills, expenses, plPeriod, today, monthPrefix, yearPrefix, fromDate, toDate]);

  const inRange = (d: string) => d >= fromDate && d <= toDate;
  const q = searchFilter.trim().toLowerCase();

  const triggerPdfPrint = (title: string, columns: string[], rows: (string | number)[][]) => {
    openPrintModal({
      title,
      content: (
        <div className="space-y-4 text-xs text-slate-900">
          <div className="border-b border-slate-300 pb-3 flex justify-between">
            <div>
              <h2 className="text-base font-bold">{shopProfile?.shopName}</h2>
              <p className="font-semibold text-sm mt-0.5">{title}</p>
            </div>
            <div className="text-right font-mono">
              <p>{fromDate} → {toDate}</p>
            </div>
          </div>
          <table className="w-full border-collapse">
            <thead>
              <tr className="border-b border-slate-300 text-left">
                {columns.map((c, idx) => (
                  <th key={idx} className="py-2 pr-2 font-bold">
                    {c}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {rows.map((r, rIdx) => (
                <tr key={rIdx}>
                  {r.map((cell, cIdx) => (
                    <td key={cIdx} className="py-1.5 pr-2 font-mono">
                      {cell}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ),
    });
  };

  // All 10 Requested Report Generators (Excel + Printable PDF)
  const reportCards = [
    {
      id: 'daily_sales',
      title: lang === 'hi' ? '1. दैनिक बिक्री रिपोर्ट' : '1. Daily Sales Report',
      onExcel: () => {
        const rows = bills
          .filter((b) => b.billDate === today && (!q || b.customerName.toLowerCase().includes(q) || b.billNumber.toLowerCase().includes(q)))
          .map((b) => ({
            BillNo: b.billNumber,
            Date: b.billDate,
            Customer: b.customerName,
            Total: b.totalAmount,
            Paid: b.paidAmount,
            Credit: b.creditAmount,
            GrossProfit: b.grossProfit,
            Status: b.status,
          }));
        exportToExcel(`Daily_Sales_${today}`, 'DailySales', rows);
      },
      onPdf: () => {
        const list = bills.filter((b) => b.billDate === today);
        triggerPdfPrint(
          lang === 'hi' ? 'दैनिक बिक्री रिपोर्ट' : 'Daily Sales Report',
          ['Bill #', 'Customer', 'Total', 'Paid', 'Credit', 'Profit'],
          list.map((b) => [b.billNumber, b.customerName, formatINR(b.totalAmount), formatINR(b.paidAmount), formatINR(b.creditAmount), formatINR(b.grossProfit)])
        );
      },
    },
    {
      id: 'monthly_sales',
      title: lang === 'hi' ? '2. मासिक / तिथि बिक्री रिपोर्ट' : '2. Monthly / Date Range Sales',
      onExcel: () => {
        const rows = bills
          .filter((b) => inRange(b.billDate) && (!q || b.customerName.toLowerCase().includes(q)))
          .map((b) => ({
            BillNo: b.billNumber,
            Date: b.billDate,
            Customer: b.customerName,
            Subtotal: b.subtotal,
            GST: b.gstAmount,
            Total: b.totalAmount,
            Paid: b.paidAmount,
            Credit: b.creditAmount,
            Status: b.status,
          }));
        exportToExcel(`Sales_${fromDate}_to_${toDate}`, 'Sales', rows);
      },
      onPdf: () => {
        const list = bills.filter((b) => inRange(b.billDate));
        triggerPdfPrint(
          lang === 'hi' ? 'बिक्री रिपोर्ट' : 'Sales Report',
          ['Date', 'Bill #', 'Customer', 'Total', 'Paid', 'Status'],
          list.map((b) => [b.billDate, b.billNumber, b.customerName, formatINR(b.totalAmount), formatINR(b.paidAmount), b.status])
        );
      },
    },
    {
      id: 'purchases',
      title: lang === 'hi' ? '3. खरीद (Purchase) रिपोर्ट' : '3. Purchase Report',
      onExcel: () => {
        const rows = purchases
          .filter((p) => inRange(p.purchaseDate) && (!q || p.supplierName.toLowerCase().includes(q)))
          .map((p) => ({
            PurchaseNo: p.purchaseNumber,
            Date: p.purchaseDate,
            Supplier: p.supplierName,
            Total: p.totalAmount,
            Paid: p.paidAmount,
            Due: p.remainingAmount,
            Status: p.status,
          }));
        exportToExcel(`Purchases_${fromDate}_to_${toDate}`, 'Purchases', rows);
      },
      onPdf: () => {
        const list = purchases.filter((p) => inRange(p.purchaseDate));
        triggerPdfPrint(
          lang === 'hi' ? 'खरीद रिपोर्ट' : 'Purchase Report',
          ['Date', 'Pur #', 'Supplier', 'Total', 'Paid', 'Due'],
          list.map((p) => [p.purchaseDate, p.purchaseNumber, p.supplierName, formatINR(p.totalAmount), formatINR(p.paidAmount), formatINR(p.remainingAmount)])
        );
      },
    },
    {
      id: 'profit_loss',
      title: lang === 'hi' ? '4. लाभ-हानि (Profit & Loss)' : '4. Profit & Loss Report',
      onExcel: () => {
        exportToExcel(`Profit_Loss_${today}`, 'ProfitAndLoss', [
          { Metric: 'Total Revenue (Excl GST)', Amount: plStats.totalBilledRevenue },
          { Metric: 'Cost of Goods Sold (COGS)', Amount: plStats.totalCogs },
          { Metric: 'Gross Profit', Amount: plStats.grossProfit },
          { Metric: 'Operating Expenses', Amount: plStats.totalExp },
          { Metric: 'Net Profit', Amount: plStats.netProfit },
          { Metric: 'Actual Cash & Online Received', Amount: plStats.actualCashAndOnlineReceived },
          { Metric: 'Unpaid Customer Credit', Amount: plStats.unpaidCreditInSales },
        ]);
      },
      onPdf: () => {
        triggerPdfPrint(
          lang === 'hi' ? 'लाभ-हानि विवरण (P&L)' : 'Profit & Loss Statement',
          ['Metric', 'Amount'],
          [
            ['Revenue (Excl GST)', formatINR(plStats.totalBilledRevenue)],
            ['Cost of Goods Sold', formatINR(plStats.totalCogs)],
            ['Gross Profit', formatINR(plStats.grossProfit)],
            ['Expenses', formatINR(plStats.totalExp)],
            ['Net Profit', formatINR(plStats.netProfit)],
            ['Cash/Online Received', formatINR(plStats.actualCashAndOnlineReceived)],
          ]
        );
      },
    },
    {
      id: 'expenses',
      title: lang === 'hi' ? '5. खर्च (Expense) रिपोर्ट' : '5. Expense Report',
      onExcel: () => {
        const rows = expenses
          .filter((e) => inRange(e.expenseDate) && (!q || e.title.toLowerCase().includes(q)))
          .map((e) => ({
            Date: e.expenseDate,
            Category: e.category,
            Title: e.title,
            Mode: e.paymentMode,
            Amount: e.amount,
          }));
        exportToExcel(`Expenses_${fromDate}_to_${toDate}`, 'Expenses', rows);
      },
      onPdf: () => {
        const list = expenses.filter((e) => inRange(e.expenseDate));
        triggerPdfPrint(
          lang === 'hi' ? 'खर्च रिपोर्ट' : 'Expense Report',
          ['Date', 'Category', 'Title', 'Mode', 'Amount'],
          list.map((e) => [e.expenseDate, e.category, e.title, e.paymentMode, formatINR(e.amount)])
        );
      },
    },
    {
      id: 'udhaar',
      title: lang === 'hi' ? '6. ग्राहक उधार रिपोर्ट' : '6. Customer Udhaar Report',
      onExcel: () => {
        const rows = customers
          .filter((c) => !q || c.name.toLowerCase().includes(q))
          .map((c) => ({
            Customer: c.name,
            Phone: c.phone,
            TotalUdhaar: c.totalUdhaar,
            Received: c.amountReceived,
            RemainingBalance: c.remainingBalance,
          }));
        exportToExcel(`Customer_Udhaar_${today}`, 'CustomerUdhaar', rows);
      },
      onPdf: () => {
        triggerPdfPrint(
          lang === 'hi' ? 'ग्राहक उधार रिपोर्ट' : 'Customer Udhaar Report',
          ['Customer', 'Phone', 'Total', 'Received', 'Balance'],
          customers.map((c) => [c.name, c.phone, formatINR(c.totalUdhaar), formatINR(c.amountReceived), formatINR(c.remainingBalance)])
        );
      },
    },
    {
      id: 'suppliers',
      title: lang === 'hi' ? '7. सप्लायर बकाया रिपोर्ट' : '7. Supplier Outstanding Report',
      onExcel: () => {
        const rows = suppliers
          .filter((s) => !q || s.name.toLowerCase().includes(q))
          .map((s) => ({
            Supplier: s.name,
            Phone: s.phone,
            TotalPurchases: s.totalPurchases,
            TotalPaid: s.totalPaid,
            RemainingOutstanding: s.remainingOutstanding,
          }));
        exportToExcel(`Supplier_Outstanding_${today}`, 'Suppliers', rows);
      },
      onPdf: () => {
        triggerPdfPrint(
          lang === 'hi' ? 'सप्लायर बकाया रिपोर्ट' : 'Supplier Outstanding Report',
          ['Supplier', 'Phone', 'Purchases', 'Paid', 'Outstanding'],
          suppliers.map((s) => [s.name, s.phone, formatINR(s.totalPurchases), formatINR(s.totalPaid), formatINR(s.remainingOutstanding)])
        );
      },
    },
    {
      id: 'stock',
      title: lang === 'hi' ? '8. स्टॉक एवं मूल्यांकन रिपोर्ट' : '8. Stock Valuation Report',
      onExcel: () => {
        const rows = products
          .filter((p) => !q || p.name.toLowerCase().includes(q))
          .map((p) => ({
            Product: p.name,
            Category: p.category,
            StockQty: p.stockQty,
            Unit: p.unit,
            PurchasePrice: p.purchasePrice,
            SellingPrice: p.sellingPrice,
            StockValue: Math.max(0, p.stockQty) * p.purchasePrice,
          }));
        exportToExcel(`Stock_Report_${today}`, 'Stock', rows);
      },
      onPdf: () => {
        triggerPdfPrint(
          lang === 'hi' ? 'स्टॉक रिपोर्ट' : 'Stock Report',
          ['Product', 'Stock', 'Purchase', 'Selling', 'Value'],
          products.map((p) => [p.name, `${p.stockQty} ${p.unit}`, formatINR(p.purchasePrice), formatINR(p.sellingPrice), formatINR(Math.max(0, p.stockQty) * p.purchasePrice)])
        );
      },
    },
    {
      id: 'price_history',
      title: lang === 'hi' ? '9. मूल्य परिवर्तन इतिहास' : '9. Price Change History Report',
      onExcel: () => {
        const rows = priceHistory
          .filter((h) => !q || h.productName.toLowerCase().includes(q))
          .map((h) => ({
            Product: h.productName,
            PriceType: h.priceType,
            PreviousPrice: h.previousPrice,
            NewPrice: h.newPrice,
            MarginPercent: h.profitMarginPercent,
            Reason: h.changeReason,
          }));
        exportToExcel(`Price_History_${today}`, 'PriceHistory', rows);
      },
      onPdf: () => {
        triggerPdfPrint(
          lang === 'hi' ? 'मूल्य परिवर्तन इतिहास' : 'Price Change History',
          ['Product', 'Type', 'Old', 'New', 'Margin%', 'Reason'],
          priceHistory.slice(0, 100).map((h) => [h.productName, h.priceType, formatINR(h.previousPrice), formatINR(h.newPrice), `${h.profitMarginPercent}%`, h.changeReason])
        );
      },
    },
    {
      id: 'cashflow',
      title: lang === 'hi' ? '10. कैश फ्लो (Cash Flow) रिपोर्ट' : '10. Cash Flow Report',
      onExcel: () => {
        const rows = cashbookEntries
          .filter((c) => inRange(c.entryDate))
          .map((c) => ({
            Date: c.entryDate,
            Direction: c.direction,
            Category: c.category,
            Mode: c.paymentMode,
            Amount: c.amount,
            Description: c.description,
          }));
        exportToExcel(`CashFlow_${fromDate}_to_${toDate}`, 'CashFlow', rows);
      },
      onPdf: () => {
        const list = cashbookEntries.filter((c) => inRange(c.entryDate));
        triggerPdfPrint(
          lang === 'hi' ? 'कैश फ्लो रिपोर्ट' : 'Cash Flow Report',
          ['Date', 'In/Out', 'Mode', 'Description', 'Amount'],
          list.map((c) => [c.entryDate, c.direction.toUpperCase(), c.paymentMode.toUpperCase(), c.description, formatINR(c.amount)])
        );
      },
    },
  ];

  return (
    <div className="space-y-8">
      {/* P&L Period Switcher & Statement */}
      <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h2 className="text-base font-bold">
            {lang === 'hi' ? 'लाभ एवं हानि गणना (Profit & Loss)' : 'Profit & Loss Statement'}
          </h2>
          <div className="flex flex-wrap gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl">
            {(
              [
                ['day', labels.day],
                ['week', labels.week],
                ['month', labels.month],
                ['year', labels.year],
                ['custom', lang === 'hi' ? 'कस्टम तिथि' : 'Custom'],
              ] as const
            ).map(([k, l]) => (
              <button
                key={k}
                type="button"
                onClick={() => setPlPeriod(k)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer ${
                  plPeriod === k ? 'bg-white dark:bg-slate-900 shadow-sm' : 'text-slate-600 dark:text-slate-400'
                }`}
              >
                {l}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-950">
            <p className="text-xs text-slate-500">{lang === 'hi' ? 'कुल बिक्री (Revenue)' : 'Revenue (Excl GST)'}</p>
            <p className="text-base font-bold font-mono tabular-nums mt-1">
              {formatINR(plStats.totalBilledRevenue)}
            </p>
          </div>
          <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-950">
            <p className="text-xs text-slate-500">{lang === 'hi' ? 'माल की लागत (COGS)' : 'Cost of Goods (COGS)'}</p>
            <p className="text-base font-bold font-mono tabular-nums mt-1">
              {formatINR(plStats.totalCogs)}
            </p>
          </div>
          <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-950">
            <p className="text-xs text-slate-500">{lang === 'hi' ? 'सकल लाभ (Gross)' : 'Gross Profit'}</p>
            <p className="text-base font-bold font-mono tabular-nums text-emerald-700 dark:text-emerald-400 mt-1">
              {formatINR(plStats.grossProfit)}
            </p>
          </div>
          <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-950">
            <p className="text-xs text-slate-500">{lang === 'hi' ? 'कुल खर्च' : 'Total Expenses'}</p>
            <p className="text-base font-bold font-mono tabular-nums text-red-600 mt-1">
              {formatINR(plStats.totalExp)}
            </p>
          </div>
          <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-950">
            <p className="text-xs text-slate-500">{lang === 'hi' ? 'शुद्ध लाभ (Net Profit)' : 'Net Profit'}</p>
            <p
              className={`text-base font-bold font-mono tabular-nums mt-1 ${
                plStats.netProfit >= 0 ? 'text-emerald-700 dark:text-emerald-400' : 'text-red-600'
              }`}
            >
              {formatINR(plStats.netProfit)}
            </p>
          </div>
          <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-950">
            <p className="text-xs text-slate-500">{lang === 'hi' ? 'नकद/ऑनलाइन प्राप्त' : 'Cash/Online Recd'}</p>
            <p className="text-base font-bold font-mono tabular-nums text-sky-700 dark:text-sky-400 mt-1">
              {formatINR(plStats.actualCashAndOnlineReceived)}
            </p>
          </div>
        </div>

        {/* Product-wise Profit Table */}
        {plStats.productWise.length > 0 && (
          <div className="overflow-x-auto pt-2">
            <h3 className="text-xs font-bold text-slate-500 mb-2">
              {lang === 'hi' ? 'उत्पाद-वार लाभ (Product-wise Profit)' : 'Product-wise Profit Breakdown'}
            </h3>
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-left text-xs text-slate-500">
                  <th className="py-2 pr-3">{lang === 'hi' ? 'उत्पाद' : 'Product'}</th>
                  <th className="py-2 pr-3 text-right">{lang === 'hi' ? 'बिक्री मात्रा' : 'Sold Qty'}</th>
                  <th className="py-2 pr-3 text-right">{lang === 'hi' ? 'बिक्री' : 'Revenue'}</th>
                  <th className="py-2 pr-3 text-right">{lang === 'hi' ? 'लागत' : 'Cost'}</th>
                  <th className="py-2 text-right">{lang === 'hi' ? 'लाभ' : 'Profit'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {plStats.productWise.slice(0, 15).map((pw, idx) => (
                  <tr key={idx}>
                    <td className="py-2 pr-3 font-medium">{pw.name}</td>
                    <td className="py-2 pr-3 text-right font-mono">{pw.qty}</td>
                    <td className="py-2 pr-3 text-right font-mono">{formatINR(pw.revenue)}</td>
                    <td className="py-2 pr-3 text-right font-mono">{formatINR(pw.cost)}</td>
                    <td
                      className={`py-2 text-right font-mono font-bold ${
                        pw.profit >= 0 ? 'text-emerald-700 dark:text-emerald-400' : 'text-red-600'
                      }`}
                    >
                      {formatINR(pw.profit)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>

      {/* Downloadable PDF & Excel Reports with Date & Search Filters */}
      <section className="space-y-4">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 flex flex-wrap items-end justify-between gap-3">
          <div className="flex flex-wrap items-end gap-3">
            <div>
              <label className="block text-[11px] text-slate-500">{lang === 'hi' ? 'प्रारंभ तिथि' : 'From Date'}</label>
              <input
                type="date"
                value={fromDate}
                onChange={(e) => setFromDate(e.target.value)}
                className="h-10 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono text-xs"
              />
            </div>
            <div>
              <label className="block text-[11px] text-slate-500">{lang === 'hi' ? 'अंतिम तिथि' : 'To Date'}</label>
              <input
                type="date"
                value={toDate}
                onChange={(e) => setToDate(e.target.value)}
                className="h-10 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono text-xs"
              />
            </div>
          </div>

          <div className="relative w-full sm:w-72">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
            <input
              type="text"
              value={searchFilter}
              onChange={(e) => setSearchFilter(e.target.value)}
              placeholder={lang === 'hi' ? 'रिपोर्ट डेटा फ़िल्टर करें...' : 'Filter report records...'}
              className="w-full h-10 pl-9 pr-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-xs"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
          {reportCards.map((rc) => (
            <div
              key={rc.id}
              className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 flex items-center justify-between gap-3"
            >
              <p className="font-semibold text-sm">{rc.title}</p>
              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={rc.onExcel}
                  className="inline-flex items-center gap-1.5 px-3 h-9 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold cursor-pointer whitespace-nowrap"
                >
                  <FileSpreadsheet className="w-3.5 h-3.5" />
                  Excel
                </button>
                <button
                  type="button"
                  onClick={rc.onPdf}
                  className="inline-flex items-center gap-1.5 px-3 h-9 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-semibold cursor-pointer whitespace-nowrap"
                >
                  <Printer className="w-3.5 h-3.5" />
                  PDF
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};
