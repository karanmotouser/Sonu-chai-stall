import React, { useMemo } from 'react';
import {
  AlertTriangle,
  ArrowDownRight,
  ArrowUpRight,
  Boxes,
  CreditCard,
  IndianRupee,
  Package,
  Plus,
  Receipt,
  ShoppingBag,
  TrendingUp,
  Truck,
  Wallet,
} from 'lucide-react';
import { DashboardInstallCard } from '../components/PWAInstallBanner';
import { useDukaan } from '../context/DukaanContext';
import { formatDisplayDate, formatINR, formatNumber, getMonthPrefix, getTodayISO } from '../lib/formatters';
import { t } from '../lib/i18n';

export const DashboardPage: React.FC = () => {
  const {
    lang,
    products,
    bills,
    purchases,
    customers,
    suppliers,
    expenses,
    cashbookEntries,
    setActiveSection,
    dataLoading,
  } = useDukaan();

  const labels = t(lang);
  const today = getTodayISO();
  const currentMonth = getMonthPrefix(today);

  const metrics = useMemo(() => {
    const activeBills = bills.filter((b) => b.status !== 'cancelled');
    const todayBills = activeBills.filter((b) => b.billDate === today);
    const activePurchases = purchases.filter((p) => p.status !== 'cancelled');
    const todayPurchases = activePurchases.filter((p) => p.purchaseDate === today);
    const todayExpenses = expenses.filter((e) => e.expenseDate === today);
    const monthExpenses = expenses.filter((e) => e.expenseDate.startsWith(currentMonth));

    const todaySalesTotal = todayBills.reduce((s, b) => s + b.totalAmount, 0);
    const todayGrossProfit = todayBills.reduce((s, b) => s + b.grossProfit, 0);
    const todayExpensesTotal = todayExpenses.reduce((s, e) => s + e.amount, 0);
    const monthExpensesTotal = monthExpenses.reduce((s, e) => s + e.amount, 0);
    const todayNetProfit = todayGrossProfit - todayExpensesTotal;
    const todayPurchasesTotal = todayPurchases.reduce((s, p) => s + p.totalAmount, 0);

    // Cash & Online received strictly from actual cashbook inflows (never unpaid credit!)
    const todayCashIn = cashbookEntries
      .filter((c) => c.entryDate === today && c.direction === 'in' && c.paymentMode === 'cash')
      .reduce((s, c) => s + c.amount, 0);
    const todayOnlineIn = cashbookEntries
      .filter(
        (c) =>
          c.entryDate === today &&
          c.direction === 'in' &&
          (c.paymentMode === 'upi' || c.paymentMode === 'card' || c.paymentMode === 'bank')
      )
      .reduce((s, c) => s + c.amount, 0);

    const totalCustomerUdhaar = customers.reduce((s, c) => s + Math.max(0, c.remainingBalance), 0);
    const totalSupplierOutstanding = suppliers.reduce(
      (s, sup) => s + Math.max(0, sup.remainingOutstanding),
      0
    );

    const lowStockList = products.filter((p) => p.stockQty <= p.minStockAlert);

    return {
      todaySalesTotal,
      todayPurchasesTotal,
      todayNetProfit,
      todayExpensesTotal,
      monthExpensesTotal,
      todayCashIn,
      todayOnlineIn,
      totalCustomerUdhaar,
      totalSupplierOutstanding,
      totalProducts: products.length,
      lowStockList,
    };
  }, [bills, purchases, expenses, cashbookEntries, customers, suppliers, products, today, currentMonth]);

  // Last 6 months Sales & Net Profit bar chart data
  const monthlyChart = useMemo(() => {
    const months: { key: string; label: string; sales: number; profit: number }[] = [];
    const now = new Date();
    for (let i = 5; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const y = d.getFullYear();
      const m = String(d.getMonth() + 1).padStart(2, '0');
      const key = `${y}-${m}`;
      const label = d.toLocaleDateString(lang === 'hi' ? 'hi-IN' : 'en-IN', {
        month: 'short',
      });
      const mBills = bills.filter((b) => b.status !== 'cancelled' && b.billDate.startsWith(key));
      const mExpenses = expenses.filter((e) => e.expenseDate.startsWith(key));
      const sales = mBills.reduce((s, b) => s + b.totalAmount, 0);
      const gross = mBills.reduce((s, b) => s + b.grossProfit, 0);
      const exp = mExpenses.reduce((s, e) => s + e.amount, 0);
      months.push({ key, label, sales, profit: gross - exp });
    }
    const maxVal = Math.max(100, ...months.map((m) => Math.max(m.sales, m.profit, 0)));
    return { months, maxVal };
  }, [bills, expenses, lang]);

  // Recent combined transactions
  const recentTx = useMemo(() => {
    type TxRow = {
      id: string;
      date: string;
      title: string;
      subtitle: string;
      amount: number;
      kind: 'sale' | 'purchase' | 'expense';
    };
    const rows: TxRow[] = [];
    bills.slice(0, 8).forEach((b) => {
      rows.push({
        id: `bill_${b.id}`,
        date: b.billDate,
        title: `${b.billNumber} · ${b.customerName}`,
        subtitle: b.status === 'cancelled' ? labels.cancelled : labels[b.paymentMode],
        amount: b.totalAmount,
        kind: 'sale',
      });
    });
    purchases.slice(0, 6).forEach((p) => {
      rows.push({
        id: `pur_${p.id}`,
        date: p.purchaseDate,
        title: `${p.purchaseNumber} · ${p.supplierName}`,
        subtitle: labels[p.paymentMode],
        amount: p.totalAmount,
        kind: 'purchase',
      });
    });
    expenses.slice(0, 6).forEach((e) => {
      rows.push({
        id: `exp_${e.id}`,
        date: e.expenseDate,
        title: e.title,
        subtitle: labels[e.paymentMode],
        amount: e.amount,
        kind: 'expense',
      });
    });
    return rows.sort((a, b) => b.date.localeCompare(a.date)).slice(0, 10);
  }, [bills, purchases, expenses, labels]);

  if (dataLoading && products.length === 0 && bills.length === 0) {
    return (
      <div className="space-y-4">
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
          {Array.from({ length: 10 }).map((_, i) => (
            <div
              key={i}
              className="h-24 rounded-2xl bg-slate-200/70 dark:bg-slate-800/70 animate-pulse"
            />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Quick Action Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
            {formatDisplayDate(today, lang)} · {lang === 'hi' ? 'लाइव दुकान सारांश' : 'Live Store Summary'}
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => setActiveSection('billing')}
            className="inline-flex items-center gap-1.5 px-3.5 h-10 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold cursor-pointer whitespace-nowrap"
          >
            <Receipt className="w-4 h-4" />
            {lang === 'hi' ? 'नया बिल बनाएं' : 'Create Bill'}
          </button>
          <button
            type="button"
            onClick={() => setActiveSection('products')}
            className="inline-flex items-center gap-1.5 px-3.5 h-10 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-semibold cursor-pointer whitespace-nowrap"
          >
            <Plus className="w-4 h-4" />
            {lang === 'hi' ? 'उत्पाद जोड़ें' : 'Add Product'}
          </button>
          <button
            type="button"
            onClick={() => setActiveSection('purchase')}
            className="inline-flex items-center gap-1.5 px-3.5 h-10 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-semibold cursor-pointer whitespace-nowrap"
          >
            <ShoppingBag className="w-4 h-4" />
            {lang === 'hi' ? 'खरीद दर्ज करें' : 'Record Purchase'}
          </button>
          <button
            type="button"
            onClick={() => setActiveSection('udhaar')}
            className="inline-flex items-center gap-1.5 px-3.5 h-10 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-semibold cursor-pointer whitespace-nowrap"
          >
            <IndianRupee className="w-4 h-4" />
            {lang === 'hi' ? 'उधार / वसूली' : 'Udhaar Entry'}
          </button>
        </div>
      </div>

      {/* Clearly Visible Install App & Shareable Public Link Card */}
      <DashboardInstallCard />

      {/* 10 Core Dashboard KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3.5">
        <KpiCard
          title={labels.todaySales}
          value={formatINR(metrics.todaySalesTotal)}
          icon={<Receipt className="w-4 h-4 text-emerald-700 dark:text-emerald-400" />}
          onClick={() => setActiveSection('billing')}
        />
        <KpiCard
          title={labels.todayPurchases}
          value={formatINR(metrics.todayPurchasesTotal)}
          icon={<ShoppingBag className="w-4 h-4 text-sky-700 dark:text-sky-400" />}
          onClick={() => setActiveSection('purchase')}
        />
        <KpiCard
          title={labels.todayProfit}
          value={formatINR(metrics.todayNetProfit)}
          valueClass={
            metrics.todayNetProfit >= 0
              ? 'text-emerald-700 dark:text-emerald-400'
              : 'text-red-600 dark:text-red-400'
          }
          icon={<TrendingUp className="w-4 h-4 text-emerald-700 dark:text-emerald-400" />}
          onClick={() => setActiveSection('reports')}
        />
        <KpiCard
          title={labels.totalExpenses}
          value={formatINR(metrics.todayExpensesTotal)}
          subValue={`${lang === 'hi' ? 'माह' : 'Month'}: ${formatINR(metrics.monthExpensesTotal)}`}
          icon={<Wallet className="w-4 h-4 text-amber-600 dark:text-amber-400" />}
          onClick={() => setActiveSection('expenses')}
        />
        <KpiCard
          title={labels.cashReceived}
          value={formatINR(metrics.todayCashIn)}
          icon={<IndianRupee className="w-4 h-4 text-emerald-700 dark:text-emerald-400" />}
          onClick={() => setActiveSection('cashbook')}
        />
        <KpiCard
          title={labels.onlineReceived}
          value={formatINR(metrics.todayOnlineIn)}
          icon={<CreditCard className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />}
          onClick={() => setActiveSection('cashbook')}
        />
        <KpiCard
          title={labels.customerUdhaar}
          value={formatINR(metrics.totalCustomerUdhaar)}
          valueClass={metrics.totalCustomerUdhaar > 0 ? 'text-amber-700 dark:text-amber-400' : undefined}
          icon={<ArrowUpRight className="w-4 h-4 text-amber-600 dark:text-amber-400" />}
          onClick={() => setActiveSection('udhaar')}
        />
        <KpiCard
          title={labels.supplierOutstanding}
          value={formatINR(metrics.totalSupplierOutstanding)}
          valueClass={metrics.totalSupplierOutstanding > 0 ? 'text-red-600 dark:text-red-400' : undefined}
          icon={<Truck className="w-4 h-4 text-red-600 dark:text-red-400" />}
          onClick={() => setActiveSection('suppliers')}
        />
        <KpiCard
          title={labels.totalProducts}
          value={formatNumber(metrics.totalProducts)}
          icon={<Package className="w-4 h-4 text-slate-700 dark:text-slate-300" />}
          onClick={() => setActiveSection('products')}
        />
        <KpiCard
          title={labels.lowStockProducts}
          value={formatNumber(metrics.lowStockList.length)}
          valueClass={
            metrics.lowStockList.length > 0
              ? 'text-red-600 dark:text-red-400'
              : 'text-emerald-700 dark:text-emerald-400'
          }
          icon={<AlertTriangle className="w-4 h-4 text-red-600 dark:text-red-400" />}
          onClick={() => setActiveSection('stock')}
        />
      </div>

      {/* Main Split: Monthly Sales & Profit Chart + Low Stock Alerts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Monthly Chart */}
        <section className="lg:col-span-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h2 className="text-base font-bold text-slate-900 dark:text-slate-100">
              {labels.monthlyChartTitle}
            </h2>
            <div className="flex items-center gap-4 text-xs text-slate-600 dark:text-slate-400">
              <span className="inline-flex items-center gap-1.5">
                <span className="w-3 h-3 rounded-sm bg-emerald-600 inline-block" />
                {lang === 'hi' ? 'बिक्री' : 'Sales'}
              </span>
              <span className="inline-flex items-center gap-1.5">
                <span className="w-3 h-3 rounded-sm bg-amber-500 inline-block" />
                {lang === 'hi' ? 'शुद्ध लाभ' : 'Net Profit'}
              </span>
            </div>
          </div>

          <div className="h-56 flex items-end justify-between gap-2 sm:gap-4 pt-4 border-b border-slate-200 dark:border-slate-800 pb-2">
            {monthlyChart.months.map((m) => {
              const salesPct = Math.max(4, Math.round((m.sales / monthlyChart.maxVal) * 100));
              const profitPct = Math.max(
                4,
                Math.round((Math.max(0, m.profit) / monthlyChart.maxVal) * 100)
              );
              return (
                <div key={m.key} className="flex-1 flex flex-col items-center gap-2 h-full justify-end">
                  <div className="w-full flex items-end justify-center gap-1.5 h-44">
                    <div
                      title={`${m.label} Sales: ${formatINR(m.sales)}`}
                      style={{ height: `${m.sales > 0 ? salesPct : 3}%` }}
                      className="w-4 sm:w-6 rounded-t-md bg-emerald-600 transition-all duration-300"
                    />
                    <div
                      title={`${m.label} Net Profit: ${formatINR(m.profit)}`}
                      style={{ height: `${m.profit > 0 ? profitPct : 3}%` }}
                      className={`w-4 sm:w-6 rounded-t-md transition-all duration-300 ${
                        m.profit >= 0 ? 'bg-amber-500' : 'bg-red-500'
                      }`}
                    />
                  </div>
                  <div className="text-center">
                    <p className="text-xs font-semibold text-slate-700 dark:text-slate-300">{m.label}</p>
                    <p className="text-[10px] font-mono tabular-nums text-slate-500 dark:text-slate-400">
                      {m.sales >= 1000 ? `₹${(m.sales / 1000).toFixed(1)}k` : `₹${Math.round(m.sales)}`}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </section>

        {/* Low Stock Products List */}
        <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 flex flex-col justify-between gap-4">
          <div className="flex items-center justify-between gap-2">
            <h2 className="text-base font-bold text-slate-900 dark:text-slate-100">
              {labels.lowStockProducts}
            </h2>
            <button
              type="button"
              onClick={() => setActiveSection('stock')}
              className="text-xs font-semibold text-emerald-700 dark:text-emerald-400 hover:underline cursor-pointer"
            >
              {lang === 'hi' ? 'स्टॉक देखें' : 'View Stock'}
            </button>
          </div>

          {metrics.lowStockList.length === 0 ? (
            <div className="py-8 text-center text-sm text-slate-500 dark:text-slate-400 space-y-2">
              <Boxes className="w-8 h-8 mx-auto text-emerald-600/70" />
              <p>
                {lang === 'hi'
                  ? 'सभी उत्पादों का स्टॉक पर्याप्त है।'
                  : 'All products are well stocked.'}
              </p>
            </div>
          ) : (
            <div className="divide-y divide-slate-100 dark:divide-slate-800 max-h-64 overflow-y-auto">
              {metrics.lowStockList.slice(0, 8).map((p) => (
                <div key={p.id} className="py-2.5 flex items-center justify-between gap-3">
                  <div className="min-w-0">
                    <p className="text-sm font-medium text-slate-900 dark:text-slate-100 truncate">
                      {p.name}
                    </p>
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      {p.category} · {lang === 'hi' ? 'न्यूनतम' : 'Min'}: {p.minStockAlert} {p.unit}
                    </p>
                  </div>
                  <span
                    className={`text-sm font-mono tabular-nums font-bold shrink-0 ${
                      p.stockQty <= 0
                        ? 'text-red-600 dark:text-red-400'
                        : 'text-amber-600 dark:text-amber-400'
                    }`}
                  >
                    {p.stockQty} {p.unit}
                  </span>
                </div>
              ))}
            </div>
          )}
        </section>
      </div>

      {/* Recent Transactions */}
      <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-4">
        <div className="flex items-center justify-between gap-2">
          <h2 className="text-base font-bold text-slate-900 dark:text-slate-100">
            {labels.recentTransactions}
          </h2>
          <button
            type="button"
            onClick={() => setActiveSection('reports')}
            className="text-xs font-semibold text-emerald-700 dark:text-emerald-400 hover:underline cursor-pointer"
          >
            {lang === 'hi' ? 'सभी रिपोर्ट्स' : 'All Reports'}
          </button>
        </div>

        {recentTx.length === 0 ? (
          <p className="text-sm text-slate-500 dark:text-slate-400 py-6 text-center">
            {labels.noData}
          </p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-left text-xs text-slate-500 dark:text-slate-400">
                  <th className="py-2.5 pr-4 font-medium">{lang === 'hi' ? 'तिथि' : 'Date'}</th>
                  <th className="py-2.5 pr-4 font-medium">{lang === 'hi' ? 'विवरण' : 'Description'}</th>
                  <th className="py-2.5 pr-4 font-medium">{lang === 'hi' ? 'प्रकार / माध्यम' : 'Type / Mode'}</th>
                  <th className="py-2.5 text-right font-medium">{lang === 'hi' ? 'राशि' : 'Amount'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {recentTx.map((tx) => (
                  <tr key={tx.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                    <td className="py-3 pr-4 font-mono tabular-nums text-xs text-slate-500 dark:text-slate-400 whitespace-nowrap">
                      {tx.date}
                    </td>
                    <td className="py-3 pr-4 font-medium text-slate-900 dark:text-slate-100">
                      {tx.title}
                    </td>
                    <td className="py-3 pr-4 text-xs text-slate-600 dark:text-slate-400 whitespace-nowrap">
                      {tx.kind === 'sale'
                        ? lang === 'hi'
                          ? 'बिक्री'
                          : 'Sale'
                        : tx.kind === 'purchase'
                          ? lang === 'hi'
                            ? 'खरीद'
                            : 'Purchase'
                          : lang === 'hi'
                            ? 'खर्च'
                            : 'Expense'}{' '}
                      · {tx.subtitle}
                    </td>
                    <td
                      className={`py-3 text-right font-mono tabular-nums font-semibold whitespace-nowrap ${
                        tx.kind === 'sale'
                          ? 'text-emerald-700 dark:text-emerald-400'
                          : 'text-slate-800 dark:text-slate-200'
                      }`}
                    >
                      <span className="inline-flex items-center gap-1 justify-end">
                        {tx.kind === 'sale' ? (
                          <ArrowDownRight className="w-3.5 h-3.5" />
                        ) : (
                          <ArrowUpRight className="w-3.5 h-3.5 text-red-500" />
                        )}
                        {formatINR(tx.amount)}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
};

const KpiCard: React.FC<{
  title: string;
  value: string;
  subValue?: string;
  icon: React.ReactNode;
  valueClass?: string;
  onClick?: () => void;
}> = ({ title, value, subValue, icon, valueClass, onClick }) => (
  <button
    type="button"
    onClick={onClick}
    className="text-left bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-emerald-500/50 rounded-2xl p-4 space-y-2 transition-colors cursor-pointer"
  >
    <div className="flex items-center justify-between gap-2">
      <span className="text-xs font-medium text-slate-500 dark:text-slate-400 truncate">{title}</span>
      {icon}
    </div>
    <p
      className={`text-lg sm:text-xl font-bold font-mono tabular-nums truncate ${
        valueClass || 'text-slate-900 dark:text-slate-100'
      }`}
    >
      {value}
    </p>
    {subValue && (
      <p className="text-[11px] font-mono tabular-nums text-slate-500 dark:text-slate-400 truncate">
        {subValue}
      </p>
    )}
  </button>
);
