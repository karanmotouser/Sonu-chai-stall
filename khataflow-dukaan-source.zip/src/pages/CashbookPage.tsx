import React, { useMemo, useState } from 'react';
import { BookOpen, Plus, X } from 'lucide-react';
import { useDukaan } from '../context/DukaanContext';
import { formatINR, getTodayISO } from '../lib/formatters';
import { t } from '../lib/i18n';
import { addManualCashbookEntry, updateShopProfile } from '../services/dukaanService';

export const CashbookPage: React.FC = () => {
  const { user, shopProfile, lang, cashbookEntries, notify } = useDukaan();
  const labels = t(lang);

  const [selectedDate, setSelectedDate] = useState(getTodayISO());
  const [openingInput, setOpeningInput] = useState(shopProfile?.openingCashBalance || 0);
  const [manualOpen, setManualOpen] = useState(false);
  const [direction, setDirection] = useState<'in' | 'out'>('in');
  const [paymentMode, setPaymentMode] = useState<'cash' | 'upi' | 'bank' | 'card'>('cash');
  const [amount, setAmount] = useState(0);
  const [description, setDescription] = useState('');
  const [saving, setSaving] = useState(false);

  const stats = useMemo(() => {
    const baseOpening = shopProfile?.openingCashBalance || 0;
    // Prior days net cash
    const priorCashNet = cashbookEntries
      .filter((c) => c.entryDate < selectedDate && c.paymentMode === 'cash')
      .reduce((s, c) => s + (c.direction === 'in' ? c.amount : -c.amount), 0);

    const openingCashForDate = baseOpening + priorCashNet;
    const dayEntries = cashbookEntries.filter((c) => c.entryDate === selectedDate);

    const sum = (mode: 'cash' | 'upi' | 'bank' | 'card', dir: 'in' | 'out') =>
      dayEntries
        .filter((e) => e.paymentMode === mode && e.direction === dir)
        .reduce((s, e) => s + e.amount, 0);

    const cashIn = sum('cash', 'in');
    const cashOut = sum('cash', 'out');
    const closingCash = openingCashForDate + cashIn - cashOut;

    const upiNet = sum('upi', 'in') - sum('upi', 'out');
    const bankNet = sum('bank', 'in') - sum('bank', 'out');
    const cardNet = sum('card', 'in') - sum('card', 'out');

    return {
      openingCashForDate,
      cashIn,
      cashOut,
      closingCash,
      upiIn: sum('upi', 'in'),
      upiOut: sum('upi', 'out'),
      upiNet,
      bankIn: sum('bank', 'in'),
      bankOut: sum('bank', 'out'),
      bankNet,
      cardIn: sum('card', 'in'),
      cardNet,
      dayEntries,
    };
  }, [cashbookEntries, selectedDate, shopProfile]);

  const saveOpeningBalance = async () => {
    if (!user) return;
    await updateShopProfile(user.uid, { openingCashBalance: Number(openingInput) || 0 });
    notify(lang === 'hi' ? 'प्रारंभिक रोकड़ बैलेंस अपडेट हुआ!' : 'Opening cash balance updated!');
  };

  const handleManualSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || saving || amount <= 0) return;
    setSaving(true);
    try {
      await addManualCashbookEntry(user.uid, {
        entryDate: selectedDate,
        direction,
        paymentMode,
        amount,
        description,
      });
      notify(lang === 'hi' ? 'रोकड़ प्रविष्टि जुड़ गई!' : 'Cashbook entry added!');
      setManualOpen(false);
      setAmount(0);
      setDescription('');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Failed', 'error');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Bar Controls */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-3">
          <div>
            <label className="block text-[11px] text-slate-500">{lang === 'hi' ? 'तिथि चुनें' : 'Select Date'}</label>
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="h-10 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono text-sm"
            />
          </div>
          <div className="flex items-end gap-2">
            <div>
              <label className="block text-[11px] text-slate-500">
                {lang === 'hi' ? 'बेस ओपनिंग कैश (₹)' : 'Base Opening Cash (₹)'}
              </label>
              <input
                type="number"
                step="any"
                value={openingInput}
                onChange={(e) => setOpeningInput(Number(e.target.value) || 0)}
                className="w-32 h-10 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono text-sm"
              />
            </div>
            <button
              type="button"
              onClick={saveOpeningBalance}
              className="px-3 h-10 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-semibold hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
            >
              {labels.save}
            </button>
          </div>
        </div>

        <button
          type="button"
          onClick={() => setManualOpen(true)}
          className="inline-flex items-center gap-2 px-4 h-10 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          {lang === 'hi' ? 'मैनुअल प्रविष्टि' : 'Manual Entry'}
        </button>
      </div>

      {/* Mode Breakdown Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 space-y-1.5">
          <p className="text-xs text-slate-500">{lang === 'hi' ? 'गल्ला / नकद रोकड़ (Cash)' : 'Physical Cash Drawer'}</p>
          <p className="text-xs text-slate-500 font-mono">
            {lang === 'hi' ? 'ओपनिंग' : 'Opening'}: {formatINR(stats.openingCashForDate)}
          </p>
          <p className="text-xs font-mono text-emerald-700 dark:text-emerald-400">
            + {formatINR(stats.cashIn)} / - {formatINR(stats.cashOut)}
          </p>
          <p className="text-lg font-bold font-mono tabular-nums pt-1 border-t border-slate-100 dark:border-slate-800">
            {lang === 'hi' ? 'क्लोजिंग' : 'Closing'}: {formatINR(stats.closingCash)}
          </p>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 space-y-1.5">
          <p className="text-xs text-slate-500">UPI / QR</p>
          <p className="text-xs font-mono text-emerald-700 dark:text-emerald-400">
            {lang === 'hi' ? 'आवक' : 'In'}: {formatINR(stats.upiIn)}
          </p>
          <p className="text-xs font-mono text-red-600">
            {lang === 'hi' ? 'जावक' : 'Out'}: {formatINR(stats.upiOut)}
          </p>
          <p className="text-lg font-bold font-mono tabular-nums pt-1 border-t border-slate-100 dark:border-slate-800">
            {lang === 'hi' ? 'शुद्ध' : 'Net'}: {formatINR(stats.upiNet)}
          </p>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 space-y-1.5">
          <p className="text-xs text-slate-500">{labels.bank}</p>
          <p className="text-xs font-mono text-emerald-700 dark:text-emerald-400">
            {lang === 'hi' ? 'आवक' : 'In'}: {formatINR(stats.bankIn)}
          </p>
          <p className="text-xs font-mono text-red-600">
            {lang === 'hi' ? 'जावक' : 'Out'}: {formatINR(stats.bankOut)}
          </p>
          <p className="text-lg font-bold font-mono tabular-nums pt-1 border-t border-slate-100 dark:border-slate-800">
            {lang === 'hi' ? 'शुद्ध' : 'Net'}: {formatINR(stats.bankNet)}
          </p>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 space-y-1.5">
          <p className="text-xs text-slate-500">{labels.card}</p>
          <p className="text-xs font-mono text-emerald-700 dark:text-emerald-400">
            {lang === 'hi' ? 'आवक' : 'In'}: {formatINR(stats.cardIn)}
          </p>
          <p className="text-lg font-bold font-mono tabular-nums pt-1 border-t border-slate-100 dark:border-slate-800">
            {formatINR(stats.cardNet)}
          </p>
        </div>
      </div>

      {/* Day Entries */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 text-left text-xs text-slate-500 bg-slate-50/70 dark:bg-slate-950/50">
                <th className="py-3 px-4">{lang === 'hi' ? 'श्रेणी' : 'Category'}</th>
                <th className="py-3 px-3">{lang === 'hi' ? 'विवरण' : 'Description'}</th>
                <th className="py-3 px-3">{lang === 'hi' ? 'माध्यम' : 'Mode'}</th>
                <th className="py-3 px-4 text-right">{lang === 'hi' ? 'राशि' : 'Amount'}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {stats.dayEntries.length === 0 ? (
                <tr>
                  <td colSpan={4} className="py-8 text-center text-slate-500">
                    <BookOpen className="w-6 h-6 mx-auto mb-1 opacity-50" />
                    {labels.noData}
                  </td>
                </tr>
              ) : (
                stats.dayEntries.map((e) => (
                  <tr key={e.id}>
                    <td className="py-3 px-4 text-xs capitalize font-medium">{e.category}</td>
                    <td className="py-3 px-3">{e.description}</td>
                    <td className="py-3 px-3 text-xs uppercase font-mono">{e.paymentMode}</td>
                    <td
                      className={`py-3 px-4 text-right font-mono tabular-nums font-bold ${
                        e.direction === 'in'
                          ? 'text-emerald-700 dark:text-emerald-400'
                          : 'text-red-600'
                      }`}
                    >
                      {e.direction === 'in' ? '+' : '-'}
                      {formatINR(e.amount)}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Manual Entry Modal */}
      {manualOpen && (
        <div className="fixed inset-0 z-50 bg-black/55 backdrop-blur-sm flex items-center justify-center p-4">
          <form
            onSubmit={handleManualSubmit}
            className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-md w-full p-5 space-y-4"
          >
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-base">
                {lang === 'hi' ? 'रोकड़ बही प्रविष्टि' : 'Cashbook Manual Entry'}
              </h3>
              <button
                type="button"
                onClick={() => setManualOpen(false)}
                className="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setDirection('in')}
                className={`h-10 rounded-xl text-xs font-semibold border cursor-pointer ${
                  direction === 'in' ? 'bg-emerald-700 border-emerald-700 text-white' : 'border-slate-200 dark:border-slate-700'
                }`}
              >
                {lang === 'hi' ? 'रोकड़ आवक (In)' : 'Cash In'}
              </button>
              <button
                type="button"
                onClick={() => setDirection('out')}
                className={`h-10 rounded-xl text-xs font-semibold border cursor-pointer ${
                  direction === 'out' ? 'bg-red-600 border-red-600 text-white' : 'border-slate-200 dark:border-slate-700'
                }`}
              >
                {lang === 'hi' ? 'रोकड़ जावक (Out)' : 'Cash Out'}
              </button>
            </div>
            <select
              value={paymentMode}
              onChange={(e) => setPaymentMode(e.target.value as 'cash' | 'upi' | 'bank' | 'card')}
              className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm"
            >
              <option value="cash">{labels.cash}</option>
              <option value="upi">UPI</option>
              <option value="bank">{labels.bank}</option>
              <option value="card">{labels.card}</option>
            </select>
            <input
              required
              type="number"
              min="1"
              step="any"
              value={amount}
              onChange={(e) => setAmount(Number(e.target.value) || 0)}
              placeholder={lang === 'hi' ? 'राशि (₹)' : 'Amount (₹)'}
              className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono text-base font-bold"
            />
            <input
              required
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder={lang === 'hi' ? 'विवरण (जैसे: गल्ले में नकद जमा)' : 'Description'}
              className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm"
            />
            <button
              type="submit"
              disabled={saving}
              className="w-full h-11 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-semibold text-sm cursor-pointer"
            >
              {saving ? '...' : labels.save}
            </button>
          </form>
        </div>
      )}
    </div>
  );
};
