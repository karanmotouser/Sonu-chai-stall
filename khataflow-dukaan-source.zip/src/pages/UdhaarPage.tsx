import React, { useMemo, useState } from 'react';
import { ArrowDownLeft, ArrowUpRight, FileText, MessageCircle, Search, X } from 'lucide-react';
import { useDukaan } from '../context/DukaanContext';
import { buildWhatsAppUrl, formatINR, getTodayISO } from '../lib/formatters';
import { t } from '../lib/i18n';
import { recordUdhaarEntry } from '../services/dukaanService';
import { Customer } from '../types/dukaan';

export const UdhaarPage: React.FC = () => {
  const { user, shopProfile, lang, customers, udhaarTransactions, notify, openPrintModal } = useDukaan();
  const labels = t(lang);

  const [search, setSearch] = useState('');
  const [onlyPending, setOnlyPending] = useState(true);
  const [activeCust, setActiveCust] = useState<Customer | null>(null);
  const [txType, setTxType] = useState<'udhaar' | 'repayment'>('repayment');
  const [amount, setAmount] = useState(0);
  const [paymentMode, setPaymentMode] = useState<'cash' | 'upi' | 'bank'>('cash');
  const [txDate, setTxDate] = useState(getTodayISO());
  const [notes, setNotes] = useState('');
  const [saving, setSaving] = useState(false);

  const totalPending = useMemo(
    () => customers.reduce((s, c) => s + Math.max(0, c.remainingBalance), 0),
    [customers]
  );

  const filteredCustomers = useMemo(() => {
    const q = search.trim().toLowerCase();
    return customers.filter((c) => {
      const matchPending = !onlyPending || c.remainingBalance > 0;
      const matchQ = !q || c.name.toLowerCase().includes(q) || c.phone.includes(q);
      return matchPending && matchQ;
    });
  }, [customers, onlyPending, search]);

  const openModal = (c: Customer, type: 'udhaar' | 'repayment') => {
    setActiveCust(c);
    setTxType(type);
    setAmount(type === 'repayment' ? Math.max(0, c.remainingBalance) : 0);
    setPaymentMode('cash');
    setTxDate(getTodayISO());
    setNotes('');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !activeCust || saving) return;
    if (amount <= 0) {
      notify(lang === 'hi' ? 'राशि 0 से अधिक होनी चाहिए।' : 'Amount must be greater than 0.', 'error');
      return;
    }
    setSaving(true);
    try {
      await recordUdhaarEntry(user.uid, {
        customerId: activeCust.id,
        type: txType,
        amount,
        paymentMode: txType === 'udhaar' ? 'credit' : paymentMode,
        txDate,
        notes,
      });
      notify(
        txType === 'repayment'
          ? lang === 'hi'
            ? 'उधार वसूली दर्ज हो गई!'
            : 'Repayment recorded!'
          : lang === 'hi'
            ? 'उधार दर्ज हो गया!'
            : 'Udhaar added!'
      );
      setActiveCust(null);
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Failed', 'error');
    } finally {
      setSaving(false);
    }
  };

  const sendWhatsAppReminder = (c: Customer) => {
    const msg =
      lang === 'hi'
        ? `नमस्ते ${c.name} जी,\n*${shopProfile?.shopName || 'हमारी दुकान'}* पर आपका बकाया उधार *${formatINR(c.remainingBalance)}* है। कृपया सुविधा अनुसार भुगतान करें। धन्यवाद!`
        : `Hello ${c.name},\nThis is a gentle payment reminder from *${shopProfile?.shopName || 'our shop'}*. Your pending udhaar balance is *${formatINR(c.remainingBalance)}*. Thank you!`;
    window.open(buildWhatsAppUrl(c.phone, msg), '_blank', 'noopener,noreferrer');
  };

  const printCustomerLedger = (c: Customer) => {
    const list = udhaarTransactions.filter((tx) => tx.customerId === c.id);
    openPrintModal({
      title: `${c.name} · ${lang === 'hi' ? 'उधार बही' : 'Udhaar Ledger'}`,
      content: (
        <div className="space-y-4 text-sm text-slate-900">
          <div className="flex justify-between border-b border-slate-300 pb-3">
            <div>
              <h2 className="text-lg font-bold">{shopProfile?.shopName}</h2>
              <p className="text-xs">{c.name} ({c.phone})</p>
            </div>
            <div className="text-right">
              <p className="text-xs text-slate-500">{lang === 'hi' ? 'शेष बकाया' : 'Balance Due'}</p>
              <p className="text-lg font-bold font-mono text-red-700">{formatINR(c.remainingBalance)}</p>
            </div>
          </div>
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-slate-300 text-left">
                <th className="py-2">{lang === 'hi' ? 'तिथि' : 'Date'}</th>
                <th className="py-2">{lang === 'hi' ? 'विवरण' : 'Type'}</th>
                <th className="py-2">{lang === 'hi' ? 'टिप्पणी' : 'Notes'}</th>
                <th className="py-2 text-right">{lang === 'hi' ? 'राशि' : 'Amount'}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {list.map((tx) => (
                <tr key={tx.id}>
                  <td className="py-2 font-mono">{tx.txDate}</td>
                  <td className="py-2">{tx.type}</td>
                  <td className="py-2">{tx.notes || '-'}</td>
                  <td className="py-2 text-right font-mono font-bold">{formatINR(tx.amount)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ),
    });
  };

  return (
    <div className="space-y-6">
      {/* Top Summary */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 flex flex-wrap items-center justify-between gap-4">
        <div>
          <p className="text-xs text-slate-500">{lang === 'hi' ? 'कुल बकाया ग्राहक उधार' : 'Total Receivable Udhaar'}</p>
          <p className="text-2xl font-bold font-mono tabular-nums text-amber-600 mt-0.5">
            {formatINR(totalPending)}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <label className="inline-flex items-center gap-2 text-xs font-medium cursor-pointer">
            <input
              type="checkbox"
              checked={onlyPending}
              onChange={(e) => setOnlyPending(e.target.checked)}
              className="w-4 h-4 accent-emerald-700"
            />
            {lang === 'hi' ? 'केवल बकाया वाले ग्राहक' : 'Only Pending Balance'}
          </label>
          <div className="relative w-56">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder={labels.search}
              className="w-full h-10 pl-9 pr-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm"
            />
          </div>
        </div>
      </div>

      {/* Customer Udhaar Cards / Table */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 text-left text-xs text-slate-500 bg-slate-50/70 dark:bg-slate-950/50">
                <th className="py-3 px-4">{lang === 'hi' ? 'ग्राहक' : 'Customer'}</th>
                <th className="py-3 px-3 text-right">{lang === 'hi' ? 'कुल दिया' : 'Given'}</th>
                <th className="py-3 px-3 text-right">{lang === 'hi' ? 'जमा' : 'Received'}</th>
                <th className="py-3 px-3 text-right">{lang === 'hi' ? 'बाकी' : 'Balance'}</th>
                <th className="py-3 px-4 text-right">{lang === 'hi' ? 'लेन-देन' : 'Actions'}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filteredCustomers.length === 0 ? (
                <tr>
                  <td colSpan={5} className="py-8 text-center text-slate-500">
                    {labels.noData}
                  </td>
                </tr>
              ) : (
                filteredCustomers.map((c) => (
                  <tr key={c.id}>
                    <td className="py-3 px-4">
                      <p className="font-semibold">{c.name}</p>
                      <p className="text-xs font-mono text-slate-500">{c.phone}</p>
                    </td>
                    <td className="py-3 px-3 text-right font-mono tabular-nums">{formatINR(c.totalUdhaar)}</td>
                    <td className="py-3 px-3 text-right font-mono tabular-nums text-emerald-700 dark:text-emerald-400">
                      {formatINR(c.amountReceived)}
                    </td>
                    <td className="py-3 px-3 text-right font-mono tabular-nums font-bold text-red-600">
                      {formatINR(c.remainingBalance)}
                    </td>
                    <td className="py-3 px-4 text-right whitespace-nowrap">
                      <div className="inline-flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => openModal(c, 'repayment')}
                          className="inline-flex items-center gap-1 px-2.5 h-8 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold cursor-pointer"
                        >
                          <ArrowDownLeft className="w-3.5 h-3.5" />
                          {lang === 'hi' ? 'जमा लें' : 'Receive'}
                        </button>
                        <button
                          type="button"
                          onClick={() => openModal(c, 'udhaar')}
                          className="inline-flex items-center gap-1 px-2.5 h-8 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-semibold hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                        >
                          <ArrowUpRight className="w-3.5 h-3.5 text-amber-600" />
                          {lang === 'hi' ? 'उधार दें' : 'Give'}
                        </button>
                        <button
                          type="button"
                          onClick={() => sendWhatsAppReminder(c)}
                          title={lang === 'hi' ? 'WhatsApp रिमाइंडर' : 'WhatsApp Reminder'}
                          className="p-2 rounded-lg text-emerald-700 hover:bg-emerald-50 dark:hover:bg-emerald-950 cursor-pointer"
                        >
                          <MessageCircle className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => printCustomerLedger(c)}
                          title={lang === 'hi' ? 'खाता प्रिंट' : 'Print Ledger'}
                          className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                        >
                          <FileText className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Transaction History */}
      <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-3">
        <h3 className="text-base font-bold">
          {lang === 'hi' ? 'उधार एवं वसूली इतिहास' : 'Udhaar & Repayment History'}
        </h3>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 text-left text-xs text-slate-500">
                <th className="py-2 pr-3">{lang === 'hi' ? 'तिथि' : 'Date'}</th>
                <th className="py-2 pr-3">{lang === 'hi' ? 'ग्राहक' : 'Customer'}</th>
                <th className="py-2 pr-3">{lang === 'hi' ? 'प्रकार' : 'Type'}</th>
                <th className="py-2 pr-3">{lang === 'hi' ? 'नोट' : 'Notes'}</th>
                <th className="py-2 text-right">{lang === 'hi' ? 'राशि' : 'Amount'}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {udhaarTransactions.slice(0, 50).map((tx) => (
                <tr key={tx.id}>
                  <td className="py-2.5 pr-3 font-mono text-xs text-slate-500">{tx.txDate}</td>
                  <td className="py-2.5 pr-3 font-medium">{tx.customerName}</td>
                  <td className="py-2.5 pr-3 text-xs">{tx.type} ({tx.paymentMode})</td>
                  <td className="py-2.5 pr-3 text-xs text-slate-500">{tx.notes || '-'}</td>
                  <td
                    className={`py-2.5 text-right font-mono tabular-nums font-bold ${
                      tx.type === 'repayment' || tx.type === 'return_credit'
                        ? 'text-emerald-700 dark:text-emerald-400'
                        : 'text-red-600'
                    }`}
                  >
                    {tx.type === 'repayment' || tx.type === 'return_credit' ? '-' : '+'}
                    {formatINR(tx.amount)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* Add Udhaar / Repayment Modal */}
      {activeCust && (
        <div className="fixed inset-0 z-50 bg-black/55 backdrop-blur-sm flex items-center justify-center p-4">
          <form
            onSubmit={handleSubmit}
            className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-md w-full p-5 space-y-4"
          >
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-base">
                {activeCust.name} ·{' '}
                {txType === 'repayment'
                  ? lang === 'hi'
                    ? 'उधार जमा (वसूली)'
                    : 'Receive Repayment'
                  : lang === 'hi'
                    ? 'नया उधार जोड़ें'
                    : 'Add Udhaar'}
              </h3>
              <button
                type="button"
                onClick={() => setActiveCust(null)}
                className="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-xs text-slate-500 mb-1">
                  {lang === 'hi' ? 'राशि (₹)' : 'Amount (₹)'}
                </label>
                <input
                  required
                  type="number"
                  min="1"
                  step="any"
                  value={amount}
                  onChange={(e) => setAmount(Number(e.target.value) || 0)}
                  className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono text-base font-bold"
                />
              </div>

              {txType === 'repayment' && (
                <div>
                  <label className="block text-xs text-slate-500 mb-1">
                    {lang === 'hi' ? 'भुगतान माध्यम' : 'Payment Mode'}
                  </label>
                  <select
                    value={paymentMode}
                    onChange={(e) => setPaymentMode(e.target.value as 'cash' | 'upi' | 'bank')}
                    className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm"
                  >
                    <option value="cash">{labels.cash}</option>
                    <option value="upi">{labels.upi}</option>
                    <option value="bank">{labels.bank}</option>
                  </select>
                </div>
              )}

              <div>
                <label className="block text-xs text-slate-500 mb-1">{lang === 'hi' ? 'तिथि' : 'Date'}</label>
                <input
                  type="date"
                  value={txDate}
                  onChange={(e) => setTxDate(e.target.value)}
                  className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono text-sm"
                />
              </div>

              <div>
                <label className="block text-xs text-slate-500 mb-1">{lang === 'hi' ? 'टिप्पणी' : 'Notes'}</label>
                <input
                  type="text"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={saving}
              className="w-full h-11 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-semibold text-sm cursor-pointer"
            >
              {saving ? '...' : labels.save}
            </button>
          </form>
        </div>
      )}
    </div>
  );
};
