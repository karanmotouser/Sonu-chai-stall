import React, { useEffect, useMemo, useState } from 'react';
import {
  CheckCircle2,
  Edit3,
  MessageCircle,
  Minus,
  Plus,
  Printer,
  Search,
  Trash2,
  XCircle,
} from 'lucide-react';
import { useDukaan } from '../context/DukaanContext';
import {
  buildWhatsAppUrl,
  formatDisplayDate,
  formatINR,
  getTodayISO,
} from '../lib/formatters';
import { t } from '../lib/i18n';
import { cancelBill, createBill, editBill } from '../services/dukaanService';
import { Bill, BillLineItem, PaymentMode, Product } from '../types/dukaan';

interface CartRow {
  productId: string;
  productName: string;
  unit: string;
  qty: number;
  unitPrice: number;
  purchasePriceAtSale: number;
  gstRate: number;
}

export const BillingPosPage: React.FC = () => {
  const {
    user,
    shopProfile,
    lang,
    products,
    customers,
    bills,
    notify,
    openPrintModal,
    editingBillId,
    setEditingBillId,
  } = useDukaan();

  const labels = t(lang);

  const [searchQuery, setSearchQuery] = useState('');
  const [cart, setCart] = useState<CartRow[]>([]);
  const [selectedCustomerId, setSelectedCustomerId] = useState('');
  const [customerName, setCustomerName] = useState<string>(labels.walkInCustomer);
  const [customerPhone, setCustomerPhone] = useState('');
  const [discountAmount, setDiscountAmount] = useState(0);
  const [applyGst, setApplyGst] = useState(true);
  const [billDate, setBillDate] = useState(getTodayISO());
  const [paymentMode, setPaymentMode] = useState<PaymentMode>('cash');
  const [cashPaid, setCashPaid] = useState(0);
  const [onlinePaid, setOnlinePaid] = useState(0);
  const [cardPaid, setCardPaid] = useState(0);
  const [creditAmount, setCreditAmount] = useState(0);
  const [notes, setNotes] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [billSearch, setBillSearch] = useState('');

  // Load existing bill when editing
  useEffect(() => {
    if (!editingBillId) return;
    const found = bills.find((b) => b.id === editingBillId);
    if (!found) return;
    setSelectedCustomerId(found.customerId || '');
    setCustomerName(found.customerName);
    setCustomerPhone(found.customerPhone || '');
    setCart(
      found.items.map((i) => ({
        productId: i.productId,
        productName: i.productName,
        unit: i.unit,
        qty: i.qty,
        unitPrice: i.unitPrice,
        purchasePriceAtSale: i.purchasePriceAtSale,
        gstRate: i.gstRate,
      }))
    );
    setDiscountAmount(found.discountAmount);
    setApplyGst(found.gstAmount > 0);
    setBillDate(found.billDate);
    setPaymentMode(found.paymentMode);
    setCashPaid(found.cashPaid);
    setOnlinePaid(found.onlinePaid);
    setCardPaid(found.cardPaid);
    setCreditAmount(found.creditAmount);
    setNotes(found.notes || '');
  }, [editingBillId, bills]);

  const filteredProducts = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return products.slice(0, 12);
    return products
      .filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          (p.barcode || '').toLowerCase().includes(q) ||
          (p.sku || '').toLowerCase().includes(q)
      )
      .slice(0, 16);
  }, [products, searchQuery]);

  const addProductToCart = (prod: Product) => {
    setCart((prev) => {
      const idx = prev.findIndex((c) => c.productId === prod.id);
      if (idx >= 0) {
        return prev.map((c, i) => (i === idx ? { ...c, qty: c.qty + 1 } : c));
      }
      return [
        ...prev,
        {
          productId: prod.id,
          productName: prod.name,
          unit: prod.unit,
          qty: 1,
          unitPrice: prod.sellingPrice,
          purchasePriceAtSale: prod.purchasePrice,
          gstRate: prod.gstRate ?? (shopProfile?.defaultGstRate || 0),
        },
      ];
    });
  };

  // Barcode scan Enter key instant add
  const handleSearchKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && searchQuery.trim()) {
      e.preventDefault();
      const q = searchQuery.trim().toLowerCase();
      const exactBarcode = products.find(
        (p) =>
          (p.barcode || '').toLowerCase() === q || (p.sku || '').toLowerCase() === q
      );
      if (exactBarcode) {
        addProductToCart(exactBarcode);
        setSearchQuery('');
      } else if (filteredProducts.length === 1) {
        addProductToCart(filteredProducts[0]);
        setSearchQuery('');
      }
    }
  };

  const totals = useMemo(() => {
    let subtotal = 0;
    let gstTotal = 0;
    const lineItems: BillLineItem[] = cart.map((row) => {
      const base = Math.round(row.qty * row.unitPrice * 100) / 100;
      const gst = applyGst ? Math.round(base * (row.gstRate / 100) * 100) / 100 : 0;
      subtotal += base;
      gstTotal += gst;
      return {
        productId: row.productId,
        productName: row.productName,
        unit: row.unit,
        qty: row.qty,
        unitPrice: row.unitPrice,
        purchasePriceAtSale: row.purchasePriceAtSale,
        gstRate: applyGst ? row.gstRate : 0,
        gstAmount: gst,
        lineTotal: Math.round((base + gst) * 100) / 100,
      };
    });

    subtotal = Math.round(subtotal * 100) / 100;
    gstTotal = Math.round(gstTotal * 100) / 100;
    const disc = Math.max(0, Math.min(subtotal + gstTotal, Number(discountAmount) || 0));
    const totalAmount = Math.round((subtotal + gstTotal - disc) * 100) / 100;
    return { lineItems, subtotal, gstTotal, disc, totalAmount };
  }, [cart, applyGst, discountAmount]);

  // Auto sync single payment mode amounts
  useEffect(() => {
    const total = totals.totalAmount;
    if (paymentMode === 'cash') {
      setCashPaid(total);
      setOnlinePaid(0);
      setCardPaid(0);
      setCreditAmount(0);
    } else if (paymentMode === 'upi') {
      setCashPaid(0);
      setOnlinePaid(total);
      setCardPaid(0);
      setCreditAmount(0);
    } else if (paymentMode === 'card') {
      setCashPaid(0);
      setOnlinePaid(0);
      setCardPaid(total);
      setCreditAmount(0);
    } else if (paymentMode === 'credit') {
      setCashPaid(0);
      setOnlinePaid(0);
      setCardPaid(0);
      setCreditAmount(total);
    }
  }, [paymentMode, totals.totalAmount]);

  const handleCustomerSelect = (cid: string) => {
    setSelectedCustomerId(cid);
    if (!cid) {
      setCustomerName(labels.walkInCustomer);
      setCustomerPhone('');
      return;
    }
    const cust = customers.find((c) => c.id === cid);
    if (cust) {
      setCustomerName(cust.name);
      setCustomerPhone(cust.phone);
    }
  };

  const resetForm = () => {
    setCart([]);
    setSelectedCustomerId('');
    setCustomerName(labels.walkInCustomer);
    setCustomerPhone('');
    setDiscountAmount(0);
    setPaymentMode('cash');
    setNotes('');
    setEditingBillId(null);
  };

  const nextBillNumber = useMemo(() => {
    const num = bills.length + 1001;
    return `INV-${num}`;
  }, [bills.length]);

  const handleSubmitBill = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || submitting) return;
    if (cart.length === 0) {
      notify(lang === 'hi' ? 'कृपया कम से कम 1 उत्पाद जोड़ें।' : 'Add at least 1 product.', 'error');
      return;
    }

    const totalSplit =
      Math.round((Number(cashPaid) + Number(onlinePaid) + Number(cardPaid) + Number(creditAmount)) * 100) /
      100;
    if (Math.abs(totalSplit - totals.totalAmount) > 1) {
      notify(
        lang === 'hi'
          ? `भुगतान योग (${formatINR(totalSplit)}) बिल राशि (${formatINR(totals.totalAmount)}) के बराबर होना चाहिए।`
          : `Split payments (${formatINR(totalSplit)}) must equal bill total (${formatINR(totals.totalAmount)}).`,
        'error'
      );
      return;
    }

    if (creditAmount > 0 && !selectedCustomerId) {
      notify(
        lang === 'hi'
          ? 'उधार (Credit) बिल के लिए कृपया ग्राहक चुनें।'
          : 'Please select a registered customer for Credit / Udhaar billing.',
        'error'
      );
      return;
    }

    setSubmitting(true);
    try {
      if (editingBillId) {
        await editBill(user.uid, editingBillId, {
          customerId: selectedCustomerId,
          customerName: customerName.trim() || labels.walkInCustomer,
          customerPhone,
          items: totals.lineItems,
          subtotal: totals.subtotal,
          discountAmount: totals.disc,
          gstAmount: totals.gstTotal,
          totalAmount: totals.totalAmount,
          paymentMode,
          cashPaid: Number(cashPaid) || 0,
          onlinePaid: Number(onlinePaid) || 0,
          cardPaid: Number(cardPaid) || 0,
          creditAmount: Number(creditAmount) || 0,
          billDate,
          notes,
        });
        notify(lang === 'hi' ? 'बिल सफलतापूर्वक अपडेट हुआ!' : 'Bill updated successfully!');
      } else {
        await createBill(user.uid, {
          billNumber: nextBillNumber,
          customerId: selectedCustomerId,
          customerName: customerName.trim() || labels.walkInCustomer,
          customerPhone,
          items: totals.lineItems,
          subtotal: totals.subtotal,
          discountAmount: totals.disc,
          gstAmount: totals.gstTotal,
          totalAmount: totals.totalAmount,
          paymentMode,
          cashPaid: Number(cashPaid) || 0,
          onlinePaid: Number(onlinePaid) || 0,
          cardPaid: Number(cardPaid) || 0,
          creditAmount: Number(creditAmount) || 0,
          billDate,
          notes,
        });
        notify(lang === 'hi' ? 'नया बिल बन गया और स्टॉक अपडेट हो गया!' : 'Bill created & stock updated!');
      }
      resetForm();
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Failed to save bill', 'error');
    } finally {
      setSubmitting(false);
    }
  };

  const handleCancelBill = async (bill: Bill) => {
    if (!user) return;
    try {
      await cancelBill(user.uid, bill.id, lang === 'hi' ? 'ग्राहक द्वारा रद्द' : 'Cancelled by owner');
      notify(lang === 'hi' ? 'बिल रद्द और स्टॉक वापस जोड़ा गया।' : 'Bill cancelled & stock restored.');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Cancel failed', 'error');
    }
  };

  const handlePrintBill = (bill: Bill) => {
    openPrintModal({
      title: `${bill.billNumber} · ${bill.customerName}`,
      content: (
        <div className="space-y-4 text-sm text-slate-900">
          <div className="flex justify-between items-start border-b border-slate-300 pb-4">
            <div>
              <h2 className="text-xl font-bold">{shopProfile?.shopName || 'Dukaan'}</h2>
              {shopProfile?.address && <p className="text-xs text-slate-600">{shopProfile.address}</p>}
              {shopProfile?.phone && <p className="text-xs text-slate-600">Mob: {shopProfile.phone}</p>}
              {shopProfile?.gstin && <p className="text-xs font-mono">GSTIN: {shopProfile.gstin}</p>}
            </div>
            <div className="text-right">
              <p className="font-bold font-mono text-base">{bill.billNumber}</p>
              <p className="text-xs text-slate-600">{formatDisplayDate(bill.billDate, lang)}</p>
              <p className="text-xs mt-1 font-medium">
                {lang === 'hi' ? 'ग्राहक' : 'Customer'}: {bill.customerName}
              </p>
              {bill.customerPhone && <p className="text-xs">{bill.customerPhone}</p>}
            </div>
          </div>

          <table className="w-full text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-300 text-left">
                <th className="py-2">#</th>
                <th className="py-2">{lang === 'hi' ? 'सामान' : 'Item'}</th>
                <th className="py-2 text-right">{lang === 'hi' ? 'मात्रा' : 'Qty'}</th>
                <th className="py-2 text-right">{lang === 'hi' ? 'दर' : 'Rate'}</th>
                <th className="py-2 text-right">GST</th>
                <th className="py-2 text-right">{lang === 'hi' ? 'कुल' : 'Total'}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {bill.items.map((item, idx) => (
                <tr key={idx}>
                  <td className="py-2">{idx + 1}</td>
                  <td className="py-2 font-medium">{item.productName}</td>
                  <td className="py-2 text-right font-mono tabular-nums">
                    {item.qty} {item.unit}
                  </td>
                  <td className="py-2 text-right font-mono tabular-nums">{formatINR(item.unitPrice)}</td>
                  <td className="py-2 text-right font-mono tabular-nums">{item.gstRate}%</td>
                  <td className="py-2 text-right font-mono tabular-nums font-semibold">
                    {formatINR(item.lineTotal)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          <div className="border-t border-slate-300 pt-3 flex justify-end">
            <div className="w-64 space-y-1 text-xs">
              <div className="flex justify-between">
                <span>{lang === 'hi' ? 'उप-योग (Subtotal)' : 'Subtotal'}:</span>
                <span className="font-mono tabular-nums">{formatINR(bill.subtotal)}</span>
              </div>
              <div className="flex justify-between">
                <span>GST:</span>
                <span className="font-mono tabular-nums">{formatINR(bill.gstAmount)}</span>
              </div>
              {bill.discountAmount > 0 && (
                <div className="flex justify-between text-emerald-700">
                  <span>{lang === 'hi' ? 'छूट (Discount)' : 'Discount'}:</span>
                  <span className="font-mono tabular-nums">-{formatINR(bill.discountAmount)}</span>
                </div>
              )}
              <div className="flex justify-between font-bold text-base border-t border-slate-300 pt-2">
                <span>{lang === 'hi' ? 'कुल देय राशि' : 'Grand Total'}:</span>
                <span className="font-mono tabular-nums">{formatINR(bill.totalAmount)}</span>
              </div>
              <div className="flex justify-between text-slate-600 pt-1">
                <span>{lang === 'hi' ? 'भुगतान प्राप्त' : 'Paid'}:</span>
                <span className="font-mono tabular-nums">{formatINR(bill.paidAmount)}</span>
              </div>
              {bill.creditAmount > 0 && (
                <div className="flex justify-between text-red-700 font-semibold">
                  <span>{lang === 'hi' ? 'उधार शेष' : 'Credit Balance'}:</span>
                  <span className="font-mono tabular-nums">{formatINR(bill.creditAmount)}</span>
                </div>
              )}
            </div>
          </div>

          <p className="text-center text-xs text-slate-500 pt-4 border-t border-slate-200">
            {lang === 'hi' ? 'खरीदारी के लिए धन्यवाद! फिर पधारें।' : 'Thank you for shopping with us!'}
          </p>
        </div>
      ),
    });
  };

  const handleWhatsAppBill = (bill: Bill) => {
    const itemsText = bill.items
      .map((i) => `• ${i.productName} (${i.qty} ${i.unit}) = ${formatINR(i.lineTotal)}`)
      .join('\n');
    const msg =
      lang === 'hi'
        ? `*${shopProfile?.shopName || 'दुकान'}*\nबिल नं: ${bill.billNumber}\nतिथि: ${bill.billDate}\nग्राहक: ${bill.customerName}\n\n${itemsText}\n\nकुल राशि: *${formatINR(bill.totalAmount)}*\nभुगतान: ${formatINR(bill.paidAmount)}${bill.creditAmount > 0 ? `\nउधार बाकी: ${formatINR(bill.creditAmount)}` : ''}\nधन्यवाद!`
        : `*${shopProfile?.shopName || 'Shop'}*\nBill: ${bill.billNumber}\nDate: ${bill.billDate}\nCustomer: ${bill.customerName}\n\n${itemsText}\n\nGrand Total: *${formatINR(bill.totalAmount)}*\nPaid: ${formatINR(bill.paidAmount)}${bill.creditAmount > 0 ? `\nBalance Due: ${formatINR(bill.creditAmount)}` : ''}\nThank you!`;
    const url = buildWhatsAppUrl(bill.customerPhone || '', msg);
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  const filteredBills = useMemo(() => {
    const q = billSearch.trim().toLowerCase();
    if (!q) return bills.slice(0, 20);
    return bills.filter(
      (b) =>
        b.billNumber.toLowerCase().includes(q) ||
        b.customerName.toLowerCase().includes(q) ||
        (b.customerPhone || '').includes(q)
    );
  }, [bills, billSearch]);

  return (
    <div className="space-y-8">
      <form onSubmit={handleSubmitBill} className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left: Product Search & Quick Add */}
        <div className="lg:col-span-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 space-y-4">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={handleSearchKeyDown}
              placeholder={
                lang === 'hi'
                  ? 'नाम, बारकोड या SKU से खोजें (Enter दबाएं)...'
                  : 'Search by name, barcode or SKU (press Enter)...'
              }
              className="w-full h-11 pl-10 pr-4 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600"
            />
          </div>

          {products.length === 0 ? (
            <p className="text-sm text-slate-500 dark:text-slate-400 py-8 text-center">
              {lang === 'hi'
                ? 'पहले "सामान / उत्पाद" सेक्शन में उत्पाद जोड़ें।'
                : 'Add products in the Products section first.'}
            </p>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 max-h-[420px] overflow-y-auto pr-1">
              {filteredProducts.map((prod) => (
                <button
                  key={prod.id}
                  type="button"
                  onClick={() => addProductToCart(prod)}
                  className="text-left p-3 rounded-xl border border-slate-200 dark:border-slate-800 hover:border-emerald-600 hover:bg-emerald-50/40 dark:hover:bg-emerald-950/20 transition-colors cursor-pointer space-y-1"
                >
                  <p className="text-sm font-semibold text-slate-900 dark:text-slate-100 truncate">
                    {prod.name}
                  </p>
                  <div className="flex items-center justify-between gap-2 text-xs">
                    <span className="font-mono tabular-nums font-bold text-emerald-700 dark:text-emerald-400">
                      {formatINR(prod.sellingPrice)}
                    </span>
                    <span
                      className={`font-mono tabular-nums ${
                        prod.stockQty <= prod.minStockAlert
                          ? 'text-red-600 dark:text-red-400'
                          : 'text-slate-500 dark:text-slate-400'
                      }`}
                    >
                      {prod.stockQty} {prod.unit}
                    </span>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Right: Active Bill Cart & Checkout */}
        <div className="lg:col-span-7 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 dark:border-slate-800 pb-3">
            <div>
              <h2 className="text-base font-bold">
                {editingBillId
                  ? lang === 'hi'
                    ? 'बिल संशोधन (Edit Bill)'
                    : 'Edit Bill'
                  : `${lang === 'hi' ? 'नया बिल' : 'New Bill'} · ${nextBillNumber}`}
              </h2>
            </div>
            <div className="flex items-center gap-2">
              <input
                type="date"
                value={billDate}
                onChange={(e) => setBillDate(e.target.value)}
                className="h-9 px-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-xs font-mono"
              />
              {editingBillId && (
                <button
                  type="button"
                  onClick={resetForm}
                  className="px-3 h-9 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-semibold cursor-pointer"
                >
                  {labels.cancel}
                </button>
              )}
            </div>
          </div>

          {/* Customer Selector */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <select
              value={selectedCustomerId}
              onChange={(e) => handleCustomerSelect(e.target.value)}
              className="h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm"
            >
              <option value="">{labels.walkInCustomer}</option>
              {customers.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name} ({c.phone || '-'})
                </option>
              ))}
            </select>
            <input
              type="text"
              value={customerName}
              onChange={(e) => setCustomerName(e.target.value)}
              placeholder={lang === 'hi' ? 'ग्राहक का नाम' : 'Customer Name'}
              className="h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm"
            />
            <input
              type="tel"
              value={customerPhone}
              onChange={(e) => setCustomerPhone(e.target.value)}
              placeholder={lang === 'hi' ? 'मोबाइल नंबर' : 'Phone Number'}
              className="h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm font-mono"
            />
          </div>

          {/* Cart Items */}
          {cart.length === 0 ? (
            <div className="py-10 text-center text-sm text-slate-500 dark:text-slate-400 border border-dashed border-slate-200 dark:border-slate-800 rounded-xl">
              {lang === 'hi'
                ? 'बाईं ओर से उत्पाद चुनें या बारकोड स्कैन करें।'
                : 'Select products from the left or scan barcode.'}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-800 text-left text-xs text-slate-500">
                    <th className="py-2 pr-2">{lang === 'hi' ? 'सामान' : 'Item'}</th>
                    <th className="py-2 px-2 text-center">{lang === 'hi' ? 'मात्रा' : 'Qty'}</th>
                    <th className="py-2 px-2 text-right">{lang === 'hi' ? 'दर (₹)' : 'Rate'}</th>
                    <th className="py-2 pl-2 text-right">{lang === 'hi' ? 'योग' : 'Total'}</th>
                    <th className="py-2 w-8" />
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {cart.map((row, idx) => {
                    const line = totals.lineItems[idx];
                    return (
                      <tr key={row.productId}>
                        <td className="py-2.5 pr-2">
                          <p className="font-medium text-slate-900 dark:text-slate-100">{row.productName}</p>
                          <p className="text-xs text-slate-500">
                            {row.unit} {applyGst ? `· GST ${row.gstRate}%` : ''}
                          </p>
                        </td>
                        <td className="py-2.5 px-2">
                          <div className="inline-flex items-center gap-1 bg-slate-100 dark:bg-slate-800 rounded-lg p-0.5">
                            <button
                              type="button"
                              onClick={() =>
                                setCart((prev) =>
                                  prev
                                    .map((c, i) =>
                                      i === idx ? { ...c, qty: Math.max(0, c.qty - 1) } : c
                                    )
                                    .filter((c) => c.qty > 0)
                                )
                              }
                              className="w-7 h-7 flex items-center justify-center rounded-md hover:bg-white dark:hover:bg-slate-700 cursor-pointer"
                            >
                              <Minus className="w-3.5 h-3.5" />
                            </button>
                            <input
                              type="number"
                              step="any"
                              min="0.01"
                              value={row.qty}
                              onChange={(e) => {
                                const val = Math.max(0.01, Number(e.target.value) || 0);
                                setCart((prev) =>
                                  prev.map((c, i) => (i === idx ? { ...c, qty: val } : c))
                                );
                              }}
                              className="w-12 text-center bg-transparent font-mono text-xs font-semibold focus:outline-none"
                            />
                            <button
                              type="button"
                              onClick={() =>
                                setCart((prev) =>
                                  prev.map((c, i) => (i === idx ? { ...c, qty: c.qty + 1 } : c))
                                )
                              }
                              className="w-7 h-7 flex items-center justify-center rounded-md hover:bg-white dark:hover:bg-slate-700 cursor-pointer"
                            >
                              <Plus className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                        <td className="py-2.5 px-2 text-right">
                          <input
                            type="number"
                            step="any"
                            min="0"
                            value={row.unitPrice}
                            onChange={(e) => {
                              const val = Math.max(0, Number(e.target.value) || 0);
                              setCart((prev) =>
                                prev.map((c, i) => (i === idx ? { ...c, unitPrice: val } : c))
                              );
                            }}
                            className="w-20 h-8 px-2 text-right rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono text-xs"
                          />
                        </td>
                        <td className="py-2.5 pl-2 text-right font-mono tabular-nums font-semibold">
                          {formatINR(line?.lineTotal || 0)}
                        </td>
                        <td className="py-2.5 pl-2 text-right">
                          <button
                            type="button"
                            onClick={() => setCart((prev) => prev.filter((_, i) => i !== idx))}
                            className="text-red-500 hover:text-red-700 cursor-pointer p-1"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}

          {/* Discount, GST & Summary */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-3 border-t border-slate-200 dark:border-slate-800">
            <div className="space-y-3">
              <div className="flex items-center justify-between gap-2">
                <label className="text-xs font-medium text-slate-600 dark:text-slate-400">
                  {lang === 'hi' ? 'छूट (Discount ₹)' : 'Discount (₹)'}
                </label>
                <input
                  type="number"
                  min="0"
                  step="any"
                  value={discountAmount}
                  onChange={(e) => setDiscountAmount(Math.max(0, Number(e.target.value) || 0))}
                  className="w-28 h-9 px-2.5 text-right rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono text-sm"
                />
              </div>

              <label className="flex items-center gap-2 text-xs font-medium text-slate-700 dark:text-slate-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={applyGst}
                  onChange={(e) => setApplyGst(e.target.checked)}
                  className="w-4 h-4 accent-emerald-700"
                />
                {lang === 'hi' ? 'GST लागू करें' : 'Apply Product GST'}
              </label>

              <input
                type="text"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder={lang === 'hi' ? 'बिल नोट (वैकल्पिक)' : 'Bill notes (optional)'}
                className="w-full h-9 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-xs"
              />
            </div>

            <div className="bg-slate-50 dark:bg-slate-950 rounded-xl p-3.5 space-y-1.5 text-sm">
              <div className="flex justify-between text-xs text-slate-600 dark:text-slate-400">
                <span>{lang === 'hi' ? 'उप-योग' : 'Subtotal'}</span>
                <span className="font-mono tabular-nums">{formatINR(totals.subtotal)}</span>
              </div>
              <div className="flex justify-between text-xs text-slate-600 dark:text-slate-400">
                <span>GST</span>
                <span className="font-mono tabular-nums">{formatINR(totals.gstTotal)}</span>
              </div>
              <div className="flex justify-between text-xs text-emerald-700 dark:text-emerald-400">
                <span>{lang === 'hi' ? 'छूट' : 'Discount'}</span>
                <span className="font-mono tabular-nums">-{formatINR(totals.disc)}</span>
              </div>
              <div className="flex justify-between text-lg font-bold pt-1.5 border-t border-slate-200 dark:border-slate-800">
                <span>{lang === 'hi' ? 'कुल राशि' : 'Grand Total'}</span>
                <span className="font-mono tabular-nums text-emerald-700 dark:text-emerald-400">
                  {formatINR(totals.totalAmount)}
                </span>
              </div>
            </div>
          </div>

          {/* Payment Mode Selector */}
          <div className="space-y-3">
            <div className="flex flex-wrap gap-1.5">
              {(['cash', 'upi', 'card', 'credit', 'mixed'] as PaymentMode[]).map((mode) => (
                <button
                  key={mode}
                  type="button"
                  onClick={() => setPaymentMode(mode)}
                  className={`px-3.5 h-10 rounded-xl text-xs font-semibold border transition-colors cursor-pointer ${
                    paymentMode === mode
                      ? 'bg-emerald-700 border-emerald-700 text-white'
                      : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                  }`}
                >
                  {labels[mode]}
                </button>
              ))}
            </div>

            {paymentMode === 'mixed' && (
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 bg-slate-50 dark:bg-slate-950 p-3 rounded-xl">
                <div>
                  <label className="text-[11px] text-slate-500">{labels.cash}</label>
                  <input
                    type="number"
                    min="0"
                    step="any"
                    value={cashPaid}
                    onChange={(e) => setCashPaid(Math.max(0, Number(e.target.value) || 0))}
                    className="w-full h-9 px-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 font-mono text-xs"
                  />
                </div>
                <div>
                  <label className="text-[11px] text-slate-500">UPI</label>
                  <input
                    type="number"
                    min="0"
                    step="any"
                    value={onlinePaid}
                    onChange={(e) => setOnlinePaid(Math.max(0, Number(e.target.value) || 0))}
                    className="w-full h-9 px-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 font-mono text-xs"
                  />
                </div>
                <div>
                  <label className="text-[11px] text-slate-500">{labels.card}</label>
                  <input
                    type="number"
                    min="0"
                    step="any"
                    value={cardPaid}
                    onChange={(e) => setCardPaid(Math.max(0, Number(e.target.value) || 0))}
                    className="w-full h-9 px-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 font-mono text-xs"
                  />
                </div>
                <div>
                  <label className="text-[11px] text-slate-500">{labels.credit}</label>
                  <input
                    type="number"
                    min="0"
                    step="any"
                    value={creditAmount}
                    onChange={(e) => setCreditAmount(Math.max(0, Number(e.target.value) || 0))}
                    className="w-full h-9 px-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 font-mono text-xs"
                  />
                </div>
              </div>
            )}

            <button
              type="submit"
              disabled={submitting || cart.length === 0}
              className="w-full h-12 rounded-xl bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white font-bold text-sm flex items-center justify-center gap-2 transition-colors cursor-pointer"
            >
              <CheckCircle2 className="w-4 h-4" />
              {submitting
                ? lang === 'hi'
                  ? 'बिल सेव हो रहा है...'
                  : 'Saving Bill...'
                : editingBillId
                  ? lang === 'hi'
                    ? 'संशोधित बिल सेव करें'
                    : 'Save Edited Bill'
                  : lang === 'hi'
                    ? `बिल सेव करें (${formatINR(totals.totalAmount)})`
                    : `Complete Bill (${formatINR(totals.totalAmount)})`}
            </button>
          </div>
        </div>
      </form>

      {/* Recent Bills History with Print, WhatsApp, Edit & Cancel */}
      <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h2 className="text-base font-bold">
            {lang === 'hi' ? 'हाल के बिल एवं चालान' : 'Recent Bills & Invoices'}
          </h2>
          <div className="relative w-full sm:w-72">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
            <input
              type="text"
              value={billSearch}
              onChange={(e) => setBillSearch(e.target.value)}
              placeholder={lang === 'hi' ? 'बिल नं या ग्राहक से खोजें...' : 'Search bill # or customer...'}
              className="w-full h-10 pl-9 pr-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-xs"
            />
          </div>
        </div>

        {filteredBills.length === 0 ? (
          <p className="text-sm text-slate-500 py-6 text-center">{labels.noData}</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-left text-xs text-slate-500">
                  <th className="py-2.5 pr-3">{lang === 'hi' ? 'बिल नं' : 'Bill #'}</th>
                  <th className="py-2.5 pr-3">{lang === 'hi' ? 'तिथि' : 'Date'}</th>
                  <th className="py-2.5 pr-3">{lang === 'hi' ? 'ग्राहक' : 'Customer'}</th>
                  <th className="py-2.5 pr-3">{lang === 'hi' ? 'माध्यम' : 'Mode'}</th>
                  <th className="py-2.5 pr-3 text-right">{lang === 'hi' ? 'राशि' : 'Total'}</th>
                  <th className="py-2.5 pr-3 text-right">{lang === 'hi' ? 'स्थिति' : 'Status'}</th>
                  <th className="py-2.5 text-right">{lang === 'hi' ? 'कार्रवाई' : 'Actions'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filteredBills.map((bill) => (
                  <tr key={bill.id}>
                    <td className="py-3 pr-3 font-mono font-semibold whitespace-nowrap">{bill.billNumber}</td>
                    <td className="py-3 pr-3 font-mono tabular-nums text-xs text-slate-500 whitespace-nowrap">
                      {bill.billDate}
                    </td>
                    <td className="py-3 pr-3">
                      <p className="font-medium">{bill.customerName}</p>
                      <p className="text-xs text-slate-500">
                        {bill.items.length} {lang === 'hi' ? 'आइटम' : 'items'}
                      </p>
                    </td>
                    <td className="py-3 pr-3 text-xs whitespace-nowrap">{labels[bill.paymentMode]}</td>
                    <td className="py-3 pr-3 text-right font-mono tabular-nums font-bold whitespace-nowrap">
                      {formatINR(bill.totalAmount)}
                    </td>
                    <td
                      className={`py-3 pr-3 text-right text-xs font-semibold whitespace-nowrap ${
                        bill.status === 'cancelled'
                          ? 'text-red-600'
                          : bill.status === 'edited'
                            ? 'text-amber-600'
                            : 'text-emerald-700 dark:text-emerald-400'
                      }`}
                    >
                      {labels[bill.status]}
                    </td>
                    <td className="py-3 text-right whitespace-nowrap">
                      <div className="inline-flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => handlePrintBill(bill)}
                          title={labels.printPdf}
                          className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 cursor-pointer"
                        >
                          <Printer className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleWhatsAppBill(bill)}
                          title={labels.whatsappShare}
                          className="p-2 rounded-lg hover:bg-emerald-50 dark:hover:bg-emerald-950 text-emerald-700 dark:text-emerald-400 cursor-pointer"
                        >
                          <MessageCircle className="w-4 h-4" />
                        </button>
                        {bill.status !== 'cancelled' && (
                          <>
                            <button
                              type="button"
                              onClick={() => {
                                setEditingBillId(bill.id);
                                window.scrollTo({ top: 0, behavior: 'smooth' });
                              }}
                              title={labels.edit}
                              className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-sky-700 dark:text-sky-400 cursor-pointer"
                            >
                              <Edit3 className="w-4 h-4" />
                            </button>
                            <button
                              type="button"
                              onClick={() => handleCancelBill(bill)}
                              title={lang === 'hi' ? 'बिल रद्द करें' : 'Cancel Bill'}
                              className="p-2 rounded-lg hover:bg-red-50 dark:hover:bg-red-950 text-red-600 cursor-pointer"
                            >
                              <XCircle className="w-4 h-4" />
                            </button>
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
};
