import React, { useMemo, useState } from 'react';
import { ArrowUpRight, CheckSquare, History, Search, TrendingUp, X } from 'lucide-react';
import { useDukaan } from '../context/DukaanContext';
import { calculateProfitMargin, formatINR, formatTimestamp } from '../lib/formatters';
import { t } from '../lib/i18n';
import { bulkUpdatePrices, updateProductPrice } from '../services/dukaanService';
import { PriceType, Product } from '../types/dukaan';

type PriceTab = 'manage' | 'cost_up' | 'history';

export const PriceManagementPage: React.FC = () => {
  const { user, lang, products, priceHistory, notify } = useDukaan();
  const labels = t(lang);

  const [tab, setTab] = useState<PriceTab>('manage');
  const [search, setSearch] = useState('');
  const [selectedIds, setSelectedIds] = useState<string[]>([]);

  // Single edit modal
  const [editProd, setEditProd] = useState<Product | null>(null);
  const [pPurchase, setPPurchase] = useState(0);
  const [pSelling, setPSelling] = useState(0);
  const [pWholesale, setPWholesale] = useState(0);
  const [pMrp, setPMrp] = useState(0);
  const [pReason, setPReason] = useState('');
  const [saving, setSaving] = useState(false);

  // Bulk update modal
  const [bulkOpen, setBulkOpen] = useState(false);
  const [bulkPriceType, setBulkPriceType] = useState<PriceType>('selling');
  const [bulkMode, setBulkMode] = useState<'percent' | 'fixed'>('percent');
  const [bulkDelta, setBulkDelta] = useState(5);
  const [bulkReason, setBulkReason] = useState('');

  // Products whose purchase price increased in history
  const purchaseIncreasedMap = useMemo(() => {
    const map = new Map<string, { prev: number; next: number; when: string }>();
    for (const h of priceHistory) {
      if (h.priceType === 'purchase' && h.newPrice > h.previousPrice && !map.has(h.productId)) {
        map.set(h.productId, {
          prev: h.previousPrice,
          next: h.newPrice,
          when: formatTimestamp(h.createdAt, lang),
        });
      }
    }
    return map;
  }, [priceHistory, lang]);

  const filteredProducts = useMemo(() => {
    const q = search.trim().toLowerCase();
    const base =
      tab === 'cost_up'
        ? products.filter((p) => purchaseIncreasedMap.has(p.id))
        : products;
    if (!q) return base;
    return base.filter(
      (p) =>
        p.name.toLowerCase().includes(q) ||
        p.category.toLowerCase().includes(q) ||
        (p.barcode || '').toLowerCase().includes(q)
    );
  }, [products, tab, purchaseIncreasedMap, search]);

  const filteredHistory = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return priceHistory;
    return priceHistory.filter(
      (h) =>
        h.productName.toLowerCase().includes(q) ||
        h.changeReason.toLowerCase().includes(q) ||
        h.priceType.toLowerCase().includes(q)
    );
  }, [priceHistory, search]);

  const openEditPrice = (p: Product) => {
    setEditProd(p);
    setPPurchase(p.purchasePrice);
    setPSelling(p.sellingPrice);
    setPWholesale(p.wholesalePrice ?? p.sellingPrice);
    setPMrp(p.mrp);
    setPReason('');
  };

  const handleSingleUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !editProd || saving) return;
    if (!pReason.trim()) {
      notify(lang === 'hi' ? 'कृपया कीमत बदलने का कारण लिखें।' : 'Please enter a reason for price change.', 'error');
      return;
    }
    setSaving(true);
    try {
      await updateProductPrice(
        user.uid,
        editProd.id,
        {
          purchasePrice: pPurchase,
          sellingPrice: pSelling,
          wholesalePrice: pWholesale,
          mrp: pMrp,
        },
        pReason.trim()
      );
      notify(
        lang === 'hi'
          ? 'नई कीमत सेव हुई और पुराना मूल्य इतिहास सुरक्षित रखा गया!'
          : 'Price updated & old price history preserved!'
      );
      setEditProd(null);
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Update failed', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleBulkSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || selectedIds.length === 0 || saving) return;
    if (!bulkReason.trim()) {
      notify(lang === 'hi' ? 'कृपया थोक बदलाव का कारण लिखें।' : 'Please enter bulk change reason.', 'error');
      return;
    }
    setSaving(true);
    try {
      const count = await bulkUpdatePrices(
        user.uid,
        selectedIds,
        bulkPriceType,
        bulkMode,
        bulkDelta,
        bulkReason.trim()
      );
      notify(
        lang === 'hi'
          ? `${count} उत्पादों की कीमत अपडेट हुई और इतिहास में दर्ज की गई!`
          : `Updated prices for ${count} products with full history!`
      );
      setBulkOpen(false);
      setSelectedIds([]);
      setBulkReason('');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Bulk update failed', 'error');
    } finally {
      setSaving(false);
    }
  };

  const toggleSelect = (id: string) => {
    setSelectedIds((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
  };

  const toggleSelectAll = () => {
    if (selectedIds.length === filteredProducts.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(filteredProducts.map((p) => p.id));
    }
  };

  const liveMargin = calculateProfitMargin(pPurchase, pSelling);

  return (
    <div className="space-y-6">
      {/* Tabs & Bulk Action */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-100 dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800">
          {(
            [
              ['manage', lang === 'hi' ? 'मूल्य प्रबंधन' : 'Manage Prices'],
              [
                'cost_up',
                `${lang === 'hi' ? 'खरीद मूल्य बढ़े' : 'Purchase Cost Increased'} (${purchaseIncreasedMap.size})`,
              ],
              ['history', `${lang === 'hi' ? 'मूल्य इतिहास' : 'Price History'} (${priceHistory.length})`],
            ] as [PriceTab, string][]
          ).map(([id, label]) => (
            <button
              key={id}
              type="button"
              onClick={() => setTab(id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                tab === id
                  ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 shadow-sm'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              {label}
            </button>
          ))}
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <div className="relative w-56 sm:w-64">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder={labels.search}
              className="w-full h-10 pl-9 pr-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm"
            />
          </div>
          {tab !== 'history' && selectedIds.length > 0 && (
            <button
              type="button"
              onClick={() => setBulkOpen(true)}
              className="inline-flex items-center gap-1.5 px-4 h-10 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-semibold cursor-pointer whitespace-nowrap"
            >
              <CheckSquare className="w-4 h-4" />
              {lang === 'hi'
                ? `एक साथ बदलें (${selectedIds.length})`
                : `Bulk Update (${selectedIds.length})`}
            </button>
          )}
        </div>
      </div>

      {/* Product Pricing Table OR Immutable Price History */}
      {tab !== 'history' ? (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-left text-xs text-slate-500 bg-slate-50/70 dark:bg-slate-950/50">
                  <th className="py-3 px-4 w-10">
                    <input
                      type="checkbox"
                      checked={
                        filteredProducts.length > 0 && selectedIds.length === filteredProducts.length
                      }
                      onChange={toggleSelectAll}
                      className="w-4 h-4 accent-emerald-700 cursor-pointer"
                    />
                  </th>
                  <th className="py-3 px-3">{lang === 'hi' ? 'उत्पाद' : 'Product'}</th>
                  <th className="py-3 px-3 text-right">{lang === 'hi' ? 'खरीद मूल्य' : 'Purchase'}</th>
                  <th className="py-3 px-3 text-right">{lang === 'hi' ? 'बिक्री मूल्य' : 'Selling'}</th>
                  <th className="py-3 px-3 text-right">{lang === 'hi' ? 'थोक मूल्य' : 'Wholesale'}</th>
                  <th className="py-3 px-3 text-right">MRP</th>
                  <th className="py-3 px-3 text-right">{lang === 'hi' ? 'लाभ मार्जिन' : 'Margin'}</th>
                  <th className="py-3 px-4 text-right">{lang === 'hi' ? 'कीमत बदलें' : 'Update'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filteredProducts.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="py-8 text-center text-slate-500">
                      {labels.noData}
                    </td>
                  </tr>
                ) : (
                  filteredProducts.map((p) => {
                    const margin = calculateProfitMargin(p.purchasePrice, p.sellingPrice);
                    const costAlert = purchaseIncreasedMap.get(p.id);
                    return (
                      <tr key={p.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                        <td className="py-3 px-4">
                          <input
                            type="checkbox"
                            checked={selectedIds.includes(p.id)}
                            onChange={() => toggleSelect(p.id)}
                            className="w-4 h-4 accent-emerald-700 cursor-pointer"
                          />
                        </td>
                        <td className="py-3 px-3">
                          <p className="font-semibold">{p.name}</p>
                          {costAlert && (
                            <p className="text-[11px] text-amber-700 dark:text-amber-400 inline-flex items-center gap-1">
                              <ArrowUpRight className="w-3 h-3" />
                              {lang === 'hi' ? 'खरीद दर बढ़ी:' : 'Cost increased:'}{' '}
                              {formatINR(costAlert.prev)} → {formatINR(costAlert.next)}
                            </p>
                          )}
                        </td>
                        <td className="py-3 px-3 text-right font-mono tabular-nums">
                          {formatINR(p.purchasePrice)}
                        </td>
                        <td className="py-3 px-3 text-right font-mono tabular-nums font-bold text-emerald-700 dark:text-emerald-400">
                          {formatINR(p.sellingPrice)}
                        </td>
                        <td className="py-3 px-3 text-right font-mono tabular-nums">
                          {formatINR(p.wholesalePrice ?? p.sellingPrice)}
                        </td>
                        <td className="py-3 px-3 text-right font-mono tabular-nums text-slate-500">
                          {formatINR(p.mrp)}
                        </td>
                        <td
                          className={`py-3 px-3 text-right font-mono tabular-nums font-semibold ${
                            margin < 5 ? 'text-red-600' : 'text-emerald-700 dark:text-emerald-400'
                          }`}
                        >
                          {margin}%
                        </td>
                        <td className="py-3 px-4 text-right">
                          <button
                            type="button"
                            onClick={() => openEditPrice(p)}
                            className="inline-flex items-center gap-1.5 px-3 h-9 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold cursor-pointer whitespace-nowrap"
                          >
                            <TrendingUp className="w-3.5 h-3.5" />
                            {lang === 'hi' ? 'कीमत बदलें' : 'Update Price'}
                          </button>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-left text-xs text-slate-500 bg-slate-50/70 dark:bg-slate-950/50">
                  <th className="py-3 px-4">{lang === 'hi' ? 'कब बदला गया' : 'Changed At'}</th>
                  <th className="py-3 px-3">{lang === 'hi' ? 'उत्पाद' : 'Product'}</th>
                  <th className="py-3 px-3">{lang === 'hi' ? 'मूल्य प्रकार' : 'Price Type'}</th>
                  <th className="py-3 px-3 text-right">{lang === 'hi' ? 'पुरानी कीमत' : 'Old Price'}</th>
                  <th className="py-3 px-3 text-right">{lang === 'hi' ? 'नई कीमत' : 'New Price'}</th>
                  <th className="py-3 px-3 text-right">{lang === 'hi' ? 'मार्जिन %' : 'Margin %'}</th>
                  <th className="py-3 px-4">{lang === 'hi' ? 'कारण' : 'Reason'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filteredHistory.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="py-8 text-center text-slate-500">
                      <History className="w-6 h-6 mx-auto mb-1 opacity-50" />
                      {labels.noData}
                    </td>
                  </tr>
                ) : (
                  filteredHistory.map((h) => (
                    <tr key={h.id}>
                      <td className="py-3 px-4 font-mono text-xs text-slate-500 whitespace-nowrap">
                        {formatTimestamp(h.createdAt, lang)}
                      </td>
                      <td className="py-3 px-3 font-medium">{h.productName}</td>
                      <td className="py-3 px-3 text-xs capitalize">{h.priceType}</td>
                      <td className="py-3 px-3 text-right font-mono tabular-nums text-slate-500 line-through">
                        {formatINR(h.previousPrice)}
                      </td>
                      <td
                        className={`py-3 px-3 text-right font-mono tabular-nums font-bold ${
                          h.newPrice > h.previousPrice ? 'text-amber-600' : 'text-emerald-700 dark:text-emerald-400'
                        }`}
                      >
                        {formatINR(h.newPrice)}
                      </td>
                      <td className="py-3 px-3 text-right font-mono tabular-nums text-xs">
                        {h.profitMarginPercent}%
                      </td>
                      <td className="py-3 px-4 text-xs text-slate-600 dark:text-slate-400">
                        {h.changeReason}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Single Product Smart Price Update Modal */}
      {editProd && (
        <div className="fixed inset-0 z-50 bg-black/55 backdrop-blur-sm flex items-center justify-center p-4">
          <form
            onSubmit={handleSingleUpdate}
            className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-md w-full p-5 space-y-4"
          >
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-base truncate">{editProd.name}</h3>
              <button
                type="button"
                onClick={() => setEditProd(null)}
                className="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs text-slate-500 mb-1">
                  {lang === 'hi' ? 'खरीद मूल्य (₹)' : 'Purchase Price (₹)'}
                </label>
                <input
                  type="number"
                  min="0"
                  step="any"
                  value={pPurchase}
                  onChange={(e) => setPPurchase(Number(e.target.value) || 0)}
                  className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono text-sm"
                />
              </div>
              <div>
                <label className="block text-xs text-slate-500 mb-1">
                  {lang === 'hi' ? 'बिक्री मूल्य (₹)' : 'Selling Price (₹)'}
                </label>
                <input
                  type="number"
                  min="0"
                  step="any"
                  value={pSelling}
                  onChange={(e) => setPSelling(Number(e.target.value) || 0)}
                  className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono text-sm"
                />
              </div>
              <div>
                <label className="block text-xs text-slate-500 mb-1">
                  {lang === 'hi' ? 'थोक मूल्य (₹)' : 'Wholesale Price (₹)'}
                </label>
                <input
                  type="number"
                  min="0"
                  step="any"
                  value={pWholesale}
                  onChange={(e) => setPWholesale(Number(e.target.value) || 0)}
                  className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono text-sm"
                />
              </div>
              <div>
                <label className="block text-xs text-slate-500 mb-1">MRP (₹)</label>
                <input
                  type="number"
                  min="0"
                  step="any"
                  value={pMrp}
                  onChange={(e) => setPMrp(Number(e.target.value) || 0)}
                  className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono text-sm"
                />
              </div>
            </div>

            <div className="bg-slate-50 dark:bg-slate-950 rounded-xl p-3 flex items-center justify-between text-sm">
              <span className="text-slate-600 dark:text-slate-400">
                {lang === 'hi' ? 'नया लाभ मार्जिन:' : 'New Profit Margin:'}
              </span>
              <span
                className={`font-mono font-bold ${
                  liveMargin >= 0 ? 'text-emerald-700 dark:text-emerald-400' : 'text-red-600'
                }`}
              >
                {liveMargin}% ({formatINR(pSelling - pPurchase)})
              </span>
            </div>

            <div>
              <label className="block text-xs text-slate-500 mb-1">
                {lang === 'hi' ? 'कीमत बदलने का कारण *' : 'Reason for Price Change *'}
              </label>
              <input
                required
                type="text"
                value={pReason}
                onChange={(e) => setPReason(e.target.value)}
                placeholder={
                  lang === 'hi' ? 'जैसे: थोक बाजार रेट बढ़ा / त्योहार छूट' : 'e.g., Supplier rate increased'
                }
                className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm"
              />
            </div>

            <button
              type="submit"
              disabled={saving}
              className="w-full h-11 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-semibold text-sm cursor-pointer"
            >
              {saving ? '...' : labels.save}
            </button>
          </form>
        </div>
      )}

      {/* Bulk Price Update Modal */}
      {bulkOpen && (
        <div className="fixed inset-0 z-50 bg-black/55 backdrop-blur-sm flex items-center justify-center p-4">
          <form
            onSubmit={handleBulkSubmit}
            className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-md w-full p-5 space-y-4"
          >
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-base">
                {lang === 'hi'
                  ? `${selectedIds.length} उत्पादों की कीमत एक साथ बदलें`
                  : `Bulk Update (${selectedIds.length} Products)`}
              </h3>
              <button
                type="button"
                onClick={() => setBulkOpen(false)}
                className="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs text-slate-500 mb-1">
                  {lang === 'hi' ? 'कौन सा मूल्य' : 'Price Field'}
                </label>
                <select
                  value={bulkPriceType}
                  onChange={(e) => setBulkPriceType(e.target.value as PriceType)}
                  className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm"
                >
                  <option value="selling">{lang === 'hi' ? 'बिक्री मूल्य' : 'Selling Price'}</option>
                  <option value="purchase">{lang === 'hi' ? 'खरीद मूल्य' : 'Purchase Price'}</option>
                  <option value="wholesale">{lang === 'hi' ? 'थोक मूल्य' : 'Wholesale Price'}</option>
                  <option value="mrp">MRP</option>
                </select>
              </div>
              <div>
                <label className="block text-xs text-slate-500 mb-1">
                  {lang === 'hi' ? 'प्रकार' : 'Adjustment Type'}
                </label>
                <select
                  value={bulkMode}
                  onChange={(e) => setBulkMode(e.target.value as 'percent' | 'fixed')}
                  className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm"
                >
                  <option value="percent">{lang === 'hi' ? 'प्रतिशत (%)' : 'Percentage (%)'}</option>
                  <option value="fixed">{lang === 'hi' ? 'निश्चित राशि (₹)' : 'Fixed Amount (₹)'}</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs text-slate-500 mb-1">
                {lang === 'hi'
                  ? 'बदलाव (+/- जैसे 5 या -10)'
                  : 'Delta (+/- e.g. 5 to increase, -10 to decrease)'}
              </label>
              <input
                required
                type="number"
                step="any"
                value={bulkDelta}
                onChange={(e) => setBulkDelta(Number(e.target.value) || 0)}
                className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono text-sm"
              />
            </div>

            <div>
              <label className="block text-xs text-slate-500 mb-1">
                {lang === 'hi' ? 'कारण *' : 'Reason *'}
              </label>
              <input
                required
                type="text"
                value={bulkReason}
                onChange={(e) => setBulkReason(e.target.value)}
                placeholder={lang === 'hi' ? 'जैसे: नया GST / कंपनी मूल्य वृद्धि' : 'e.g., Seasonal price revision'}
                className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm"
              />
            </div>

            <button
              type="submit"
              disabled={saving}
              className="w-full h-11 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-semibold text-sm cursor-pointer"
            >
              {saving ? '...' : labels.confirm}
            </button>
          </form>
        </div>
      )}
    </div>
  );
};
