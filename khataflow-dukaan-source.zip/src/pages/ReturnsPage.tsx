import React, { useMemo, useState } from 'react';
import { ArrowLeftRight, Plus, Trash2 } from 'lucide-react';
import { useDukaan } from '../context/DukaanContext';
import { formatINR, getTodayISO } from '../lib/formatters';
import { t } from '../lib/i18n';
import { processReturn } from '../services/dukaanService';
import { ReturnLineItem } from '../types/dukaan';

export const ReturnsPage: React.FC = () => {
  const { user, lang, products, customers, suppliers, returns, notify } = useDukaan();
  const labels = t(lang);

  const [returnType, setReturnType] = useState<'customer_return' | 'supplier_return'>('customer_return');
  const [partyId, setPartyId] = useState('');
  const [partyName, setPartyName] = useState('');
  const [referenceNumber, setReferenceNumber] = useState('');
  const [selectedProdId, setSelectedProdId] = useState('');
  const [items, setItems] = useState<ReturnLineItem[]>([]);
  const [refundMode, setRefundMode] = useState<'cash' | 'upi' | 'credit_adjust' | 'none'>('cash');
  const [stockCondition, setStockCondition] = useState<'restock' | 'damaged'>('restock');
  const [returnDate, setReturnDate] = useState(getTodayISO());
  const [notes, setNotes] = useState('');
  const [saving, setSaving] = useState(false);

  const totalAmount = useMemo(
    () => Math.round(items.reduce((s, i) => s + i.lineTotal, 0) * 100) / 100,
    [items]
  );

  const addItem = () => {
    const p = products.find((x) => x.id === selectedProdId);
    if (!p) return;
    const rate = returnType === 'customer_return' ? p.sellingPrice : p.purchasePrice;
    setItems((prev) => [
      ...prev,
      {
        productId: p.id,
        productName: p.name,
        unit: p.unit,
        qty: 1,
        unitPrice: rate,
        lineTotal: rate,
      },
    ]);
    setSelectedProdId('');
  };

  const handlePartyChange = (id: string) => {
    setPartyId(id);
    if (returnType === 'customer_return') {
      const c = customers.find((x) => x.id === id);
      setPartyName(c?.name || labels.walkInCustomer);
    } else {
      const s = suppliers.find((x) => x.id === id);
      setPartyName(s?.name || '');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || saving || items.length === 0) return;
    setSaving(true);
    try {
      await processReturn(user.uid, {
        returnType,
        partyId,
        partyName: partyName.trim() || labels.walkInCustomer,
        referenceNumber,
        items,
        totalAmount,
        refundMode,
        stockCondition,
        returnDate,
        notes,
      });
      notify(lang === 'hi' ? 'वापसी और स्टॉक समायोजन दर्ज हुआ!' : 'Return processed & stock adjusted!');
      setItems([]);
      setReferenceNumber('');
      setNotes('');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Return failed', 'error');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-8">
      <form
        onSubmit={handleSubmit}
        className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-4"
      >
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 dark:border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <ArrowLeftRight className="w-5 h-5 text-emerald-700" />
            <h2 className="text-base font-bold">
              {lang === 'hi' ? 'सामान वापसी एवं रिफंड दर्ज करें' : 'Record Return & Refund'}
            </h2>
          </div>
          <div className="flex gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl">
            <button
              type="button"
              onClick={() => {
                setReturnType('customer_return');
                setPartyId('');
                setPartyName(labels.walkInCustomer);
              }}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer ${
                returnType === 'customer_return' ? 'bg-white dark:bg-slate-900 shadow-sm' : ''
              }`}
            >
              {lang === 'hi' ? 'ग्राहक वापसी (Sales Return)' : 'Customer Return'}
            </button>
            <button
              type="button"
              onClick={() => {
                setReturnType('supplier_return');
                setPartyId('');
                setPartyName('');
              }}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer ${
                returnType === 'supplier_return' ? 'bg-white dark:bg-slate-900 shadow-sm' : ''
              }`}
            >
              {lang === 'hi' ? 'सप्लायर वापसी (Purchase Return)' : 'Supplier Return'}
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <select
            value={partyId}
            onChange={(e) => handlePartyChange(e.target.value)}
            className="h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm"
          >
            <option value="">
              {returnType === 'customer_return' ? labels.walkInCustomer : lang === 'hi' ? '-- सप्लायर चुनें --' : '-- Select Supplier --'}
            </option>
            {(returnType === 'customer_return' ? customers : suppliers).map((p) => (
              <option key={p.id} value={p.id}>
                {p.name}
              </option>
            ))}
          </select>
          <input
            type="text"
            value={referenceNumber}
            onChange={(e) => setReferenceNumber(e.target.value)}
            placeholder={lang === 'hi' ? 'बिल / खरीद नं (वैकल्पिक)' : 'Bill / Purchase # (Optional)'}
            className="h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono text-sm"
          />
          <input
            type="date"
            value={returnDate}
            onChange={(e) => setReturnDate(e.target.value)}
            className="h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono text-sm"
          />
        </div>

        <div className="flex gap-2">
          <select
            value={selectedProdId}
            onChange={(e) => setSelectedProdId(e.target.value)}
            className="flex-1 h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm"
          >
            <option value="">{lang === 'hi' ? '-- वापस आने वाला उत्पाद चुनें --' : '-- Select Product --'}</option>
            {products.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name} ({p.stockQty} {p.unit})
              </option>
            ))}
          </select>
          <button
            type="button"
            onClick={addItem}
            className="px-4 h-11 rounded-xl bg-slate-900 dark:bg-slate-800 text-white text-xs font-semibold cursor-pointer inline-flex items-center gap-1"
          >
            <Plus className="w-4 h-4" />
            {labels.add}
          </button>
        </div>

        {items.length > 0 && (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-left text-xs text-slate-500">
                  <th className="py-2">{lang === 'hi' ? 'उत्पाद' : 'Product'}</th>
                  <th className="py-2 text-right">{lang === 'hi' ? 'मात्रा' : 'Qty'}</th>
                  <th className="py-2 text-right">{lang === 'hi' ? 'दर' : 'Rate'}</th>
                  <th className="py-2 text-right">{lang === 'hi' ? 'कुल' : 'Total'}</th>
                  <th className="py-2 w-8" />
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {items.map((row, idx) => (
                  <tr key={idx}>
                    <td className="py-2 font-medium">{row.productName}</td>
                    <td className="py-2 text-right">
                      <input
                        type="number"
                        min="0.01"
                        step="any"
                        value={row.qty}
                        onChange={(e) => {
                          const q = Math.max(0.01, Number(e.target.value) || 0);
                          setItems((prev) =>
                            prev.map((x, i) =>
                              i === idx ? { ...x, qty: q, lineTotal: Math.round(q * x.unitPrice * 100) / 100 } : x
                            )
                          );
                        }}
                        className="w-20 h-9 px-2 text-right rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono text-xs"
                      />
                    </td>
                    <td className="py-2 text-right">
                      <input
                        type="number"
                        min="0"
                        step="any"
                        value={row.unitPrice}
                        onChange={(e) => {
                          const r = Math.max(0, Number(e.target.value) || 0);
                          setItems((prev) =>
                            prev.map((x, i) =>
                              i === idx ? { ...x, unitPrice: r, lineTotal: Math.round(x.qty * r * 100) / 100 } : x
                            )
                          );
                        }}
                        className="w-24 h-9 px-2 text-right rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono text-xs"
                      />
                    </td>
                    <td className="py-2 text-right font-mono font-bold">{formatINR(row.lineTotal)}</td>
                    <td className="py-2 text-right">
                      <button
                        type="button"
                        onClick={() => setItems((prev) => prev.filter((_, i) => i !== idx))}
                        className="text-red-500 p-1 cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 border-t border-slate-200 dark:border-slate-800 items-end">
          <div>
            <label className="block text-xs text-slate-500 mb-1">
              {lang === 'hi' ? 'रिफंड / समायोजन माध्यम' : 'Refund Mode'}
            </label>
            <select
              value={refundMode}
              onChange={(e) => setRefundMode(e.target.value as 'cash' | 'upi' | 'credit_adjust' | 'none')}
              className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm"
            >
              <option value="cash">{labels.cash}</option>
              <option value="upi">UPI</option>
              <option value="credit_adjust">{lang === 'hi' ? 'खाता / उधार समायोजन' : 'Adjust in Ledger'}</option>
              <option value="none">{lang === 'hi' ? 'केवल स्टॉक बदलें' : 'Stock Only (No Refund)'}</option>
            </select>
          </div>

          {returnType === 'customer_return' && (
            <div>
              <label className="block text-xs text-slate-500 mb-1">
                {lang === 'hi' ? 'सामान की स्थिति' : 'Item Condition'}
              </label>
              <select
                value={stockCondition}
                onChange={(e) => setStockCondition(e.target.value as 'restock' | 'damaged')}
                className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm"
              >
                <option value="restock">{lang === 'hi' ? 'सही है (वापस स्टॉक में जोड़ें)' : 'Good (Restock)'}</option>
                <option value="damaged">{lang === 'hi' ? 'खराब (Damaged में दर्ज करें)' : 'Damaged'}</option>
              </select>
            </div>
          )}

          <button
            type="submit"
            disabled={saving || items.length === 0}
            className="h-11 rounded-xl bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white font-semibold text-sm cursor-pointer"
          >
            {saving ? '...' : `${lang === 'hi' ? 'वापसी दर्ज करें' : 'Process Return'} (${formatINR(totalAmount)})`}
          </button>
        </div>
      </form>

      {/* Return History */}
      <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-3">
        <h3 className="text-base font-bold">{lang === 'hi' ? 'वापसी इतिहास' : 'Return History'}</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 text-left text-xs text-slate-500">
                <th className="py-2 pr-3">{lang === 'hi' ? 'तिथि' : 'Date'}</th>
                <th className="py-2 pr-3">{lang === 'hi' ? 'प्रकार' : 'Type'}</th>
                <th className="py-2 pr-3">{lang === 'hi' ? 'पार्टी' : 'Party'}</th>
                <th className="py-2 pr-3">{lang === 'hi' ? 'रिफंड' : 'Refund'}</th>
                <th className="py-2 text-right">{lang === 'hi' ? 'राशि' : 'Amount'}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {returns.length === 0 ? (
                <tr>
                  <td colSpan={5} className="py-6 text-center text-slate-500">
                    {labels.noData}
                  </td>
                </tr>
              ) : (
                returns.map((r) => (
                  <tr key={r.id}>
                    <td className="py-2.5 pr-3 font-mono text-xs text-slate-500">{r.returnDate}</td>
                    <td className="py-2.5 pr-3 text-xs font-semibold">
                      {r.returnType === 'customer_return'
                        ? lang === 'hi'
                          ? 'ग्राहक वापसी'
                          : 'Customer Return'
                        : lang === 'hi'
                          ? 'सप्लायर वापसी'
                          : 'Supplier Return'}
                    </td>
                    <td className="py-2.5 pr-3">{r.partyName}</td>
                    <td className="py-2.5 pr-3 text-xs">{r.refundMode}</td>
                    <td className="py-2.5 text-right font-mono font-bold">{formatINR(r.totalAmount)}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
};
