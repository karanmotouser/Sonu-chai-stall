import {
  calculateProfitMargin,
  generateDocId,
  getTodayISO,
  sanitizeId,
} from '../lib/formatters';
import {
  LOCAL_STORES,
  LOCAL_UID,
  localDelete,
  localGetAll,
  localGetById,
  localPut,
  nowLocalTimestamp,
} from '../lib/localDb';
import {
  Bill,
  BillLineItem,
  Customer,
  Expense,
  ExpenseCategory,
  ExpensePaymentMode,
  PriceType,
  Product,
  Purchase,
  ReturnLineItem,
  ShopProfile,
  StockMovementType,
  Supplier,
} from '../types/dukaan';
import type { CreateBillInput, CreatePurchaseInput, ProductInput } from './dukaanService';

function cleanStr(val: string | undefined | null, maxLen: number): string {
  return (val || '').trim().slice(0, maxLen);
}

function round2(n: number): number {
  return Math.round((Number(n) || 0) * 100) / 100;
}

export async function localEnsureShopProfile(
  uid: string = LOCAL_UID,
  displayName = 'दुकान मालिक'
): Promise<ShopProfile> {
  const existing = await localGetById<ShopProfile>('shops', uid);
  if (existing) return existing;
  const ts = nowLocalTimestamp();
  const profile: ShopProfile = {
    id: uid,
    ownerId: uid,
    shopName: cleanStr(displayName ? `${displayName} की दुकान` : 'KhataFlow Dukaan', 120),
    ownerName: cleanStr(displayName || 'दुकान मालिक', 100),
    phone: '',
    address: '',
    gstin: '',
    defaultGstRate: 0,
    openingCashBalance: 0,
    openingCashDate: getTodayISO(),
    pinHash: '',
    language: 'hi',
    lastBackupAt: '',
    createdAt: ts,
    updatedAt: ts,
  };
  await localPut('shops', profile);
  return profile;
}

export async function localUpdateShopProfile(
  uid: string,
  patch: Partial<ShopProfile>
): Promise<void> {
  const existing = await localEnsureShopProfile(uid);
  const next: ShopProfile = {
    ...existing,
    ...patch,
    id: uid,
    ownerId: uid,
    updatedAt: nowLocalTimestamp(),
  };
  await localPut('shops', next);
}

export async function localSaveProduct(uid: string, input: ProductInput): Promise<string> {
  const isNew = !input.id;
  const productId = input.id ? sanitizeId(input.id) : generateDocId('prod');
  const existing = isNew ? null : await localGetById<Product>('products', productId);
  const ts = nowLocalTimestamp();
  const today = getTodayISO();

  const next: Product = {
    id: productId,
    ownerId: uid,
    name: cleanStr(input.name, 160),
    category: cleanStr(input.category || 'General', 80),
    barcode: cleanStr(input.barcode, 64),
    sku: cleanStr(input.sku, 64),
    purchasePrice: Math.max(0, round2(input.purchasePrice)),
    sellingPrice: Math.max(0, round2(input.sellingPrice)),
    wholesalePrice: Math.max(0, round2(input.wholesalePrice ?? input.sellingPrice)),
    mrp: Math.max(0, round2(input.mrp)),
    stockQty: round2(input.stockQty),
    minStockAlert: Math.max(0, round2(input.minStockAlert)),
    damagedQty: Math.max(0, round2(input.damagedQty ?? existing?.damagedQty ?? 0)),
    unit: cleanStr(input.unit || 'Piece', 30),
    description: cleanStr(input.description, 500),
    photoUrl: cleanStr(input.photoUrl, 145000),
    expiryDate: cleanStr(input.expiryDate, 20),
    gstRate: Math.max(0, Math.min(50, round2(input.gstRate))),
    isActive: true,
    createdAt: existing?.createdAt || ts,
    updatedAt: ts,
  };

  await localPut('products', next);

  if (isNew && next.stockQty !== 0) {
    await localPut('stock_movements', {
      id: generateDocId('mov'),
      ownerId: uid,
      productId,
      productName: next.name,
      type: 'adjustment',
      qtyChange: next.stockQty,
      stockBefore: 0,
      stockAfter: next.stockQty,
      unitCost: next.purchasePrice,
      referenceId: productId,
      reason: 'Initial opening stock',
      movementDate: today,
      createdAt: ts,
    });
  } else if (existing && round2(existing.stockQty) !== next.stockQty) {
    await localPut('stock_movements', {
      id: generateDocId('mov'),
      ownerId: uid,
      productId,
      productName: next.name,
      type: 'adjustment',
      qtyChange: round2(next.stockQty - existing.stockQty),
      stockBefore: round2(existing.stockQty),
      stockAfter: next.stockQty,
      unitCost: next.purchasePrice,
      referenceId: productId,
      reason: 'Edited product stock directly',
      movementDate: today,
      createdAt: ts,
    });
  }

  if (isNew) {
    await localPut('audit_logs', {
      id: generateDocId('log'),
      ownerId: uid,
      action: 'PRODUCT_CREATED',
      entityType: 'product',
      entityId: productId,
      summary: cleanStr(`Added product: ${next.name} (Stock: ${next.stockQty})`, 300),
      createdAt: ts,
    });
  }
  return productId;
}

export async function localDeleteProduct(uid: string, productId: string, productName: string): Promise<void> {
  await localDelete('products', productId);
  await localPut('audit_logs', {
    id: generateDocId('log'),
    ownerId: uid,
    action: 'PRODUCT_DELETED',
    entityType: 'product',
    entityId: productId,
    summary: cleanStr(`Deleted product: ${productName}`, 300),
    createdAt: nowLocalTimestamp(),
  });
}

export async function localUpdateProductPrice(
  uid: string,
  productId: string,
  updates: { sellingPrice?: number; purchasePrice?: number; mrp?: number; wholesalePrice?: number },
  reason: string
): Promise<void> {
  const prod = await localGetById<Product>('products', productId);
  if (!prod) throw new Error('Product not found');

  const nextPurchase = updates.purchasePrice !== undefined ? Math.max(0, round2(updates.purchasePrice)) : prod.purchasePrice;
  const nextSelling = updates.sellingPrice !== undefined ? Math.max(0, round2(updates.sellingPrice)) : prod.sellingPrice;
  const nextMrp = updates.mrp !== undefined ? Math.max(0, round2(updates.mrp)) : prod.mrp;
  const nextWholesale =
    updates.wholesalePrice !== undefined
      ? Math.max(0, round2(updates.wholesalePrice))
      : (prod.wholesalePrice ?? prod.sellingPrice);

  const margin = calculateProfitMargin(nextPurchase, nextSelling);
  const batchId = generateDocId('pbatch');
  const cleanReason = cleanStr(reason || 'Manual price update', 250);
  const ts = nowLocalTimestamp();

  const changes: { type: PriceType; prev: number; next: number }[] = [];
  if (updates.purchasePrice !== undefined && nextPurchase !== prod.purchasePrice) {
    changes.push({ type: 'purchase', prev: prod.purchasePrice, next: nextPurchase });
  }
  if (updates.sellingPrice !== undefined && nextSelling !== prod.sellingPrice) {
    changes.push({ type: 'selling', prev: prod.sellingPrice, next: nextSelling });
  }
  if (updates.mrp !== undefined && nextMrp !== prod.mrp) {
    changes.push({ type: 'mrp', prev: prod.mrp, next: nextMrp });
  }
  if (updates.wholesalePrice !== undefined && nextWholesale !== (prod.wholesalePrice ?? prod.sellingPrice)) {
    changes.push({ type: 'wholesale', prev: prod.wholesalePrice ?? prod.sellingPrice, next: nextWholesale });
  }
  if (changes.length === 0) return;

  await localPut('products', {
    ...prod,
    purchasePrice: nextPurchase,
    sellingPrice: nextSelling,
    mrp: nextMrp,
    wholesalePrice: nextWholesale,
    updatedAt: ts,
  });

  for (const ch of changes) {
    await localPut('price_history', {
      id: generateDocId('ph'),
      ownerId: uid,
      productId,
      productName: prod.name,
      priceType: ch.type,
      previousPrice: ch.prev,
      newPrice: ch.next,
      changeReason: cleanReason,
      purchasePriceAtChange: nextPurchase,
      sellingPriceAtChange: nextSelling,
      profitMarginPercent: margin,
      batchId,
      createdAt: ts,
    });
  }

  await localPut('audit_logs', {
    id: generateDocId('log'),
    ownerId: uid,
    action: 'PRICE_UPDATED',
    entityType: 'product',
    entityId: productId,
    summary: cleanStr(`Updated prices for ${prod.name}: ${cleanReason}`, 300),
    createdAt: ts,
  });
}

export async function localBulkUpdatePrices(
  uid: string,
  productIds: string[],
  priceType: PriceType,
  mode: 'percent' | 'fixed',
  deltaValue: number,
  reason: string
): Promise<number> {
  if (productIds.length === 0) return 0;
  const batchId = generateDocId('bulk');
  const cleanReason = cleanStr(reason || 'Bulk price update', 250);
  const ts = nowLocalTimestamp();
  let updatedCount = 0;

  for (const pid of productIds) {
    const prod = await localGetById<Product>('products', pid);
    if (!prod) continue;
    const prevVal =
      priceType === 'purchase'
        ? prod.purchasePrice
        : priceType === 'mrp'
          ? prod.mrp
          : priceType === 'wholesale'
            ? prod.wholesalePrice ?? prod.sellingPrice
            : prod.sellingPrice;

    const rawNew = mode === 'percent' ? prevVal * (1 + deltaValue / 100) : prevVal + deltaValue;
    const nextVal = Math.max(0, round2(rawNew));
    if (nextVal === prevVal) continue;

    const nextPurchase = priceType === 'purchase' ? nextVal : prod.purchasePrice;
    const nextSelling = priceType === 'selling' ? nextVal : prod.sellingPrice;
    const nextMrp = priceType === 'mrp' ? nextVal : prod.mrp;
    const nextWholesale = priceType === 'wholesale' ? nextVal : prod.wholesalePrice ?? prod.sellingPrice;
    const margin = calculateProfitMargin(nextPurchase, nextSelling);

    await localPut('products', {
      ...prod,
      purchasePrice: nextPurchase,
      sellingPrice: nextSelling,
      mrp: nextMrp,
      wholesalePrice: nextWholesale,
      updatedAt: ts,
    });

    await localPut('price_history', {
      id: generateDocId('ph'),
      ownerId: uid,
      productId: pid,
      productName: prod.name,
      priceType,
      previousPrice: prevVal,
      newPrice: nextVal,
      changeReason: cleanReason,
      purchasePriceAtChange: nextPurchase,
      sellingPriceAtChange: nextSelling,
      profitMarginPercent: margin,
      batchId,
      createdAt: ts,
    });
    updatedCount += 1;
  }

  if (updatedCount > 0) {
    await localPut('audit_logs', {
      id: generateDocId('log'),
      ownerId: uid,
      action: 'BULK_PRICE_UPDATE',
      entityType: 'product',
      entityId: batchId,
      summary: cleanStr(`Bulk ${priceType} update on ${updatedCount} products: ${cleanReason}`, 300),
      createdAt: ts,
    });
  }
  return updatedCount;
}

export async function localCreateBill(uid: string, input: CreateBillInput): Promise<string> {
  const billId = generateDocId('bill');
  const ts = nowLocalTimestamp();

  let totalCost = 0;
  const finalizedItems: BillLineItem[] = [];
  const prodCache = new Map<string, Product>();

  for (const item of input.items) {
    const prod = await localGetById<Product>('products', item.productId);
    if (prod) prodCache.set(item.productId, prod);
    const unitCost = prod ? prod.purchasePrice : item.purchasePriceAtSale;
    totalCost += round2(unitCost * item.qty);
    finalizedItems.push({ ...item, purchasePriceAtSale: unitCost });
  }

  totalCost = round2(totalCost);
  const netRevenue = round2(input.totalAmount - input.gstAmount);
  const grossProfit = round2(netRevenue - totalCost);
  const paidAmount = round2(input.cashPaid + input.onlinePaid + input.cardPaid);

  const bill: Bill = {
    id: billId,
    ownerId: uid,
    billNumber: cleanStr(input.billNumber, 40),
    customerId: cleanStr(input.customerId, 128),
    customerName: cleanStr(input.customerName, 120),
    customerPhone: cleanStr(input.customerPhone, 20),
    items: finalizedItems,
    subtotal: round2(input.subtotal),
    discountAmount: round2(input.discountAmount),
    gstAmount: round2(input.gstAmount),
    totalAmount: round2(input.totalAmount),
    totalCost,
    grossProfit,
    paymentMode: input.paymentMode,
    cashPaid: round2(input.cashPaid),
    onlinePaid: round2(input.onlinePaid),
    cardPaid: round2(input.cardPaid),
    creditAmount: round2(input.creditAmount),
    paidAmount,
    status: 'completed',
    notes: cleanStr(input.notes, 300),
    billDate: cleanStr(input.billDate, 20),
    createdAt: ts,
    updatedAt: ts,
  };
  await localPut('bills', bill);

  for (const item of finalizedItems) {
    const prod = prodCache.get(item.productId);
    if (!prod) continue;
    const stockBefore = round2(prod.stockQty);
    const stockAfter = round2(stockBefore - item.qty);
    prod.stockQty = stockAfter;
    await localPut('products', { ...prod, stockQty: stockAfter, updatedAt: ts });
    await localPut('stock_movements', {
      id: generateDocId('mov'),
      ownerId: uid,
      productId: item.productId,
      productName: item.productName,
      type: 'sale',
      qtyChange: -round2(item.qty),
      stockBefore,
      stockAfter,
      unitCost: item.purchasePriceAtSale,
      referenceId: billId,
      reason: cleanStr(`Bill ${input.billNumber}`, 250),
      movementDate: input.billDate,
      createdAt: ts,
    });
  }

  if (input.creditAmount > 0 && input.customerId) {
    const cust = await localGetById<Customer>('customers', input.customerId);
    if (cust) {
      const nextTotal = round2(cust.totalUdhaar + input.creditAmount);
      await localPut('customers', {
        ...cust,
        totalUdhaar: nextTotal,
        remainingBalance: round2(nextTotal - cust.amountReceived),
        updatedAt: ts,
      });
      await localPut('udhaar_transactions', {
        id: generateDocId('utx'),
        ownerId: uid,
        customerId: cust.id,
        customerName: cust.name,
        type: 'bill_credit',
        amount: round2(input.creditAmount),
        paymentMode: 'credit',
        billId,
        notes: cleanStr(`Credit on Bill ${input.billNumber}`, 300),
        txDate: input.billDate,
        createdAt: ts,
      });
    }
  }

  if (input.cashPaid > 0) {
    await localPut('cashbook_entries', {
      id: generateDocId('cb'),
      ownerId: uid,
      entryDate: input.billDate,
      direction: 'in',
      category: 'sale',
      paymentMode: 'cash',
      amount: round2(input.cashPaid),
      referenceId: billId,
      description: cleanStr(`Bill ${input.billNumber} (${input.customerName})`, 250),
      createdAt: ts,
    });
  }
  if (input.onlinePaid > 0) {
    await localPut('cashbook_entries', {
      id: generateDocId('cb'),
      ownerId: uid,
      entryDate: input.billDate,
      direction: 'in',
      category: 'sale',
      paymentMode: 'upi',
      amount: round2(input.onlinePaid),
      referenceId: billId,
      description: cleanStr(`UPI Bill ${input.billNumber} (${input.customerName})`, 250),
      createdAt: ts,
    });
  }
  if (input.cardPaid > 0) {
    await localPut('cashbook_entries', {
      id: generateDocId('cb'),
      ownerId: uid,
      entryDate: input.billDate,
      direction: 'in',
      category: 'sale',
      paymentMode: 'card',
      amount: round2(input.cardPaid),
      referenceId: billId,
      description: cleanStr(`Card Bill ${input.billNumber} (${input.customerName})`, 250),
      createdAt: ts,
    });
  }

  await localPut('audit_logs', {
    id: generateDocId('log'),
    ownerId: uid,
    action: 'BILL_CREATED',
    entityType: 'bill',
    entityId: billId,
    summary: cleanStr(`Created Bill ${input.billNumber} for ₹${round2(input.totalAmount)}`, 300),
    createdAt: ts,
  });

  return billId;
}

export async function localEditBill(
  uid: string,
  billId: string,
  updated: Omit<CreateBillInput, 'billNumber'>
): Promise<void> {
  const oldBill = await localGetById<Bill>('bills', billId);
  if (!oldBill) throw new Error('Bill not found');
  if (oldBill.status === 'cancelled') throw new Error('Cancelled bill cannot be edited');

  const ts = nowLocalTimestamp();
  const prodIds = Array.from(
    new Set([...oldBill.items.map((i) => i.productId), ...updated.items.map((i) => i.productId)])
  );
  const prodMap = new Map<string, Product>();
  for (const pid of prodIds) {
    const p = await localGetById<Product>('products', pid);
    if (p) prodMap.set(pid, p);
  }

  const stockDeltaMap = new Map<string, number>();
  oldBill.items.forEach((i) => stockDeltaMap.set(i.productId, (stockDeltaMap.get(i.productId) || 0) + i.qty));
  updated.items.forEach((i) => stockDeltaMap.set(i.productId, (stockDeltaMap.get(i.productId) || 0) - i.qty));

  let totalCost = 0;
  const finalizedItems: BillLineItem[] = updated.items.map((item) => {
    const p = prodMap.get(item.productId);
    const unitCost = p ? p.purchasePrice : item.purchasePriceAtSale;
    totalCost += round2(unitCost * item.qty);
    return { ...item, purchasePriceAtSale: unitCost };
  });
  totalCost = round2(totalCost);
  const grossProfit = round2(round2(updated.totalAmount - updated.gstAmount) - totalCost);
  const paidAmount = round2(updated.cashPaid + updated.onlinePaid + updated.cardPaid);

  await localPut('bills', {
    ...oldBill,
    customerId: cleanStr(updated.customerId, 128),
    customerName: cleanStr(updated.customerName, 120),
    customerPhone: cleanStr(updated.customerPhone, 20),
    items: finalizedItems,
    subtotal: round2(updated.subtotal),
    discountAmount: round2(updated.discountAmount),
    gstAmount: round2(updated.gstAmount),
    totalAmount: round2(updated.totalAmount),
    totalCost,
    grossProfit,
    paymentMode: updated.paymentMode,
    cashPaid: round2(updated.cashPaid),
    onlinePaid: round2(updated.onlinePaid),
    cardPaid: round2(updated.cardPaid),
    creditAmount: round2(updated.creditAmount),
    paidAmount,
    status: 'edited',
    notes: cleanStr(updated.notes, 300),
    billDate: cleanStr(updated.billDate, 20),
    updatedAt: ts,
  });

  for (const [pid, delta] of stockDeltaMap.entries()) {
    if (round2(delta) === 0) continue;
    const p = prodMap.get(pid);
    if (!p) continue;
    const stockBefore = round2(p.stockQty);
    const stockAfter = round2(stockBefore + delta);
    await localPut('products', { ...p, stockQty: stockAfter, updatedAt: ts });
    await localPut('stock_movements', {
      id: generateDocId('mov'),
      ownerId: uid,
      productId: pid,
      productName: p.name,
      type: 'adjustment',
      qtyChange: round2(delta),
      stockBefore,
      stockAfter,
      unitCost: p.purchasePrice,
      referenceId: billId,
      reason: cleanStr(`Edited Bill ${oldBill.billNumber}`, 250),
      movementDate: updated.billDate,
      createdAt: ts,
    });
  }

  if (oldBill.customerId && updated.customerId === oldBill.customerId) {
    const creditDiff = round2(updated.creditAmount - oldBill.creditAmount);
    if (creditDiff !== 0) {
      const cust = await localGetById<Customer>('customers', oldBill.customerId);
      if (cust) {
        const nextTotal = Math.max(0, round2(cust.totalUdhaar + creditDiff));
        await localPut('customers', {
          ...cust,
          totalUdhaar: nextTotal,
          remainingBalance: round2(nextTotal - cust.amountReceived),
          updatedAt: ts,
        });
      }
    }
  } else {
    if (oldBill.customerId && oldBill.creditAmount > 0) {
      const oldCust = await localGetById<Customer>('customers', oldBill.customerId);
      if (oldCust) {
        const nextTotal = Math.max(0, round2(oldCust.totalUdhaar - oldBill.creditAmount));
        await localPut('customers', {
          ...oldCust,
          totalUdhaar: nextTotal,
          remainingBalance: round2(nextTotal - oldCust.amountReceived),
          updatedAt: ts,
        });
      }
    }
    if (updated.customerId && updated.creditAmount > 0) {
      const newCust = await localGetById<Customer>('customers', updated.customerId);
      if (newCust) {
        const nextTotal = round2(newCust.totalUdhaar + updated.creditAmount);
        await localPut('customers', {
          ...newCust,
          totalUdhaar: nextTotal,
          remainingBalance: round2(nextTotal - newCust.amountReceived),
          updatedAt: ts,
        });
      }
    }
  }

  const diffs: { mode: 'cash' | 'upi' | 'card'; diff: number; label: string }[] = [
    { mode: 'cash', diff: round2(updated.cashPaid - oldBill.cashPaid), label: 'Cash' },
    { mode: 'upi', diff: round2(updated.onlinePaid - oldBill.onlinePaid), label: 'UPI' },
    { mode: 'card', diff: round2(updated.cardPaid - oldBill.cardPaid), label: 'Card' },
  ];
  for (const d of diffs) {
    if (d.diff !== 0) {
      await localPut('cashbook_entries', {
        id: generateDocId('cb'),
        ownerId: uid,
        entryDate: updated.billDate,
        direction: d.diff > 0 ? 'in' : 'out',
        category: 'sale',
        paymentMode: d.mode,
        amount: Math.abs(d.diff),
        referenceId: billId,
        description: cleanStr(`Edited Bill ${oldBill.billNumber} ${d.label} adjustment`, 250),
        createdAt: ts,
      });
    }
  }
}

export async function localCancelBill(uid: string, billId: string, reason: string): Promise<void> {
  const bill = await localGetById<Bill>('bills', billId);
  if (!bill || bill.status === 'cancelled') return;

  const ts = nowLocalTimestamp();
  const today = getTodayISO();

  await localPut('bills', {
    ...bill,
    status: 'cancelled',
    notes: cleanStr(reason || 'Cancelled by owner', 300),
    updatedAt: ts,
  });

  for (const item of bill.items) {
    const prod = await localGetById<Product>('products', item.productId);
    if (!prod) continue;
    const stockBefore = round2(prod.stockQty);
    const stockAfter = round2(stockBefore + item.qty);
    await localPut('products', { ...prod, stockQty: stockAfter, updatedAt: ts });
    await localPut('stock_movements', {
      id: generateDocId('mov'),
      ownerId: uid,
      productId: item.productId,
      productName: item.productName,
      type: 'sale_cancel',
      qtyChange: round2(item.qty),
      stockBefore,
      stockAfter,
      unitCost: item.purchasePriceAtSale,
      referenceId: billId,
      reason: cleanStr(`Bill ${bill.billNumber} cancelled: ${reason}`, 250),
      movementDate: today,
      createdAt: ts,
    });
  }

  if (bill.creditAmount > 0 && bill.customerId) {
    const cust = await localGetById<Customer>('customers', bill.customerId);
    if (cust) {
      const nextTotal = Math.max(0, round2(cust.totalUdhaar - bill.creditAmount));
      await localPut('customers', {
        ...cust,
        totalUdhaar: nextTotal,
        remainingBalance: round2(nextTotal - cust.amountReceived),
        updatedAt: ts,
      });
    }
  }

  if (bill.cashPaid > 0) {
    await localPut('cashbook_entries', {
      id: generateDocId('cb'),
      ownerId: uid,
      entryDate: today,
      direction: 'out',
      category: 'refund',
      paymentMode: 'cash',
      amount: round2(bill.cashPaid),
      referenceId: billId,
      description: cleanStr(`Cancelled Bill ${bill.billNumber} Cash refund`, 250),
      createdAt: ts,
    });
  }
  if (bill.onlinePaid > 0) {
    await localPut('cashbook_entries', {
      id: generateDocId('cb'),
      ownerId: uid,
      entryDate: today,
      direction: 'out',
      category: 'refund',
      paymentMode: 'upi',
      amount: round2(bill.onlinePaid),
      referenceId: billId,
      description: cleanStr(`Cancelled Bill ${bill.billNumber} UPI refund`, 250),
      createdAt: ts,
    });
  }
  if (bill.cardPaid > 0) {
    await localPut('cashbook_entries', {
      id: generateDocId('cb'),
      ownerId: uid,
      entryDate: today,
      direction: 'out',
      category: 'refund',
      paymentMode: 'card',
      amount: round2(bill.cardPaid),
      referenceId: billId,
      description: cleanStr(`Cancelled Bill ${bill.billNumber} Card refund`, 250),
      createdAt: ts,
    });
  }
}

export async function localCreatePurchase(uid: string, input: CreatePurchaseInput): Promise<string> {
  const purchaseId = generateDocId('pur');
  const ts = nowLocalTimestamp();
  const totalAmount = round2(input.totalAmount);
  const paidAmount = Math.min(totalAmount, Math.max(0, round2(input.paidAmount)));
  const remainingAmount = round2(totalAmount - paidAmount);

  await localPut('purchases', {
    id: purchaseId,
    ownerId: uid,
    purchaseNumber: cleanStr(input.purchaseNumber, 40),
    supplierId: input.supplierId,
    supplierName: cleanStr(input.supplierName, 120),
    items: input.items,
    totalAmount,
    paidAmount,
    remainingAmount,
    paymentMode: input.paymentMode,
    status: 'completed',
    purchaseDate: cleanStr(input.purchaseDate, 20),
    notes: cleanStr(input.notes, 300),
    createdAt: ts,
    updatedAt: ts,
  });

  for (const item of input.items) {
    const prod = await localGetById<Product>('products', item.productId);
    if (!prod) continue;
    const stockBefore = round2(prod.stockQty);
    const stockAfter = round2(stockBefore + item.qty);
    let nextPurchasePrice = prod.purchasePrice;

    if (input.updateProductPurchaseRates && item.purchaseRate !== prod.purchasePrice) {
      nextPurchasePrice = round2(item.purchaseRate);
      await localPut('price_history', {
        id: generateDocId('ph'),
        ownerId: uid,
        productId: item.productId,
        productName: prod.name,
        priceType: 'purchase',
        previousPrice: prod.purchasePrice,
        newPrice: nextPurchasePrice,
        changeReason: cleanStr(`Purchase ${input.purchaseNumber} from ${input.supplierName}`, 250),
        purchasePriceAtChange: nextPurchasePrice,
        sellingPriceAtChange: prod.sellingPrice,
        profitMarginPercent: calculateProfitMargin(nextPurchasePrice, prod.sellingPrice),
        batchId: purchaseId,
        createdAt: ts,
      });
    }

    await localPut('products', {
      ...prod,
      stockQty: stockAfter,
      purchasePrice: nextPurchasePrice,
      updatedAt: ts,
    });

    await localPut('stock_movements', {
      id: generateDocId('mov'),
      ownerId: uid,
      productId: item.productId,
      productName: item.productName,
      type: 'purchase',
      qtyChange: round2(item.qty),
      stockBefore,
      stockAfter,
      unitCost: round2(item.purchaseRate),
      referenceId: purchaseId,
      reason: cleanStr(`Purchase ${input.purchaseNumber} (${input.supplierName})`, 250),
      movementDate: input.purchaseDate,
      createdAt: ts,
    });
  }

  const supp = await localGetById<Supplier>('suppliers', input.supplierId);
  if (supp) {
    const nextTotalPurchases = round2(supp.totalPurchases + totalAmount);
    const nextTotalPaid = round2(supp.totalPaid + paidAmount);
    await localPut('suppliers', {
      ...supp,
      totalPurchases: nextTotalPurchases,
      totalPaid: nextTotalPaid,
      remainingOutstanding: round2(nextTotalPurchases - nextTotalPaid),
      updatedAt: ts,
    });
  }

  if (paidAmount > 0) {
    const cbMode = input.paymentMode === 'credit' ? 'cash' : input.paymentMode;
    await localPut('supplier_payments', {
      id: generateDocId('spay'),
      ownerId: uid,
      supplierId: input.supplierId,
      supplierName: cleanStr(input.supplierName, 120),
      purchaseId,
      type: 'payment',
      amount: paidAmount,
      paymentMode: cbMode,
      notes: cleanStr(`Paid on Purchase ${input.purchaseNumber}`, 300),
      paymentDate: input.purchaseDate,
      createdAt: ts,
    });
    await localPut('cashbook_entries', {
      id: generateDocId('cb'),
      ownerId: uid,
      entryDate: input.purchaseDate,
      direction: 'out',
      category: 'purchase',
      paymentMode: cbMode,
      amount: paidAmount,
      referenceId: purchaseId,
      description: cleanStr(`Purchase ${input.purchaseNumber} (${input.supplierName})`, 250),
      createdAt: ts,
    });
  }

  if (remainingAmount > 0) {
    await localPut('supplier_payments', {
      id: generateDocId('spay'),
      ownerId: uid,
      supplierId: input.supplierId,
      supplierName: cleanStr(input.supplierName, 120),
      purchaseId,
      type: 'purchase_credit',
      amount: remainingAmount,
      paymentMode: 'credit',
      notes: cleanStr(`Balance due on Purchase ${input.purchaseNumber}`, 300),
      paymentDate: input.purchaseDate,
      createdAt: ts,
    });
  }

  return purchaseId;
}

export async function localCancelPurchase(uid: string, purchaseId: string): Promise<void> {
  const pur = await localGetById<Purchase>('purchases', purchaseId);
  if (!pur || pur.status === 'cancelled') return;
  const ts = nowLocalTimestamp();
  const today = getTodayISO();

  await localPut('purchases', { ...pur, status: 'cancelled', notes: 'Purchase cancelled', updatedAt: ts });

  for (const item of pur.items) {
    const prod = await localGetById<Product>('products', item.productId);
    if (!prod) continue;
    const stockBefore = round2(prod.stockQty);
    const stockAfter = round2(stockBefore - item.qty);
    await localPut('products', { ...prod, stockQty: stockAfter, updatedAt: ts });
    await localPut('stock_movements', {
      id: generateDocId('mov'),
      ownerId: uid,
      productId: item.productId,
      productName: item.productName,
      type: 'purchase_cancel',
      qtyChange: -round2(item.qty),
      stockBefore,
      stockAfter,
      unitCost: item.purchaseRate,
      referenceId: purchaseId,
      reason: cleanStr(`Cancelled Purchase ${pur.purchaseNumber}`, 250),
      movementDate: today,
      createdAt: ts,
    });
  }

  const supp = await localGetById<Supplier>('suppliers', pur.supplierId);
  if (supp) {
    const nextTotal = Math.max(0, round2(supp.totalPurchases - pur.totalAmount));
    const nextPaid = Math.max(0, round2(supp.totalPaid - pur.paidAmount));
    await localPut('suppliers', {
      ...supp,
      totalPurchases: nextTotal,
      totalPaid: nextPaid,
      remainingOutstanding: round2(nextTotal - nextPaid),
      updatedAt: ts,
    });
  }

  if (pur.paidAmount > 0) {
    const cbMode = pur.paymentMode === 'credit' ? 'cash' : pur.paymentMode;
    await localPut('cashbook_entries', {
      id: generateDocId('cb'),
      ownerId: uid,
      entryDate: today,
      direction: 'in',
      category: 'refund',
      paymentMode: cbMode,
      amount: round2(pur.paidAmount),
      referenceId: purchaseId,
      description: cleanStr(`Refund from Cancelled Purchase ${pur.purchaseNumber}`, 250),
      createdAt: ts,
    });
  }
}

export async function localSaveCustomer(
  uid: string,
  input: { id?: string; name: string; phone: string; address?: string; notes?: string; initialUdhaar?: number }
): Promise<string> {
  const isNew = !input.id;
  const custId = input.id ? sanitizeId(input.id) : generateDocId('cust');
  const existing = isNew ? null : await localGetById<Customer>('customers', custId);
  const ts = nowLocalTimestamp();

  if (isNew) {
    const opening = Math.max(0, round2(input.initialUdhaar || 0));
    await localPut('customers', {
      id: custId,
      ownerId: uid,
      name: cleanStr(input.name, 120),
      phone: cleanStr(input.phone, 20),
      address: cleanStr(input.address, 250),
      totalUdhaar: opening,
      amountReceived: 0,
      remainingBalance: opening,
      notes: cleanStr(input.notes, 300),
      createdAt: ts,
      updatedAt: ts,
    });
    if (opening > 0) {
      await localPut('udhaar_transactions', {
        id: generateDocId('utx'),
        ownerId: uid,
        customerId: custId,
        customerName: cleanStr(input.name, 120),
        type: 'udhaar',
        amount: opening,
        paymentMode: 'credit',
        notes: 'Opening udhaar balance',
        txDate: getTodayISO(),
        createdAt: ts,
      });
    }
  } else if (existing) {
    await localPut('customers', {
      ...existing,
      name: cleanStr(input.name, 120),
      phone: cleanStr(input.phone, 20),
      address: cleanStr(input.address, 250),
      notes: cleanStr(input.notes, 300),
      updatedAt: ts,
    });
  }
  return custId;
}

export async function localDeleteCustomer(customerId: string): Promise<void> {
  await localDelete('customers', customerId);
}

export async function localRecordUdhaarEntry(
  uid: string,
  input: {
    customerId: string;
    type: 'udhaar' | 'repayment';
    amount: number;
    paymentMode: 'cash' | 'upi' | 'bank' | 'card' | 'credit';
    txDate: string;
    notes?: string;
  }
): Promise<void> {
  const cust = await localGetById<Customer>('customers', input.customerId);
  if (!cust) throw new Error('Customer not found');
  const amount = Math.max(0, round2(input.amount));
  if (amount <= 0) return;

  const ts = nowLocalTimestamp();
  const nextTotalUdhaar = input.type === 'udhaar' ? round2(cust.totalUdhaar + amount) : cust.totalUdhaar;
  const nextReceived = input.type === 'repayment' ? round2(cust.amountReceived + amount) : cust.amountReceived;

  await localPut('customers', {
    ...cust,
    totalUdhaar: nextTotalUdhaar,
    amountReceived: nextReceived,
    remainingBalance: round2(nextTotalUdhaar - nextReceived),
    updatedAt: ts,
  });

  const utxId = generateDocId('utx');
  await localPut('udhaar_transactions', {
    id: utxId,
    ownerId: uid,
    customerId: input.customerId,
    customerName: cust.name,
    type: input.type,
    amount,
    paymentMode: input.type === 'udhaar' ? 'credit' : input.paymentMode,
    notes: cleanStr(input.notes, 300),
    txDate: cleanStr(input.txDate, 20),
    createdAt: ts,
  });

  if (input.type === 'repayment') {
    const cbMode = input.paymentMode === 'credit' ? 'cash' : input.paymentMode;
    await localPut('cashbook_entries', {
      id: generateDocId('cb'),
      ownerId: uid,
      entryDate: input.txDate,
      direction: 'in',
      category: 'udhaar_repayment',
      paymentMode: cbMode,
      amount,
      referenceId: utxId,
      description: cleanStr(`Udhaar received from ${cust.name}`, 250),
      createdAt: ts,
    });
  }
}

export async function localSaveSupplier(
  uid: string,
  input: { id?: string; name: string; phone: string; address?: string; gstin?: string; notes?: string; openingOutstanding?: number }
): Promise<string> {
  const isNew = !input.id;
  const suppId = input.id ? sanitizeId(input.id) : generateDocId('supp');
  const existing = isNew ? null : await localGetById<Supplier>('suppliers', suppId);
  const ts = nowLocalTimestamp();

  if (isNew) {
    const opening = Math.max(0, round2(input.openingOutstanding || 0));
    await localPut('suppliers', {
      id: suppId,
      ownerId: uid,
      name: cleanStr(input.name, 120),
      phone: cleanStr(input.phone, 20),
      address: cleanStr(input.address, 250),
      gstin: cleanStr(input.gstin, 20),
      totalPurchases: opening,
      totalPaid: 0,
      remainingOutstanding: opening,
      notes: cleanStr(input.notes, 300),
      createdAt: ts,
      updatedAt: ts,
    });
  } else if (existing) {
    await localPut('suppliers', {
      ...existing,
      name: cleanStr(input.name, 120),
      phone: cleanStr(input.phone, 20),
      address: cleanStr(input.address, 250),
      gstin: cleanStr(input.gstin, 20),
      notes: cleanStr(input.notes, 300),
      updatedAt: ts,
    });
  }
  return suppId;
}

export async function localDeleteSupplier(supplierId: string): Promise<void> {
  await localDelete('suppliers', supplierId);
}

export async function localRecordSupplierPayment(
  uid: string,
  input: {
    supplierId: string;
    purchaseId?: string;
    amount: number;
    paymentMode: 'cash' | 'upi' | 'bank';
    paymentDate: string;
    notes?: string;
  }
): Promise<void> {
  const supp = await localGetById<Supplier>('suppliers', input.supplierId);
  if (!supp) throw new Error('Supplier not found');
  const amount = Math.max(0, round2(input.amount));
  if (amount <= 0) return;

  const ts = nowLocalTimestamp();
  const nextPaid = round2(supp.totalPaid + amount);
  await localPut('suppliers', {
    ...supp,
    totalPaid: nextPaid,
    remainingOutstanding: round2(supp.totalPurchases - nextPaid),
    updatedAt: ts,
  });

  if (input.purchaseId) {
    const pur = await localGetById<Purchase>('purchases', input.purchaseId);
    if (pur) {
      const newPurPaid = Math.min(pur.totalAmount, round2(pur.paidAmount + amount));
      await localPut('purchases', {
        ...pur,
        paidAmount: newPurPaid,
        remainingAmount: round2(pur.totalAmount - newPurPaid),
        updatedAt: ts,
      });
    }
  }

  const spayId = generateDocId('spay');
  await localPut('supplier_payments', {
    id: spayId,
    ownerId: uid,
    supplierId: input.supplierId,
    supplierName: supp.name,
    purchaseId: cleanStr(input.purchaseId, 128),
    type: 'payment',
    amount,
    paymentMode: input.paymentMode,
    notes: cleanStr(input.notes, 300),
    paymentDate: cleanStr(input.paymentDate, 20),
    createdAt: ts,
  });

  await localPut('cashbook_entries', {
    id: generateDocId('cb'),
    ownerId: uid,
    entryDate: input.paymentDate,
    direction: 'out',
    category: 'supplier_payment',
    paymentMode: input.paymentMode,
    amount,
    referenceId: spayId,
    description: cleanStr(`Paid to supplier ${supp.name}`, 250),
    createdAt: ts,
  });
}

export async function localSaveExpense(
  uid: string,
  input: {
    id?: string;
    category: ExpenseCategory;
    title: string;
    amount: number;
    paymentMode: ExpensePaymentMode;
    expenseDate: string;
    notes?: string;
  }
): Promise<string> {
  const isNew = !input.id;
  const expId = input.id ? sanitizeId(input.id) : generateDocId('exp');
  const existing = isNew ? null : await localGetById<Expense>('expenses', expId);
  const amount = round2(input.amount);
  if (amount <= 0) throw new Error('Expense amount must be greater than 0');
  const ts = nowLocalTimestamp();

  await localPut('expenses', {
    id: expId,
    ownerId: uid,
    category: input.category,
    title: cleanStr(input.title, 140),
    amount,
    paymentMode: input.paymentMode,
    expenseDate: cleanStr(input.expenseDate, 20),
    notes: cleanStr(input.notes, 300),
    createdAt: existing?.createdAt || ts,
    updatedAt: ts,
  });

  if (isNew) {
    await localPut('cashbook_entries', {
      id: generateDocId('cb'),
      ownerId: uid,
      entryDate: input.expenseDate,
      direction: 'out',
      category: 'expense',
      paymentMode: input.paymentMode,
      amount,
      referenceId: expId,
      description: cleanStr(`Expense: ${input.title}`, 250),
      createdAt: ts,
    });
  } else if (existing) {
    const diff = round2(amount - existing.amount);
    if (diff !== 0) {
      await localPut('cashbook_entries', {
        id: generateDocId('cb'),
        ownerId: uid,
        entryDate: input.expenseDate,
        direction: diff > 0 ? 'out' : 'in',
        category: 'expense',
        paymentMode: input.paymentMode,
        amount: Math.abs(diff),
        referenceId: expId,
        description: cleanStr(`Expense adjusted: ${input.title}`, 250),
        createdAt: ts,
      });
    }
  }
  return expId;
}

export async function localDeleteExpense(expenseId: string): Promise<void> {
  await localDelete('expenses', expenseId);
}

export async function localAdjustStock(
  uid: string,
  input: {
    productId: string;
    type: Extract<StockMovementType, 'adjustment' | 'damage' | 'expiry' | 'audit'>;
    newStockQty?: number;
    qtyDelta?: number;
    reason: string;
    movementDate: string;
  }
): Promise<void> {
  const prod = await localGetById<Product>('products', input.productId);
  if (!prod) throw new Error('Product not found');
  const stockBefore = round2(prod.stockQty);
  let stockAfter = stockBefore;
  let qtyChange = 0;

  if (input.newStockQty !== undefined) {
    stockAfter = round2(input.newStockQty);
    qtyChange = round2(stockAfter - stockBefore);
  } else if (input.qtyDelta !== undefined) {
    qtyChange = round2(input.qtyDelta);
    stockAfter = round2(stockBefore + qtyChange);
  }

  let nextDamaged = prod.damagedQty || 0;
  if ((input.type === 'damage' || input.type === 'expiry') && qtyChange < 0) {
    nextDamaged = round2(nextDamaged + Math.abs(qtyChange));
  }

  const ts = nowLocalTimestamp();
  await localPut('products', { ...prod, stockQty: stockAfter, damagedQty: nextDamaged, updatedAt: ts });
  await localPut('stock_movements', {
    id: generateDocId('mov'),
    ownerId: uid,
    productId: input.productId,
    productName: prod.name,
    type: input.type,
    qtyChange,
    stockBefore,
    stockAfter,
    unitCost: prod.purchasePrice,
    referenceId: input.productId,
    reason: cleanStr(input.reason || input.type, 250),
    movementDate: cleanStr(input.movementDate, 20),
    createdAt: ts,
  });
}

export async function localProcessReturn(
  uid: string,
  input: {
    returnType: 'customer_return' | 'supplier_return';
    referenceId?: string;
    referenceNumber?: string;
    partyId?: string;
    partyName: string;
    items: ReturnLineItem[];
    totalAmount: number;
    refundMode: 'cash' | 'upi' | 'credit_adjust' | 'none';
    stockCondition: 'restock' | 'damaged';
    returnDate: string;
    notes?: string;
  }
): Promise<string> {
  const retId = generateDocId('ret');
  const ts = nowLocalTimestamp();
  const totalAmount = round2(input.totalAmount);

  await localPut('returns', {
    id: retId,
    ownerId: uid,
    returnType: input.returnType,
    referenceId: cleanStr(input.referenceId, 128),
    referenceNumber: cleanStr(input.referenceNumber, 40),
    partyId: cleanStr(input.partyId, 128),
    partyName: cleanStr(input.partyName, 120),
    items: input.items,
    totalAmount,
    refundMode: input.refundMode,
    stockCondition: input.stockCondition,
    notes: cleanStr(input.notes, 300),
    returnDate: cleanStr(input.returnDate, 20),
    createdAt: ts,
  });

  for (const item of input.items) {
    const prod = await localGetById<Product>('products', item.productId);
    if (!prod) continue;
    const stockBefore = round2(prod.stockQty);

    if (input.returnType === 'customer_return') {
      if (input.stockCondition === 'restock') {
        const stockAfter = round2(stockBefore + item.qty);
        await localPut('products', { ...prod, stockQty: stockAfter, updatedAt: ts });
        await localPut('stock_movements', {
          id: generateDocId('mov'),
          ownerId: uid,
          productId: item.productId,
          productName: item.productName,
          type: 'customer_return',
          qtyChange: round2(item.qty),
          stockBefore,
          stockAfter,
          unitCost: prod.purchasePrice,
          referenceId: retId,
          reason: cleanStr(`Customer return (${input.partyName})`, 250),
          movementDate: input.returnDate,
          createdAt: ts,
        });
      } else {
        await localPut('products', {
          ...prod,
          damagedQty: round2((prod.damagedQty || 0) + item.qty),
          updatedAt: ts,
        });
      }
    } else {
      const stockAfter = round2(stockBefore - item.qty);
      await localPut('products', { ...prod, stockQty: stockAfter, updatedAt: ts });
      await localPut('stock_movements', {
        id: generateDocId('mov'),
        ownerId: uid,
        productId: item.productId,
        productName: item.productName,
        type: 'supplier_return',
        qtyChange: -round2(item.qty),
        stockBefore,
        stockAfter,
        unitCost: item.unitPrice,
        referenceId: retId,
        reason: cleanStr(`Returned to supplier (${input.partyName})`, 250),
        movementDate: input.returnDate,
        createdAt: ts,
      });
    }
  }

  if (input.refundMode === 'cash' || input.refundMode === 'upi') {
    await localPut('cashbook_entries', {
      id: generateDocId('cb'),
      ownerId: uid,
      entryDate: input.returnDate,
      direction: input.returnType === 'customer_return' ? 'out' : 'in',
      category: 'refund',
      paymentMode: input.refundMode,
      amount: totalAmount,
      referenceId: retId,
      description: cleanStr(`Return (${input.partyName})`, 250),
      createdAt: ts,
    });
  } else if (input.refundMode === 'credit_adjust' && input.partyId) {
    if (input.returnType === 'customer_return') {
      const cust = await localGetById<Customer>('customers', input.partyId);
      if (cust) {
        const nextReceived = round2(cust.amountReceived + totalAmount);
        await localPut('customers', {
          ...cust,
          amountReceived: nextReceived,
          remainingBalance: round2(cust.totalUdhaar - nextReceived),
          updatedAt: ts,
        });
      }
    } else {
      const supp = await localGetById<Supplier>('suppliers', input.partyId);
      if (supp) {
        const nextPaid = round2(supp.totalPaid + totalAmount);
        await localPut('suppliers', {
          ...supp,
          totalPaid: nextPaid,
          remainingOutstanding: round2(supp.totalPurchases - nextPaid),
          updatedAt: ts,
        });
      }
    }
  }

  return retId;
}

export async function localAddManualCashbookEntry(
  uid: string,
  input: {
    entryDate: string;
    direction: 'in' | 'out';
    paymentMode: 'cash' | 'upi' | 'bank' | 'card';
    amount: number;
    description: string;
  }
): Promise<void> {
  await localPut('cashbook_entries', {
    id: generateDocId('cb'),
    ownerId: uid,
    entryDate: cleanStr(input.entryDate, 20),
    direction: input.direction,
    category: 'manual',
    paymentMode: input.paymentMode,
    amount: Math.max(0, round2(input.amount)),
    description: cleanStr(input.description, 250),
    createdAt: nowLocalTimestamp(),
  });
}

export async function localExportShopBackup(uid: string): Promise<Record<string, unknown>> {
  const profile = await localGetById<ShopProfile>('shops', uid);
  const colMap: Record<string, unknown[]> = {};
  for (const storeName of LOCAL_STORES) {
    if (storeName === 'shops' || storeName === 'audit_logs') continue;
    colMap[storeName] = await localGetAll(storeName);
  }
  await localUpdateShopProfile(uid, { lastBackupAt: new Date().toISOString() });
  return {
    exportedAt: new Date().toISOString(),
    version: 1,
    shopProfile: profile,
    collections: colMap,
  };
}

export async function localImportShopBackup(
  uid: string,
  backupJson: Record<string, unknown>
): Promise<number> {
  const collections = backupJson.collections as Record<string, Record<string, unknown>[]> | undefined;
  if (!collections || typeof collections !== 'object') {
    throw new Error('Invalid backup file format');
  }
  const ts = nowLocalTimestamp();
  let count = 0;
  for (const storeName of LOCAL_STORES) {
    if (storeName === 'shops' || storeName === 'audit_logs') continue;
    const docs = collections[storeName];
    if (!Array.isArray(docs)) continue;
    for (const raw of docs) {
      const docId = sanitizeId(String(raw.id || generateDocId(storeName.slice(0, 4))));
      await localPut(storeName, {
        ...raw,
        id: docId,
        ownerId: uid,
        createdAt: ts,
        updatedAt: ts,
      });
      count += 1;
    }
  }
  return count;
}
