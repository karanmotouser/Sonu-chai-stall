import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocs,
  runTransaction,
  serverTimestamp,
  setDoc,
  updateDoc,
  writeBatch,
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import {
  calculateProfitMargin,
  generateDocId,
  getTodayISO,
  sanitizeId,
} from '../lib/formatters';
import { LOCAL_UID } from '../lib/localDb';
import {
  localAddManualCashbookEntry,
  localAdjustStock,
  localBulkUpdatePrices,
  localCancelBill,
  localCancelPurchase,
  localCreateBill,
  localCreatePurchase,
  localDeleteCustomer,
  localDeleteExpense,
  localDeleteProduct,
  localDeleteSupplier,
  localEditBill,
  localEnsureShopProfile,
  localExportShopBackup,
  localImportShopBackup,
  localProcessReturn,
  localRecordSupplierPayment,
  localRecordUdhaarEntry,
  localSaveCustomer,
  localSaveExpense,
  localSaveProduct,
  localSaveSupplier,
  localUpdateProductPrice,
  localUpdateShopProfile,
} from './localDukaanService';
import {
  Bill,
  BillLineItem,
  Customer,
  Expense,
  ExpenseCategory,
  ExpensePaymentMode,
  PaymentMode,
  PriceType,
  Product,
  Purchase,
  PurchaseLineItem,
  PurchasePaymentMode,
  ReturnLineItem,
  ShopProfile,
  StockMovementType,
  Supplier,
} from '../types/dukaan';

function shopDoc(uid: string) {
  return doc(db, 'shops', uid);
}

function subCol(uid: string, name: string) {
  return collection(db, 'shops', uid, name);
}

function subDoc(uid: string, name: string, id: string) {
  return doc(db, 'shops', uid, name, id);
}

function cleanStr(val: string | undefined | null, maxLen: number): string {
  return (val || '').trim().slice(0, maxLen);
}

function round2(n: number): number {
  return Math.round((Number(n) || 0) * 100) / 100;
}

export async function ensureShopProfile(
  uid: string,
  displayName: string,
  _email: string
): Promise<ShopProfile> {
  if (uid === LOCAL_UID) return localEnsureShopProfile(uid, displayName);
  const ref = shopDoc(uid);
  try {
    const snap = await getDoc(ref);
    if (snap.exists()) {
      return { id: snap.id, ...(snap.data() as Omit<ShopProfile, 'id'>) };
    }
    const today = getTodayISO();
    const initialData = {
      ownerId: uid,
      shopName: cleanStr(displayName ? `${displayName} की दुकान` : 'मेरी दुकान', 120),
      ownerName: cleanStr(displayName || 'दुकान मालिक', 100),
      phone: '',
      address: '',
      gstin: '',
      defaultGstRate: 0,
      openingCashBalance: 0,
      openingCashDate: today,
      pinHash: '',
      language: 'hi' as const,
      lastBackupAt: '',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    };
    await setDoc(ref, initialData);
    const createdSnap = await getDoc(ref);
    return { id: createdSnap.id, ...(createdSnap.data() as Omit<ShopProfile, 'id'>) };
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `shops/${uid}`);
  }
}

export async function updateShopProfile(
  uid: string,
  patch: Partial<
    Pick<
      ShopProfile,
      | 'shopName'
      | 'ownerName'
      | 'phone'
      | 'address'
      | 'gstin'
      | 'defaultGstRate'
      | 'openingCashBalance'
      | 'openingCashDate'
      | 'pinHash'
      | 'language'
      | 'lastBackupAt'
    >
  >
): Promise<void> {
  if (uid === LOCAL_UID) return localUpdateShopProfile(uid, patch);
  const ref = shopDoc(uid);
  try {
    const cleanPatch: Record<string, unknown> = { updatedAt: serverTimestamp() };
    if (patch.shopName !== undefined) cleanPatch.shopName = cleanStr(patch.shopName, 120) || 'मेरी दुकान';
    if (patch.ownerName !== undefined) cleanPatch.ownerName = cleanStr(patch.ownerName, 100) || 'Owner';
    if (patch.phone !== undefined) cleanPatch.phone = cleanStr(patch.phone, 20);
    if (patch.address !== undefined) cleanPatch.address = cleanStr(patch.address, 300);
    if (patch.gstin !== undefined) cleanPatch.gstin = cleanStr(patch.gstin, 20);
    if (patch.defaultGstRate !== undefined) cleanPatch.defaultGstRate = Math.max(0, Math.min(50, round2(patch.defaultGstRate)));
    if (patch.openingCashBalance !== undefined) cleanPatch.openingCashBalance = round2(patch.openingCashBalance);
    if (patch.openingCashDate !== undefined) cleanPatch.openingCashDate = cleanStr(patch.openingCashDate, 20);
    if (patch.pinHash !== undefined) cleanPatch.pinHash = cleanStr(patch.pinHash, 128);
    if (patch.language !== undefined) cleanPatch.language = patch.language;
    if (patch.lastBackupAt !== undefined) cleanPatch.lastBackupAt = cleanStr(patch.lastBackupAt, 40);

    await updateDoc(ref, cleanPatch);
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `shops/${uid}`);
  }
}

export interface ProductInput {
  id?: string;
  name: string;
  category: string;
  barcode?: string;
  sku?: string;
  purchasePrice: number;
  sellingPrice: number;
  wholesalePrice?: number;
  mrp: number;
  stockQty: number;
  minStockAlert: number;
  damagedQty?: number;
  unit: string;
  description?: string;
  photoUrl?: string;
  expiryDate?: string;
  gstRate: number;
}

export async function saveProduct(uid: string, input: ProductInput): Promise<string> {
  if (uid === LOCAL_UID) return localSaveProduct(uid, input);
  const isNew = !input.id;
  const productId = input.id ? sanitizeId(input.id) : generateDocId('prod');
  const prodRef = subDoc(uid, 'products', productId);

  try {
    await runTransaction(db, async (tx) => {
      const existingSnap = isNew ? null : await tx.get(prodRef);
      const today = getTodayISO();

      const payload = {
        ownerId: uid,
        name: cleanStr(input.name, 160),
        category: cleanStr(input.category || 'General', 80),
        barcode: cleanStr(input.barcode, 64),
        sku: cleanStr(input.sku, 64),
        purchasePrice: Math.max(0, round2(input.purchasePrice)),
        sellingPrice: Math.max(0, round2(input.sellingPrice)),
        wholesalePrice: Math.max(0, round2(input.wholesalePrice ?? input.sellingPrice)),
        mrp: Math.max(0, round2(input.mrp)),
        stockQty: round2(input.stockQty),
        minStockAlert: Math.max(0, round2(input.minStockAlert)),
        damagedQty: Math.max(0, round2(input.damagedQty ?? 0)),
        unit: cleanStr(input.unit || 'Piece', 30),
        description: cleanStr(input.description, 500),
        photoUrl: cleanStr(input.photoUrl, 145000),
        expiryDate: cleanStr(input.expiryDate, 20),
        gstRate: Math.max(0, Math.min(50, round2(input.gstRate))),
        isActive: true,
        updatedAt: serverTimestamp(),
      };

      if (isNew) {
        tx.set(prodRef, { ...payload, createdAt: serverTimestamp() });
        if (payload.stockQty !== 0) {
          const movId = generateDocId('mov');
          tx.set(subDoc(uid, 'stock_movements', movId), {
            ownerId: uid,
            productId,
            productName: payload.name,
            type: 'adjustment',
            qtyChange: payload.stockQty,
            stockBefore: 0,
            stockAfter: payload.stockQty,
            unitCost: payload.purchasePrice,
            referenceId: productId,
            reason: 'Initial opening stock',
            movementDate: today,
            createdAt: serverTimestamp(),
          });
        }
        const logId = generateDocId('log');
        tx.set(subDoc(uid, 'audit_logs', logId), {
          ownerId: uid,
          action: 'PRODUCT_CREATED',
          entityType: 'product',
          entityId: productId,
          summary: cleanStr(`Added product: ${payload.name} (Stock: ${payload.stockQty})`, 300),
          createdAt: serverTimestamp(),
        });
      } else if (existingSnap?.exists()) {
        const old = existingSnap.data() as Product;
        const { ownerId: _o, ...updateFields } = payload;
        tx.update(prodRef, updateFields);
        if (round2(old.stockQty) !== payload.stockQty) {
          const movId = generateDocId('mov');
          tx.set(subDoc(uid, 'stock_movements', movId), {
            ownerId: uid,
            productId,
            productName: payload.name,
            type: 'adjustment',
            qtyChange: round2(payload.stockQty - old.stockQty),
            stockBefore: round2(old.stockQty),
            stockAfter: payload.stockQty,
            unitCost: payload.purchasePrice,
            referenceId: productId,
            reason: 'Edited product stock directly',
            movementDate: today,
            createdAt: serverTimestamp(),
          });
        }
      }
    });
    return productId;
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `shops/${uid}/products/${productId}`);
  }
}

export async function deleteProduct(uid: string, productId: string, productName: string): Promise<void> {
  if (uid === LOCAL_UID) return localDeleteProduct(uid, productId, productName);
  try {
    await deleteDoc(subDoc(uid, 'products', productId));
    await setDoc(subDoc(uid, 'audit_logs', generateDocId('log')), {
      ownerId: uid,
      action: 'PRODUCT_DELETED',
      entityType: 'product',
      entityId: productId,
      summary: cleanStr(`Deleted product: ${productName}`, 300),
      createdAt: serverTimestamp(),
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, `shops/${uid}/products/${productId}`);
  }
}

export async function updateProductPrice(
  uid: string,
  productId: string,
  updates: {
    sellingPrice?: number;
    purchasePrice?: number;
    mrp?: number;
    wholesalePrice?: number;
  },
  reason: string
): Promise<void> {
  if (uid === LOCAL_UID) return localUpdateProductPrice(uid, productId, updates, reason);
  const prodRef = subDoc(uid, 'products', productId);
  try {
    await runTransaction(db, async (tx) => {
      const snap = await tx.get(prodRef);
      if (!snap.exists()) throw new Error('Product not found');
      const prod = snap.data() as Product;

      const nextPurchase = updates.purchasePrice !== undefined ? Math.max(0, round2(updates.purchasePrice)) : prod.purchasePrice;
      const nextSelling = updates.sellingPrice !== undefined ? Math.max(0, round2(updates.sellingPrice)) : prod.sellingPrice;
      const nextMrp = updates.mrp !== undefined ? Math.max(0, round2(updates.mrp)) : prod.mrp;
      const nextWholesale = updates.wholesalePrice !== undefined ? Math.max(0, round2(updates.wholesalePrice)) : (prod.wholesalePrice ?? prod.sellingPrice);

      const margin = calculateProfitMargin(nextPurchase, nextSelling);
      const batchId = generateDocId('pbatch');
      const cleanReason = cleanStr(reason || 'Manual price update', 250);

      const changes: { type: PriceType; prev: number; next: number }[] = [];
      if (updates.purchasePrice !== undefined && nextPurchase !== prod.purchasePrice) {
        changes.push({ type: 'purchase', prev: prod.purchasePrice, next: nextPurchase });
      }
      if (updates.sellingPrice !== undefined && nextSelling !== prod.sellingPrice) {
        changes.push({ type: 'selling', prev: prod.sellingPrice, next: nextSelling });
      }
      if (updates.mrp !== undefined && nextMrp !== prod.mrp) {
        changes.push({ type: 'mrp', prev: prod.mrp, next: nextMrp });
      }
      if (updates.wholesalePrice !== undefined && nextWholesale !== (prod.wholesalePrice ?? prod.sellingPrice)) {
        changes.push({ type: 'wholesale', prev: prod.wholesalePrice ?? prod.sellingPrice, next: nextWholesale });
      }

      if (changes.length === 0) return;

      tx.update(prodRef, {
        purchasePrice: nextPurchase,
        sellingPrice: nextSelling,
        mrp: nextMrp,
        wholesalePrice: nextWholesale,
        updatedAt: serverTimestamp(),
      });

      for (const ch of changes) {
        const histId = generateDocId('ph');
        tx.set(subDoc(uid, 'price_history', histId), {
          ownerId: uid,
          productId,
          productName: prod.name,
          priceType: ch.type,
          previousPrice: ch.prev,
          newPrice: ch.next,
          changeReason: cleanReason,
          purchasePriceAtChange: nextPurchase,
          sellingPriceAtChange: nextSelling,
          profitMarginPercent: margin,
          batchId,
          createdAt: serverTimestamp(),
        });
      }

      tx.set(subDoc(uid, 'audit_logs', generateDocId('log')), {
        ownerId: uid,
        action: 'PRICE_UPDATED',
        entityType: 'product',
        entityId: productId,
        summary: cleanStr(`Updated prices for ${prod.name}: ${cleanReason}`, 300),
        createdAt: serverTimestamp(),
      });
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `shops/${uid}/products/${productId}`);
  }
}

export async function bulkUpdatePrices(
  uid: string,
  productIds: string[],
  priceType: PriceType,
  mode: 'percent' | 'fixed',
  deltaValue: number,
  reason: string
): Promise<number> {
  if (uid === LOCAL_UID) return localBulkUpdatePrices(uid, productIds, priceType, mode, deltaValue, reason);
  if (productIds.length === 0) return 0;
  const batchId = generateDocId('bulk');
  const cleanReason = cleanStr(reason || 'Bulk price update', 250);
  let updatedCount = 0;

  try {
    await runTransaction(db, async (tx) => {
      const snaps = await Promise.all(
        productIds.map((pid) => tx.get(subDoc(uid, 'products', pid)))
      );

      for (const snap of snaps) {
        if (!snap.exists()) continue;
        const prod = snap.data() as Product;
        const pid = snap.id;

        const prevVal =
          priceType === 'purchase'
            ? prod.purchasePrice
            : priceType === 'mrp'
              ? prod.mrp
              : priceType === 'wholesale'
                ? prod.wholesalePrice ?? prod.sellingPrice
                : prod.sellingPrice;

        const rawNew =
          mode === 'percent' ? prevVal * (1 + deltaValue / 100) : prevVal + deltaValue;
        const nextVal = Math.max(0, round2(rawNew));

        if (nextVal === prevVal) continue;

        const nextPurchase = priceType === 'purchase' ? nextVal : prod.purchasePrice;
        const nextSelling = priceType === 'selling' ? nextVal : prod.sellingPrice;
        const nextMrp = priceType === 'mrp' ? nextVal : prod.mrp;
        const nextWholesale =
          priceType === 'wholesale' ? nextVal : prod.wholesalePrice ?? prod.sellingPrice;

        const margin = calculateProfitMargin(nextPurchase, nextSelling);

        tx.update(subDoc(uid, 'products', pid), {
          purchasePrice: nextPurchase,
          sellingPrice: nextSelling,
          mrp: nextMrp,
          wholesalePrice: nextWholesale,
          updatedAt: serverTimestamp(),
        });

        tx.set(subDoc(uid, 'price_history', generateDocId('ph')), {
          ownerId: uid,
          productId: pid,
          productName: prod.name,
          priceType,
          previousPrice: prevVal,
          newPrice: nextVal,
          changeReason: cleanReason,
          purchasePriceAtChange: nextPurchase,
          sellingPriceAtChange: nextSelling,
          profitMarginPercent: margin,
          batchId,
          createdAt: serverTimestamp(),
        });
        updatedCount += 1;
      }

      if (updatedCount > 0) {
        tx.set(subDoc(uid, 'audit_logs', generateDocId('log')), {
          ownerId: uid,
          action: 'BULK_PRICE_UPDATE',
          entityType: 'product',
          entityId: batchId,
          summary: cleanStr(`Bulk ${priceType} update on ${updatedCount} products: ${cleanReason}`, 300),
          createdAt: serverTimestamp(),
        });
      }
    });
    return updatedCount;
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `shops/${uid}/products`);
  }
}

export interface CreateBillInput {
  billNumber: string;
  customerId?: string;
  customerName: string;
  customerPhone?: string;
  items: BillLineItem[];
  subtotal: number;
  discountAmount: number;
  gstAmount: number;
  totalAmount: number;
  paymentMode: PaymentMode;
  cashPaid: number;
  onlinePaid: number;
  cardPaid: number;
  creditAmount: number;
  billDate: string;
  notes?: string;
}

export async function createBill(uid: string, input: CreateBillInput): Promise<string> {
  if (uid === LOCAL_UID) return localCreateBill(uid, input);
  const billId = generateDocId('bill');
  const billRef = subDoc(uid, 'bills', billId);

  try {
    await runTransaction(db, async (tx) => {
      // 1. All reads FIRST
      const prodSnaps = await Promise.all(
        input.items.map((item) => tx.get(subDoc(uid, 'products', item.productId)))
      );
      const custRef = input.customerId ? subDoc(uid, 'customers', input.customerId) : null;
      const custSnap = custRef ? await tx.get(custRef) : null;

      let totalCost = 0;
      const finalizedItems: BillLineItem[] = input.items.map((item, idx) => {
        const snap = prodSnaps[idx];
        const prod = snap.exists() ? (snap.data() as Product) : null;
        const unitCost = prod ? prod.purchasePrice : item.purchasePriceAtSale;
        totalCost += round2(unitCost * item.qty);
        return {
          ...item,
          purchasePriceAtSale: unitCost,
        };
      });

      totalCost = round2(totalCost);
      const netRevenue = round2(input.totalAmount - input.gstAmount);
      const grossProfit = round2(netRevenue - totalCost);
      const paidAmount = round2(input.cashPaid + input.onlinePaid + input.cardPaid);

      // 2. Write Bill
      tx.set(billRef, {
        ownerId: uid,
        billNumber: cleanStr(input.billNumber, 40),
        customerId: cleanStr(input.customerId, 128),
        customerName: cleanStr(input.customerName, 120),
        customerPhone: cleanStr(input.customerPhone, 20),
        items: finalizedItems,
        subtotal: round2(input.subtotal),
        discountAmount: round2(input.discountAmount),
        gstAmount: round2(input.gstAmount),
        totalAmount: round2(input.totalAmount),
        totalCost,
        grossProfit,
        paymentMode: input.paymentMode,
        cashPaid: round2(input.cashPaid),
        onlinePaid: round2(input.onlinePaid),
        cardPaid: round2(input.cardPaid),
        creditAmount: round2(input.creditAmount),
        paidAmount,
        status: 'completed',
        notes: cleanStr(input.notes, 300),
        billDate: cleanStr(input.billDate, 20),
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });

      // 3. Deduct stock & log stock movements
      finalizedItems.forEach((item, idx) => {
        const snap = prodSnaps[idx];
        if (!snap.exists()) return;
        const prod = snap.data() as Product;
        const stockBefore = round2(prod.stockQty);
        const stockAfter = round2(stockBefore - item.qty);
        tx.update(subDoc(uid, 'products', item.productId), {
          stockQty: stockAfter,
          updatedAt: serverTimestamp(),
        });
        tx.set(subDoc(uid, 'stock_movements', generateDocId('mov')), {
          ownerId: uid,
          productId: item.productId,
          productName: item.productName,
          type: 'sale',
          qtyChange: -round2(item.qty),
          stockBefore,
          stockAfter,
          unitCost: item.purchasePriceAtSale,
          referenceId: billId,
          reason: cleanStr(`Bill ${input.billNumber}`, 250),
          movementDate: input.billDate,
          createdAt: serverTimestamp(),
        });
      });

      // 4. Customer Udhaar update if creditAmount > 0
      if (input.creditAmount > 0 && custRef && custSnap?.exists()) {
        const cust = custSnap.data() as Customer;
        const nextTotal = round2(cust.totalUdhaar + input.creditAmount);
        const nextRemaining = round2(nextTotal - cust.amountReceived);
        tx.update(custRef, {
          totalUdhaar: nextTotal,
          remainingBalance: nextRemaining,
          updatedAt: serverTimestamp(),
        });
        tx.set(subDoc(uid, 'udhaar_transactions', generateDocId('utx')), {
          ownerId: uid,
          customerId: custRef.id,
          customerName: cust.name,
          type: 'bill_credit',
          amount: round2(input.creditAmount),
          paymentMode: 'credit',
          billId,
          notes: cleanStr(`Credit on Bill ${input.billNumber}`, 300),
          txDate: input.billDate,
          createdAt: serverTimestamp(),
        });
      }

      // 5. Cashbook entries ONLY for actual cash/online/card received (NEVER unpaid credit)
      if (input.cashPaid > 0) {
        tx.set(subDoc(uid, 'cashbook_entries', generateDocId('cb')), {
          ownerId: uid,
          entryDate: input.billDate,
          direction: 'in',
          category: 'sale',
          paymentMode: 'cash',
          amount: round2(input.cashPaid),
          referenceId: billId,
          description: cleanStr(`Bill ${input.billNumber} (${input.customerName})`, 250),
          createdAt: serverTimestamp(),
        });
      }
      if (input.onlinePaid > 0) {
        tx.set(subDoc(uid, 'cashbook_entries', generateDocId('cb')), {
          ownerId: uid,
          entryDate: input.billDate,
          direction: 'in',
          category: 'sale',
          paymentMode: 'upi',
          amount: round2(input.onlinePaid),
          referenceId: billId,
          description: cleanStr(`UPI Bill ${input.billNumber} (${input.customerName})`, 250),
          createdAt: serverTimestamp(),
        });
      }
      if (input.cardPaid > 0) {
        tx.set(subDoc(uid, 'cashbook_entries', generateDocId('cb')), {
          ownerId: uid,
          entryDate: input.billDate,
          direction: 'in',
          category: 'sale',
          paymentMode: 'card',
          amount: round2(input.cardPaid),
          referenceId: billId,
          description: cleanStr(`Card Bill ${input.billNumber} (${input.customerName})`, 250),
          createdAt: serverTimestamp(),
        });
      }

      // 6. Audit Log
      tx.set(subDoc(uid, 'audit_logs', generateDocId('log')), {
        ownerId: uid,
        action: 'BILL_CREATED',
        entityType: 'bill',
        entityId: billId,
        summary: cleanStr(`Created Bill ${input.billNumber} for ₹${round2(input.totalAmount)}`, 300),
        createdAt: serverTimestamp(),
      });
    });

    return billId;
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `shops/${uid}/bills/${billId}`);
  }
}

export async function editBill(
  uid: string,
  billId: string,
  updated: Omit<CreateBillInput, 'billNumber'>
): Promise<void> {
  if (uid === LOCAL_UID) return localEditBill(uid, billId, updated);
  const billRef = subDoc(uid, 'bills', billId);
  try {
    await runTransaction(db, async (tx) => {
      const oldBillSnap = await tx.get(billRef);
      if (!oldBillSnap.exists()) throw new Error('Bill not found');
      const oldBill = oldBillSnap.data() as Bill;
      if (oldBill.status === 'cancelled') throw new Error('Cancelled bill cannot be edited');

      // Collect unique productIds across old and new items
      const prodIds = Array.from(
        new Set([
          ...oldBill.items.map((i) => i.productId),
          ...updated.items.map((i) => i.productId),
        ])
      );
      const prodSnaps = await Promise.all(
        prodIds.map((pid) => tx.get(subDoc(uid, 'products', pid)))
      );
      const prodMap = new Map<string, Product>();
      prodSnaps.forEach((s) => {
        if (s.exists()) prodMap.set(s.id, { id: s.id, ...(s.data() as Omit<Product, 'id'>) });
      });

      const oldCustRef = oldBill.customerId ? subDoc(uid, 'customers', oldBill.customerId) : null;
      const newCustRef = updated.customerId ? subDoc(uid, 'customers', updated.customerId) : null;
      const oldCustSnap = oldCustRef ? await tx.get(oldCustRef) : null;
      const newCustSnap =
        newCustRef && newCustRef.id !== oldCustRef?.id
          ? await tx.get(newCustRef)
          : oldCustSnap;

      // Compute net stock delta per product
      const stockDeltaMap = new Map<string, number>();
      oldBill.items.forEach((i) => {
        stockDeltaMap.set(i.productId, (stockDeltaMap.get(i.productId) || 0) + i.qty);
      });
      updated.items.forEach((i) => {
        stockDeltaMap.set(i.productId, (stockDeltaMap.get(i.productId) || 0) - i.qty);
      });

      let totalCost = 0;
      const finalizedItems: BillLineItem[] = updated.items.map((item) => {
        const p = prodMap.get(item.productId);
        const unitCost = p ? p.purchasePrice : item.purchasePriceAtSale;
        totalCost += round2(unitCost * item.qty);
        return { ...item, purchasePriceAtSale: unitCost };
      });
      totalCost = round2(totalCost);
      const netRevenue = round2(updated.totalAmount - updated.gstAmount);
      const grossProfit = round2(netRevenue - totalCost);
      const paidAmount = round2(updated.cashPaid + updated.onlinePaid + updated.cardPaid);

      // Update bill
      tx.update(billRef, {
        customerId: cleanStr(updated.customerId, 128),
        customerName: cleanStr(updated.customerName, 120),
        customerPhone: cleanStr(updated.customerPhone, 20),
        items: finalizedItems,
        subtotal: round2(updated.subtotal),
        discountAmount: round2(updated.discountAmount),
        gstAmount: round2(updated.gstAmount),
        totalAmount: round2(updated.totalAmount),
        totalCost,
        grossProfit,
        paymentMode: updated.paymentMode,
        cashPaid: round2(updated.cashPaid),
        onlinePaid: round2(updated.onlinePaid),
        cardPaid: round2(updated.cardPaid),
        creditAmount: round2(updated.creditAmount),
        paidAmount,
        status: 'edited',
        notes: cleanStr(updated.notes, 300),
        billDate: cleanStr(updated.billDate, 20),
        updatedAt: serverTimestamp(),
      });

      // Apply stock deltas
      stockDeltaMap.forEach((delta, pid) => {
        if (round2(delta) === 0) return;
        const p = prodMap.get(pid);
        if (!p) return;
        const stockBefore = round2(p.stockQty);
        const stockAfter = round2(stockBefore + delta);
        tx.update(subDoc(uid, 'products', pid), {
          stockQty: stockAfter,
          updatedAt: serverTimestamp(),
        });
        tx.set(subDoc(uid, 'stock_movements', generateDocId('mov')), {
          ownerId: uid,
          productId: pid,
          productName: p.name,
          type: 'adjustment',
          qtyChange: round2(delta),
          stockBefore,
          stockAfter,
          unitCost: p.purchasePrice,
          referenceId: billId,
          reason: cleanStr(`Edited Bill ${oldBill.billNumber}`, 250),
          movementDate: updated.billDate,
          createdAt: serverTimestamp(),
        });
      });

      // Adjust customer credit balances if changed
      if (oldCustRef && oldCustSnap?.exists() && newCustRef && oldCustRef.id === newCustRef.id) {
        const creditDiff = round2(updated.creditAmount - oldBill.creditAmount);
        if (creditDiff !== 0) {
          const cust = oldCustSnap.data() as Customer;
          const nextTotal = Math.max(0, round2(cust.totalUdhaar + creditDiff));
          tx.update(oldCustRef, {
            totalUdhaar: nextTotal,
            remainingBalance: round2(nextTotal - cust.amountReceived),
            updatedAt: serverTimestamp(),
          });
          tx.set(subDoc(uid, 'udhaar_transactions', generateDocId('utx')), {
            ownerId: uid,
            customerId: oldCustRef.id,
            customerName: cust.name,
            type: 'adjustment',
            amount: Math.abs(creditDiff),
            paymentMode: 'credit',
            billId,
            notes: cleanStr(`Bill ${oldBill.billNumber} edited (credit diff ${creditDiff >= 0 ? '+' : ''}${creditDiff})`, 300),
            txDate: updated.billDate,
            createdAt: serverTimestamp(),
          });
        }
      } else {
        if (oldCustRef && oldCustSnap?.exists() && oldBill.creditAmount > 0) {
          const oldCust = oldCustSnap.data() as Customer;
          const nextTotal = Math.max(0, round2(oldCust.totalUdhaar - oldBill.creditAmount));
          tx.update(oldCustRef, {
            totalUdhaar: nextTotal,
            remainingBalance: round2(nextTotal - oldCust.amountReceived),
            updatedAt: serverTimestamp(),
          });
        }
        if (newCustRef && newCustSnap?.exists() && updated.creditAmount > 0) {
          const newCust = newCustSnap.data() as Customer;
          const nextTotal = round2(newCust.totalUdhaar + updated.creditAmount);
          tx.update(newCustRef, {
            totalUdhaar: nextTotal,
            remainingBalance: round2(nextTotal - newCust.amountReceived),
            updatedAt: serverTimestamp(),
          });
        }
      }

      // Cashbook delta entries for edited payments
      const cashDiff = round2(updated.cashPaid - oldBill.cashPaid);
      const upiDiff = round2(updated.onlinePaid - oldBill.onlinePaid);
      const cardDiff = round2(updated.cardPaid - oldBill.cardPaid);
      if (cashDiff !== 0) {
        tx.set(subDoc(uid, 'cashbook_entries', generateDocId('cb')), {
          ownerId: uid,
          entryDate: updated.billDate,
          direction: cashDiff > 0 ? 'in' : 'out',
          category: 'sale',
          paymentMode: 'cash',
          amount: Math.abs(cashDiff),
          referenceId: billId,
          description: cleanStr(`Edited Bill ${oldBill.billNumber} Cash adjustment`, 250),
          createdAt: serverTimestamp(),
        });
      }
      if (upiDiff !== 0) {
        tx.set(subDoc(uid, 'cashbook_entries', generateDocId('cb')), {
          ownerId: uid,
          entryDate: updated.billDate,
          direction: upiDiff > 0 ? 'in' : 'out',
          category: 'sale',
          paymentMode: 'upi',
          amount: Math.abs(upiDiff),
          referenceId: billId,
          description: cleanStr(`Edited Bill ${oldBill.billNumber} UPI adjustment`, 250),
          createdAt: serverTimestamp(),
        });
      }
      if (cardDiff !== 0) {
        tx.set(subDoc(uid, 'cashbook_entries', generateDocId('cb')), {
          ownerId: uid,
          entryDate: updated.billDate,
          direction: cardDiff > 0 ? 'in' : 'out',
          category: 'sale',
          paymentMode: 'card',
          amount: Math.abs(cardDiff),
          referenceId: billId,
          description: cleanStr(`Edited Bill ${oldBill.billNumber} Card adjustment`, 250),
          createdAt: serverTimestamp(),
        });
      }

      tx.set(subDoc(uid, 'audit_logs', generateDocId('log')), {
        ownerId: uid,
        action: 'BILL_EDITED',
        entityType: 'bill',
        entityId: billId,
        summary: cleanStr(`Edited Bill ${oldBill.billNumber} -> ₹${round2(updated.totalAmount)}`, 300),
        createdAt: serverTimestamp(),
      });
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `shops/${uid}/bills/${billId}`);
  }
}

export async function cancelBill(uid: string, billId: string, reason: string): Promise<void> {
  if (uid === LOCAL_UID) return localCancelBill(uid, billId, reason);
  const billRef = subDoc(uid, 'bills', billId);
  try {
    await runTransaction(db, async (tx) => {
      const billSnap = await tx.get(billRef);
      if (!billSnap.exists()) throw new Error('Bill not found');
      const bill = billSnap.data() as Bill;
      if (bill.status === 'cancelled') return;

      const prodSnaps = await Promise.all(
        bill.items.map((item) => tx.get(subDoc(uid, 'products', item.productId)))
      );
      const custRef = bill.customerId ? subDoc(uid, 'customers', bill.customerId) : null;
      const custSnap = custRef ? await tx.get(custRef) : null;

      const today = getTodayISO();

      tx.update(billRef, {
        status: 'cancelled',
        notes: cleanStr(reason || 'Cancelled by owner', 300),
        updatedAt: serverTimestamp(),
      });

      // Restore stock
      bill.items.forEach((item, idx) => {
        const snap = prodSnaps[idx];
        if (!snap.exists()) return;
        const prod = snap.data() as Product;
        const stockBefore = round2(prod.stockQty);
        const stockAfter = round2(stockBefore + item.qty);
        tx.update(subDoc(uid, 'products', item.productId), {
          stockQty: stockAfter,
          updatedAt: serverTimestamp(),
        });
        tx.set(subDoc(uid, 'stock_movements', generateDocId('mov')), {
          ownerId: uid,
          productId: item.productId,
          productName: item.productName,
          type: 'sale_cancel',
          qtyChange: round2(item.qty),
          stockBefore,
          stockAfter,
          unitCost: item.purchasePriceAtSale,
          referenceId: billId,
          reason: cleanStr(`Bill ${bill.billNumber} cancelled: ${reason}`, 250),
          movementDate: today,
          createdAt: serverTimestamp(),
        });
      });

      // Reverse customer credit
      if (bill.creditAmount > 0 && custRef && custSnap?.exists()) {
        const cust = custSnap.data() as Customer;
        const nextTotal = Math.max(0, round2(cust.totalUdhaar - bill.creditAmount));
        tx.update(custRef, {
          totalUdhaar: nextTotal,
          remainingBalance: round2(nextTotal - cust.amountReceived),
          updatedAt: serverTimestamp(),
        });
        tx.set(subDoc(uid, 'udhaar_transactions', generateDocId('utx')), {
          ownerId: uid,
          customerId: custRef.id,
          customerName: cust.name,
          type: 'adjustment',
          amount: round2(bill.creditAmount),
          paymentMode: 'credit',
          billId,
          notes: cleanStr(`Cancelled Bill ${bill.billNumber} credit reversed`, 300),
          txDate: today,
          createdAt: serverTimestamp(),
        });
      }

      // Reverse paid cash/online/card in cashbook as refund out
      if (bill.cashPaid > 0) {
        tx.set(subDoc(uid, 'cashbook_entries', generateDocId('cb')), {
          ownerId: uid,
          entryDate: today,
          direction: 'out',
          category: 'refund',
          paymentMode: 'cash',
          amount: round2(bill.cashPaid),
          referenceId: billId,
          description: cleanStr(`Cancelled Bill ${bill.billNumber} Cash refund`, 250),
          createdAt: serverTimestamp(),
        });
      }
      if (bill.onlinePaid > 0) {
        tx.set(subDoc(uid, 'cashbook_entries', generateDocId('cb')), {
          ownerId: uid,
          entryDate: today,
          direction: 'out',
          category: 'refund',
          paymentMode: 'upi',
          amount: round2(bill.onlinePaid),
          referenceId: billId,
          description: cleanStr(`Cancelled Bill ${bill.billNumber} UPI refund`, 250),
          createdAt: serverTimestamp(),
        });
      }
      if (bill.cardPaid > 0) {
        tx.set(subDoc(uid, 'cashbook_entries', generateDocId('cb')), {
          ownerId: uid,
          entryDate: today,
          direction: 'out',
          category: 'refund',
          paymentMode: 'card',
          amount: round2(bill.cardPaid),
          referenceId: billId,
          description: cleanStr(`Cancelled Bill ${bill.billNumber} Card refund`, 250),
          createdAt: serverTimestamp(),
        });
      }

      tx.set(subDoc(uid, 'audit_logs', generateDocId('log')), {
        ownerId: uid,
        action: 'BILL_CANCELLED',
        entityType: 'bill',
        entityId: billId,
        summary: cleanStr(`Cancelled Bill ${bill.billNumber}: ${reason}`, 300),
        createdAt: serverTimestamp(),
      });
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `shops/${uid}/bills/${billId}`);
  }
}

export interface CreatePurchaseInput {
  purchaseNumber: string;
  supplierId: string;
  supplierName: string;
  items: PurchaseLineItem[];
  totalAmount: number;
  paidAmount: number;
  paymentMode: PurchasePaymentMode;
  purchaseDate: string;
  notes?: string;
  updateProductPurchaseRates?: boolean;
}

export async function createPurchase(uid: string, input: CreatePurchaseInput): Promise<string> {
  if (uid === LOCAL_UID) return localCreatePurchase(uid, input);
  const purchaseId = generateDocId('pur');
  const purchaseRef = subDoc(uid, 'purchases', purchaseId);
  const suppRef = subDoc(uid, 'suppliers', input.supplierId);

  try {
    await runTransaction(db, async (tx) => {
      const suppSnap = await tx.get(suppRef);
      const prodSnaps = await Promise.all(
        input.items.map((item) => tx.get(subDoc(uid, 'products', item.productId)))
      );

      const totalAmount = round2(input.totalAmount);
      const paidAmount = Math.min(totalAmount, Math.max(0, round2(input.paidAmount)));
      const remainingAmount = round2(totalAmount - paidAmount);

      tx.set(purchaseRef, {
        ownerId: uid,
        purchaseNumber: cleanStr(input.purchaseNumber, 40),
        supplierId: input.supplierId,
        supplierName: cleanStr(input.supplierName, 120),
        items: input.items,
        totalAmount,
        paidAmount,
        remainingAmount,
        paymentMode: input.paymentMode,
        status: 'completed',
        purchaseDate: cleanStr(input.purchaseDate, 20),
        notes: cleanStr(input.notes, 300),
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });

      // Increase stock & optionally record purchase price changes
      input.items.forEach((item, idx) => {
        const snap = prodSnaps[idx];
        if (!snap.exists()) return;
        const prod = snap.data() as Product;
        const stockBefore = round2(prod.stockQty);
        const stockAfter = round2(stockBefore + item.qty);

        const prodPatch: Record<string, unknown> = {
          stockQty: stockAfter,
          updatedAt: serverTimestamp(),
        };

        if (input.updateProductPurchaseRates && item.purchaseRate !== prod.purchasePrice) {
          prodPatch.purchasePrice = round2(item.purchaseRate);
          tx.set(subDoc(uid, 'price_history', generateDocId('ph')), {
            ownerId: uid,
            productId: item.productId,
            productName: prod.name,
            priceType: 'purchase',
            previousPrice: prod.purchasePrice,
            newPrice: round2(item.purchaseRate),
            changeReason: cleanStr(`Purchase ${input.purchaseNumber} from ${input.supplierName}`, 250),
            purchasePriceAtChange: round2(item.purchaseRate),
            sellingPriceAtChange: prod.sellingPrice,
            profitMarginPercent: calculateProfitMargin(item.purchaseRate, prod.sellingPrice),
            batchId: purchaseId,
            createdAt: serverTimestamp(),
          });
        }

        tx.update(subDoc(uid, 'products', item.productId), prodPatch);

        tx.set(subDoc(uid, 'stock_movements', generateDocId('mov')), {
          ownerId: uid,
          productId: item.productId,
          productName: item.productName,
          type: 'purchase',
          qtyChange: round2(item.qty),
          stockBefore,
          stockAfter,
          unitCost: round2(item.purchaseRate),
          referenceId: purchaseId,
          reason: cleanStr(`Purchase ${input.purchaseNumber} (${input.supplierName})`, 250),
          movementDate: input.purchaseDate,
          createdAt: serverTimestamp(),
        });
      });

      // Update supplier totals
      if (suppSnap.exists()) {
        const supp = suppSnap.data() as Supplier;
        const nextTotalPurchases = round2(supp.totalPurchases + totalAmount);
        const nextTotalPaid = round2(supp.totalPaid + paidAmount);
        tx.update(suppRef, {
          totalPurchases: nextTotalPurchases,
          totalPaid: nextTotalPaid,
          remainingOutstanding: round2(nextTotalPurchases - nextTotalPaid),
          updatedAt: serverTimestamp(),
        });
      }

      if (paidAmount > 0) {
        const cbMode = input.paymentMode === 'credit' ? 'cash' : input.paymentMode;
        tx.set(subDoc(uid, 'supplier_payments', generateDocId('spay')), {
          ownerId: uid,
          supplierId: input.supplierId,
          supplierName: cleanStr(input.supplierName, 120),
          purchaseId,
          type: 'payment',
          amount: paidAmount,
          paymentMode: cbMode,
          notes: cleanStr(`Paid on Purchase ${input.purchaseNumber}`, 300),
          paymentDate: input.purchaseDate,
          createdAt: serverTimestamp(),
        });
        tx.set(subDoc(uid, 'cashbook_entries', generateDocId('cb')), {
          ownerId: uid,
          entryDate: input.purchaseDate,
          direction: 'out',
          category: 'purchase',
          paymentMode: cbMode,
          amount: paidAmount,
          referenceId: purchaseId,
          description: cleanStr(`Purchase ${input.purchaseNumber} (${input.supplierName})`, 250),
          createdAt: serverTimestamp(),
        });
      }

      if (remainingAmount > 0) {
        tx.set(subDoc(uid, 'supplier_payments', generateDocId('spay')), {
          ownerId: uid,
          supplierId: input.supplierId,
          supplierName: cleanStr(input.supplierName, 120),
          purchaseId,
          type: 'purchase_credit',
          amount: remainingAmount,
          paymentMode: 'credit',
          notes: cleanStr(`Balance due on Purchase ${input.purchaseNumber}`, 300),
          paymentDate: input.purchaseDate,
          createdAt: serverTimestamp(),
        });
      }

      tx.set(subDoc(uid, 'audit_logs', generateDocId('log')), {
        ownerId: uid,
        action: 'PURCHASE_CREATED',
        entityType: 'purchase',
        entityId: purchaseId,
        summary: cleanStr(`Purchase ${input.purchaseNumber} from ${input.supplierName}: ₹${totalAmount}`, 300),
        createdAt: serverTimestamp(),
      });
    });

    return purchaseId;
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `shops/${uid}/purchases/${purchaseId}`);
  }
}

export async function cancelPurchase(uid: string, purchaseId: string): Promise<void> {
  if (uid === LOCAL_UID) return localCancelPurchase(uid, purchaseId);
  const purRef = subDoc(uid, 'purchases', purchaseId);
  try {
    await runTransaction(db, async (tx) => {
      const purSnap = await tx.get(purRef);
      if (!purSnap.exists()) throw new Error('Purchase not found');
      const pur = purSnap.data() as Purchase;
      if (pur.status === 'cancelled') return;

      const suppRef = subDoc(uid, 'suppliers', pur.supplierId);
      const suppSnap = await tx.get(suppRef);
      const prodSnaps = await Promise.all(
        pur.items.map((item) => tx.get(subDoc(uid, 'products', item.productId)))
      );
      const today = getTodayISO();

      tx.update(purRef, {
        status: 'cancelled',
        notes: cleanStr('Purchase cancelled', 300),
        updatedAt: serverTimestamp(),
      });

      pur.items.forEach((item, idx) => {
        const snap = prodSnaps[idx];
        if (!snap.exists()) return;
        const prod = snap.data() as Product;
        const stockBefore = round2(prod.stockQty);
        const stockAfter = round2(stockBefore - item.qty);
        tx.update(subDoc(uid, 'products', item.productId), {
          stockQty: stockAfter,
          updatedAt: serverTimestamp(),
        });
        tx.set(subDoc(uid, 'stock_movements', generateDocId('mov')), {
          ownerId: uid,
          productId: item.productId,
          productName: item.productName,
          type: 'purchase_cancel',
          qtyChange: -round2(item.qty),
          stockBefore,
          stockAfter,
          unitCost: item.purchaseRate,
          referenceId: purchaseId,
          reason: cleanStr(`Cancelled Purchase ${pur.purchaseNumber}`, 250),
          movementDate: today,
          createdAt: serverTimestamp(),
        });
      });

      if (suppSnap.exists()) {
        const supp = suppSnap.data() as Supplier;
        const nextTotal = Math.max(0, round2(supp.totalPurchases - pur.totalAmount));
        const nextPaid = Math.max(0, round2(supp.totalPaid - pur.paidAmount));
        tx.update(suppRef, {
          totalPurchases: nextTotal,
          totalPaid: nextPaid,
          remainingOutstanding: round2(nextTotal - nextPaid),
          updatedAt: serverTimestamp(),
        });
      }

      if (pur.paidAmount > 0) {
        const cbMode = pur.paymentMode === 'credit' ? 'cash' : pur.paymentMode;
        tx.set(subDoc(uid, 'cashbook_entries', generateDocId('cb')), {
          ownerId: uid,
          entryDate: today,
          direction: 'in',
          category: 'refund',
          paymentMode: cbMode,
          amount: round2(pur.paidAmount),
          referenceId: purchaseId,
          description: cleanStr(`Refund from Cancelled Purchase ${pur.purchaseNumber}`, 250),
          createdAt: serverTimestamp(),
        });
      }
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `shops/${uid}/purchases/${purchaseId}`);
  }
}

export async function saveCustomer(
  uid: string,
  input: { id?: string; name: string; phone: string; address?: string; notes?: string; initialUdhaar?: number }
): Promise<string> {
  if (uid === LOCAL_UID) return localSaveCustomer(uid, input);
  const isNew = !input.id;
  const custId = input.id ? sanitizeId(input.id) : generateDocId('cust');
  const custRef = subDoc(uid, 'customers', custId);
  try {
    await runTransaction(db, async (tx) => {
      const existingSnap = isNew ? null : await tx.get(custRef);
      if (isNew) {
        const opening = Math.max(0, round2(input.initialUdhaar || 0));
        tx.set(custRef, {
          ownerId: uid,
          name: cleanStr(input.name, 120),
          phone: cleanStr(input.phone, 20),
          address: cleanStr(input.address, 250),
          totalUdhaar: opening,
          amountReceived: 0,
          remainingBalance: opening,
          notes: cleanStr(input.notes, 300),
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
        if (opening > 0) {
          tx.set(subDoc(uid, 'udhaar_transactions', generateDocId('utx')), {
            ownerId: uid,
            customerId: custId,
            customerName: cleanStr(input.name, 120),
            type: 'udhaar',
            amount: opening,
            paymentMode: 'credit',
            notes: 'Opening udhaar balance',
            txDate: getTodayISO(),
            createdAt: serverTimestamp(),
          });
        }
      } else if (existingSnap?.exists()) {
        tx.update(custRef, {
          name: cleanStr(input.name, 120),
          phone: cleanStr(input.phone, 20),
          address: cleanStr(input.address, 250),
          notes: cleanStr(input.notes, 300),
          updatedAt: serverTimestamp(),
        });
      }
    });
    return custId;
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `shops/${uid}/customers/${custId}`);
  }
}

export async function deleteCustomer(uid: string, customerId: string): Promise<void> {
  if (uid === LOCAL_UID) return localDeleteCustomer(customerId);
  try {
    await deleteDoc(subDoc(uid, 'customers', customerId));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, `shops/${uid}/customers/${customerId}`);
  }
}

export async function recordUdhaarEntry(
  uid: string,
  input: {
    customerId: string;
    type: 'udhaar' | 'repayment';
    amount: number;
    paymentMode: 'cash' | 'upi' | 'bank' | 'card' | 'credit';
    txDate: string;
    notes?: string;
  }
): Promise<void> {
  if (uid === LOCAL_UID) return localRecordUdhaarEntry(uid, input);
  const custRef = subDoc(uid, 'customers', input.customerId);
  const amount = Math.max(0, round2(input.amount));
  if (amount <= 0) return;

  try {
    await runTransaction(db, async (tx) => {
      const snap = await tx.get(custRef);
      if (!snap.exists()) throw new Error('Customer not found');
      const cust = snap.data() as Customer;

      const nextTotalUdhaar = input.type === 'udhaar' ? round2(cust.totalUdhaar + amount) : cust.totalUdhaar;
      const nextReceived = input.type === 'repayment' ? round2(cust.amountReceived + amount) : cust.amountReceived;
      const nextRemaining = round2(nextTotalUdhaar - nextReceived);

      tx.update(custRef, {
        totalUdhaar: nextTotalUdhaar,
        amountReceived: nextReceived,
        remainingBalance: nextRemaining,
        updatedAt: serverTimestamp(),
      });

      const utxId = generateDocId('utx');
      tx.set(subDoc(uid, 'udhaar_transactions', utxId), {
        ownerId: uid,
        customerId: input.customerId,
        customerName: cust.name,
        type: input.type,
        amount,
        paymentMode: input.type === 'udhaar' ? 'credit' : input.paymentMode,
        notes: cleanStr(input.notes, 300),
        txDate: cleanStr(input.txDate, 20),
        createdAt: serverTimestamp(),
      });

      if (input.type === 'repayment') {
        const cbMode = input.paymentMode === 'credit' ? 'cash' : input.paymentMode;
        tx.set(subDoc(uid, 'cashbook_entries', generateDocId('cb')), {
          ownerId: uid,
          entryDate: input.txDate,
          direction: 'in',
          category: 'udhaar_repayment',
          paymentMode: cbMode,
          amount,
          referenceId: utxId,
          description: cleanStr(`Udhaar received from ${cust.name}`, 250),
          createdAt: serverTimestamp(),
        });
      }

      tx.set(subDoc(uid, 'audit_logs', generateDocId('log')), {
        ownerId: uid,
        action: input.type === 'udhaar' ? 'UDHAAR_ADDED' : 'UDHAAR_REPAYMENT',
        entityType: 'customer',
        entityId: input.customerId,
        summary: cleanStr(`${cust.name}: ${input.type} ₹${amount}`, 300),
        createdAt: serverTimestamp(),
      });
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `shops/${uid}/customers/${input.customerId}`);
  }
}

export async function saveSupplier(
  uid: string,
  input: { id?: string; name: string; phone: string; address?: string; gstin?: string; notes?: string; openingOutstanding?: number }
): Promise<string> {
  if (uid === LOCAL_UID) return localSaveSupplier(uid, input);
  const isNew = !input.id;
  const suppId = input.id ? sanitizeId(input.id) : generateDocId('supp');
  const suppRef = subDoc(uid, 'suppliers', suppId);
  try {
    await runTransaction(db, async (tx) => {
      const snap = isNew ? null : await tx.get(suppRef);
      if (isNew) {
        const opening = Math.max(0, round2(input.openingOutstanding || 0));
        tx.set(suppRef, {
          ownerId: uid,
          name: cleanStr(input.name, 120),
          phone: cleanStr(input.phone, 20),
          address: cleanStr(input.address, 250),
          gstin: cleanStr(input.gstin, 20),
          totalPurchases: opening,
          totalPaid: 0,
          remainingOutstanding: opening,
          notes: cleanStr(input.notes, 300),
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      } else if (snap?.exists()) {
        tx.update(suppRef, {
          name: cleanStr(input.name, 120),
          phone: cleanStr(input.phone, 20),
          address: cleanStr(input.address, 250),
          gstin: cleanStr(input.gstin, 20),
          notes: cleanStr(input.notes, 300),
          updatedAt: serverTimestamp(),
        });
      }
    });
    return suppId;
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `shops/${uid}/suppliers/${suppId}`);
  }
}

export async function deleteSupplier(uid: string, supplierId: string): Promise<void> {
  if (uid === LOCAL_UID) return localDeleteSupplier(supplierId);
  try {
    await deleteDoc(subDoc(uid, 'suppliers', supplierId));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, `shops/${uid}/suppliers/${supplierId}`);
  }
}

export async function recordSupplierPayment(
  uid: string,
  input: {
    supplierId: string;
    purchaseId?: string;
    amount: number;
    paymentMode: 'cash' | 'upi' | 'bank';
    paymentDate: string;
    notes?: string;
  }
): Promise<void> {
  if (uid === LOCAL_UID) return localRecordSupplierPayment(uid, input);
  const suppRef = subDoc(uid, 'suppliers', input.supplierId);
  const amount = Math.max(0, round2(input.amount));
  if (amount <= 0) return;

  try {
    await runTransaction(db, async (tx) => {
      const suppSnap = await tx.get(suppRef);
      if (!suppSnap.exists()) throw new Error('Supplier not found');
      const purRef = input.purchaseId ? subDoc(uid, 'purchases', input.purchaseId) : null;
      const purSnap = purRef ? await tx.get(purRef) : null;

      const supp = suppSnap.data() as Supplier;
      const nextPaid = round2(supp.totalPaid + amount);
      tx.update(suppRef, {
        totalPaid: nextPaid,
        remainingOutstanding: round2(supp.totalPurchases - nextPaid),
        updatedAt: serverTimestamp(),
      });

      if (purRef && purSnap?.exists()) {
        const pur = purSnap.data() as Purchase;
        const newPurPaid = Math.min(pur.totalAmount, round2(pur.paidAmount + amount));
        tx.update(purRef, {
          paidAmount: newPurPaid,
          remainingAmount: round2(pur.totalAmount - newPurPaid),
          updatedAt: serverTimestamp(),
        });
      }

      const spayId = generateDocId('spay');
      tx.set(subDoc(uid, 'supplier_payments', spayId), {
        ownerId: uid,
        supplierId: input.supplierId,
        supplierName: supp.name,
        purchaseId: cleanStr(input.purchaseId, 128),
        type: 'payment',
        amount,
        paymentMode: input.paymentMode,
        notes: cleanStr(input.notes, 300),
        paymentDate: cleanStr(input.paymentDate, 20),
        createdAt: serverTimestamp(),
      });

      tx.set(subDoc(uid, 'cashbook_entries', generateDocId('cb')), {
        ownerId: uid,
        entryDate: input.paymentDate,
        direction: 'out',
        category: 'supplier_payment',
        paymentMode: input.paymentMode,
        amount,
        referenceId: spayId,
        description: cleanStr(`Paid to supplier ${supp.name}`, 250),
        createdAt: serverTimestamp(),
      });

      tx.set(subDoc(uid, 'audit_logs', generateDocId('log')), {
        ownerId: uid,
        action: 'SUPPLIER_PAYMENT',
        entityType: 'supplier',
        entityId: input.supplierId,
        summary: cleanStr(`Paid ₹${amount} to ${supp.name}`, 300),
        createdAt: serverTimestamp(),
      });
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `shops/${uid}/suppliers/${input.supplierId}`);
  }
}

export async function saveExpense(
  uid: string,
  input: {
    id?: string;
    category: ExpenseCategory;
    title: string;
    amount: number;
    paymentMode: ExpensePaymentMode;
    expenseDate: string;
    notes?: string;
  }
): Promise<string> {
  if (uid === LOCAL_UID) return localSaveExpense(uid, input);
  const isNew = !input.id;
  const expId = input.id ? sanitizeId(input.id) : generateDocId('exp');
  const expRef = subDoc(uid, 'expenses', expId);
  const amount = round2(input.amount);
  if (amount <= 0) throw new Error('Expense amount must be greater than 0');

  try {
    await runTransaction(db, async (tx) => {
      const existingSnap = isNew ? null : await tx.get(expRef);
      if (isNew) {
        tx.set(expRef, {
          ownerId: uid,
          category: input.category,
          title: cleanStr(input.title, 140),
          amount,
          paymentMode: input.paymentMode,
          expenseDate: cleanStr(input.expenseDate, 20),
          notes: cleanStr(input.notes, 300),
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
        tx.set(subDoc(uid, 'cashbook_entries', generateDocId('cb')), {
          ownerId: uid,
          entryDate: input.expenseDate,
          direction: 'out',
          category: 'expense',
          paymentMode: input.paymentMode,
          amount,
          referenceId: expId,
          description: cleanStr(`Expense: ${input.title}`, 250),
          createdAt: serverTimestamp(),
        });
      } else if (existingSnap?.exists()) {
        const old = existingSnap.data() as Expense;
        tx.update(expRef, {
          category: input.category,
          title: cleanStr(input.title, 140),
          amount,
          paymentMode: input.paymentMode,
          expenseDate: cleanStr(input.expenseDate, 20),
          notes: cleanStr(input.notes, 300),
          updatedAt: serverTimestamp(),
        });
        const diff = round2(amount - old.amount);
        if (diff !== 0) {
          tx.set(subDoc(uid, 'cashbook_entries', generateDocId('cb')), {
            ownerId: uid,
            entryDate: input.expenseDate,
            direction: diff > 0 ? 'out' : 'in',
            category: 'expense',
            paymentMode: input.paymentMode,
            amount: Math.abs(diff),
            referenceId: expId,
            description: cleanStr(`Expense adjusted: ${input.title}`, 250),
            createdAt: serverTimestamp(),
          });
        }
      }
    });
    return expId;
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `shops/${uid}/expenses/${expId}`);
  }
}

export async function deleteExpense(uid: string, expenseId: string): Promise<void> {
  if (uid === LOCAL_UID) return localDeleteExpense(expenseId);
  try {
    await deleteDoc(subDoc(uid, 'expenses', expenseId));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, `shops/${uid}/expenses/${expenseId}`);
  }
}

export async function adjustStock(
  uid: string,
  input: {
    productId: string;
    type: Extract<StockMovementType, 'adjustment' | 'damage' | 'expiry' | 'audit'>;
    newStockQty?: number;
    qtyDelta?: number;
    reason: string;
    movementDate: string;
  }
): Promise<void> {
  if (uid === LOCAL_UID) return localAdjustStock(uid, input);
  const prodRef = subDoc(uid, 'products', input.productId);
  try {
    await runTransaction(db, async (tx) => {
      const snap = await tx.get(prodRef);
      if (!snap.exists()) throw new Error('Product not found');
      const prod = snap.data() as Product;
      const stockBefore = round2(prod.stockQty);

      let stockAfter = stockBefore;
      let qtyChange = 0;

      if (input.newStockQty !== undefined) {
        stockAfter = round2(input.newStockQty);
        qtyChange = round2(stockAfter - stockBefore);
      } else if (input.qtyDelta !== undefined) {
        qtyChange = round2(input.qtyDelta);
        stockAfter = round2(stockBefore + qtyChange);
      }

      let nextDamaged = prod.damagedQty || 0;
      if ((input.type === 'damage' || input.type === 'expiry') && qtyChange < 0) {
        nextDamaged = round2(nextDamaged + Math.abs(qtyChange));
      }

      tx.update(prodRef, {
        stockQty: stockAfter,
        damagedQty: nextDamaged,
        updatedAt: serverTimestamp(),
      });

      tx.set(subDoc(uid, 'stock_movements', generateDocId('mov')), {
        ownerId: uid,
        productId: input.productId,
        productName: prod.name,
        type: input.type,
        qtyChange,
        stockBefore,
        stockAfter,
        unitCost: prod.purchasePrice,
        referenceId: input.productId,
        reason: cleanStr(input.reason || input.type, 250),
        movementDate: cleanStr(input.movementDate, 20),
        createdAt: serverTimestamp(),
      });

      tx.set(subDoc(uid, 'audit_logs', generateDocId('log')), {
        ownerId: uid,
        action: `STOCK_${input.type.toUpperCase()}`,
        entityType: 'product',
        entityId: input.productId,
        summary: cleanStr(`${prod.name}: ${stockBefore} -> ${stockAfter} (${input.reason})`, 300),
        createdAt: serverTimestamp(),
      });
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `shops/${uid}/products/${input.productId}`);
  }
}

export async function processReturn(
  uid: string,
  input: {
    returnType: 'customer_return' | 'supplier_return';
    referenceId?: string;
    referenceNumber?: string;
    partyId?: string;
    partyName: string;
    items: ReturnLineItem[];
    totalAmount: number;
    refundMode: 'cash' | 'upi' | 'credit_adjust' | 'none';
    stockCondition: 'restock' | 'damaged';
    returnDate: string;
    notes?: string;
  }
): Promise<string> {
  if (uid === LOCAL_UID) return localProcessReturn(uid, input);
  const retId = generateDocId('ret');
  const retRef = subDoc(uid, 'returns', retId);

  try {
    await runTransaction(db, async (tx) => {
      const prodSnaps = await Promise.all(
        input.items.map((i) => tx.get(subDoc(uid, 'products', i.productId)))
      );
      const partyRef = input.partyId
        ? subDoc(
            uid,
            input.returnType === 'customer_return' ? 'customers' : 'suppliers',
            input.partyId
          )
        : null;
      const partySnap = partyRef ? await tx.get(partyRef) : null;

      const totalAmount = round2(input.totalAmount);

      tx.set(retRef, {
        ownerId: uid,
        returnType: input.returnType,
        referenceId: cleanStr(input.referenceId, 128),
        referenceNumber: cleanStr(input.referenceNumber, 40),
        partyId: cleanStr(input.partyId, 128),
        partyName: cleanStr(input.partyName, 120),
        items: input.items,
        totalAmount,
        refundMode: input.refundMode,
        stockCondition: input.stockCondition,
        notes: cleanStr(input.notes, 300),
        returnDate: cleanStr(input.returnDate, 20),
        createdAt: serverTimestamp(),
      });

      // Adjust stock
      input.items.forEach((item, idx) => {
        const snap = prodSnaps[idx];
        if (!snap.exists()) return;
        const prod = snap.data() as Product;
        const stockBefore = round2(prod.stockQty);

        if (input.returnType === 'customer_return') {
          if (input.stockCondition === 'restock') {
            const stockAfter = round2(stockBefore + item.qty);
            tx.update(subDoc(uid, 'products', item.productId), {
              stockQty: stockAfter,
              updatedAt: serverTimestamp(),
            });
            tx.set(subDoc(uid, 'stock_movements', generateDocId('mov')), {
              ownerId: uid,
              productId: item.productId,
              productName: item.productName,
              type: 'customer_return',
              qtyChange: round2(item.qty),
              stockBefore,
              stockAfter,
              unitCost: prod.purchasePrice,
              referenceId: retId,
              reason: cleanStr(`Customer return (${input.partyName})`, 250),
              movementDate: input.returnDate,
              createdAt: serverTimestamp(),
            });
          } else {
            tx.update(subDoc(uid, 'products', item.productId), {
              damagedQty: round2((prod.damagedQty || 0) + item.qty),
              updatedAt: serverTimestamp(),
            });
            tx.set(subDoc(uid, 'stock_movements', generateDocId('mov')), {
              ownerId: uid,
              productId: item.productId,
              productName: item.productName,
              type: 'damage',
              qtyChange: 0,
              stockBefore,
              stockAfter: stockBefore,
              unitCost: prod.purchasePrice,
              referenceId: retId,
              reason: cleanStr(`Damaged customer return (${input.partyName})`, 250),
              movementDate: input.returnDate,
              createdAt: serverTimestamp(),
            });
          }
        } else {
          // Supplier return reduces stock
          const stockAfter = round2(stockBefore - item.qty);
          tx.update(subDoc(uid, 'products', item.productId), {
            stockQty: stockAfter,
            updatedAt: serverTimestamp(),
          });
          tx.set(subDoc(uid, 'stock_movements', generateDocId('mov')), {
            ownerId: uid,
            productId: item.productId,
            productName: item.productName,
            type: 'supplier_return',
            qtyChange: -round2(item.qty),
            stockBefore,
            stockAfter,
            unitCost: item.unitPrice,
            referenceId: retId,
            reason: cleanStr(`Returned to supplier (${input.partyName})`, 250),
            movementDate: input.returnDate,
            createdAt: serverTimestamp(),
          });
        }
      });

      // Financial adjustments
      if (input.refundMode === 'cash' || input.refundMode === 'upi') {
        tx.set(subDoc(uid, 'cashbook_entries', generateDocId('cb')), {
          ownerId: uid,
          entryDate: input.returnDate,
          direction: input.returnType === 'customer_return' ? 'out' : 'in',
          category: 'refund',
          paymentMode: input.refundMode,
          amount: totalAmount,
          referenceId: retId,
          description: cleanStr(
            input.returnType === 'customer_return'
              ? `Refund to ${input.partyName}`
              : `Refund from supplier ${input.partyName}`,
            250
          ),
          createdAt: serverTimestamp(),
        });
      } else if (input.refundMode === 'credit_adjust' && partyRef && partySnap?.exists()) {
        if (input.returnType === 'customer_return') {
          const cust = partySnap.data() as Customer;
          const nextReceived = round2(cust.amountReceived + totalAmount);
          tx.update(partyRef, {
            amountReceived: nextReceived,
            remainingBalance: round2(cust.totalUdhaar - nextReceived),
            updatedAt: serverTimestamp(),
          });
          tx.set(subDoc(uid, 'udhaar_transactions', generateDocId('utx')), {
            ownerId: uid,
            customerId: partyRef.id,
            customerName: cust.name,
            type: 'return_credit',
            amount: totalAmount,
            paymentMode: 'credit',
            notes: cleanStr(`Return credit adjusted`, 300),
            txDate: input.returnDate,
            createdAt: serverTimestamp(),
          });
        } else {
          const supp = partySnap.data() as Supplier;
          const nextPaid = round2(supp.totalPaid + totalAmount);
          tx.update(partyRef, {
            totalPaid: nextPaid,
            remainingOutstanding: round2(supp.totalPurchases - nextPaid),
            updatedAt: serverTimestamp(),
          });
          tx.set(subDoc(uid, 'supplier_payments', generateDocId('spay')), {
            ownerId: uid,
            supplierId: partyRef.id,
            supplierName: supp.name,
            type: 'return_debit',
            amount: totalAmount,
            paymentMode: 'credit',
            notes: cleanStr(`Supplier return adjusted`, 300),
            paymentDate: input.returnDate,
            createdAt: serverTimestamp(),
          });
        }
      }

      tx.set(subDoc(uid, 'audit_logs', generateDocId('log')), {
        ownerId: uid,
        action: 'RETURN_PROCESSED',
        entityType: 'return',
        entityId: retId,
        summary: cleanStr(`${input.returnType} (${input.partyName}): ₹${totalAmount}`, 300),
        createdAt: serverTimestamp(),
      });
    });

    return retId;
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `shops/${uid}/returns/${retId}`);
  }
}

export async function addManualCashbookEntry(
  uid: string,
  input: {
    entryDate: string;
    direction: 'in' | 'out';
    paymentMode: 'cash' | 'upi' | 'bank' | 'card';
    amount: number;
    description: string;
  }
): Promise<void> {
  if (uid === LOCAL_UID) return localAddManualCashbookEntry(uid, input);
  const cbId = generateDocId('cb');
  try {
    await setDoc(subDoc(uid, 'cashbook_entries', cbId), {
      ownerId: uid,
      entryDate: cleanStr(input.entryDate, 20),
      direction: input.direction,
      category: 'manual',
      paymentMode: input.paymentMode,
      amount: Math.max(0, round2(input.amount)),
      description: cleanStr(input.description, 250),
      createdAt: serverTimestamp(),
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, `shops/${uid}/cashbook_entries/${cbId}`);
  }
}

const BACKUP_COLLECTIONS = [
  'products',
  'price_history',
  'bills',
  'purchases',
  'customers',
  'udhaar_transactions',
  'suppliers',
  'supplier_payments',
  'expenses',
  'stock_movements',
  'returns',
  'cashbook_entries',
] as const;

export async function exportShopBackup(uid: string): Promise<Record<string, unknown>> {
  if (uid === LOCAL_UID) return localExportShopBackup(uid);
  try {
    const profileSnap = await getDoc(shopDoc(uid));
    const data: Record<string, unknown> = {
      exportedAt: new Date().toISOString(),
      version: 1,
      shopProfile: profileSnap.exists() ? profileSnap.data() : null,
      collections: {},
    };

    const colMap: Record<string, Record<string, unknown>[]> = {};
    for (const colName of BACKUP_COLLECTIONS) {
      const snap = await getDocs(subCol(uid, colName));
      colMap[colName] = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
    }
    data.collections = colMap;

    await updateDoc(shopDoc(uid), {
      lastBackupAt: new Date().toISOString(),
      updatedAt: serverTimestamp(),
    });

    return data;
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, `shops/${uid}`);
  }
}

export async function importShopBackup(
  uid: string,
  backupJson: Record<string, unknown>
): Promise<number> {
  if (uid === LOCAL_UID) return localImportShopBackup(uid, backupJson);
  try {
    const collections = backupJson.collections as Record<string, Record<string, unknown>[]> | undefined;
    if (!collections || typeof collections !== 'object') {
      throw new Error('Invalid backup file format');
    }

    let ops: { ref: ReturnType<typeof subDoc>; data: Record<string, unknown> }[] = [];

    for (const colName of BACKUP_COLLECTIONS) {
      const docs = collections[colName];
      if (!Array.isArray(docs)) continue;
      for (const raw of docs) {
        const docId = sanitizeId(String(raw.id || generateDocId(colName.slice(0, 4))));
        const { id: _id, createdAt: _c, updatedAt: _u, ...rest } = raw;
        const payload: Record<string, unknown> = {
          ...rest,
          ownerId: uid,
          createdAt: serverTimestamp(),
        };
        if (['products', 'bills', 'purchases', 'customers', 'suppliers', 'expenses'].includes(colName)) {
          payload.updatedAt = serverTimestamp();
        }
        ops.push({ ref: subDoc(uid, colName, docId), data: payload });
      }
    }

    // Commit in batches of 350
    for (let i = 0; i < ops.length; i += 350) {
      const batch = writeBatch(db);
      const chunk = ops.slice(i, i + 350);
      chunk.forEach((op) => batch.set(op.ref, op.data));
      await batch.commit();
    }

    return ops.length;
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `shops/${uid}`);
  }
}
