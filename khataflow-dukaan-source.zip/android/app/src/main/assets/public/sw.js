/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-afac4cd2'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "pwa-maskable-512x512.png",
    "revision": "93dcce1da226a1f8d71823a32035f96e"
  }, {
    "url": "pwa-512x512.png",
    "revision": "497f827686e634b903649e149fb76233"
  }, {
    "url": "pwa-192x192.png",
    "revision": "aa6643d7e0dd6769ab51263e12b98a86"
  }, {
    "url": "index.html",
    "revision": "7d627dbbc776ff46864072118aece78b"
  }, {
    "url": "icon.svg",
    "revision": "70bd2e382d58832efe19b044ac969bfe"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "11b71df75555b6d2c03628ff72e79535"
  }, {
    "url": "src/assets/images/shop_storefront_hero_1795069501253.jpg",
    "revision": "0efe3b709370c77aef8d2e77c5a66e4a"
  }, {
    "url": "src/assets/images/dukaan_brand_emblem_1795069501237.jpg",
    "revision": "1f775a72f45d696902002edfeed2f826"
  }, {
    "url": "assets/workbox-window.prod.es5-Bd17z0YL.js",
    "revision": null
  }, {
    "url": "assets/web-Z5xUDkWQ.js",
    "revision": null
  }, {
    "url": "assets/web-B3dJN5L6.js",
    "revision": null
  }, {
    "url": "assets/index-xOKdQs8O.js",
    "revision": null
  }, {
    "url": "assets/index-CerKEg45.css",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "11b71df75555b6d2c03628ff72e79535"
  }, {
    "url": "icon.svg",
    "revision": "70bd2e382d58832efe19b044ac969bfe"
  }, {
    "url": "pwa-192x192.png",
    "revision": "aa6643d7e0dd6769ab51263e12b98a86"
  }, {
    "url": "pwa-512x512.png",
    "revision": "497f827686e634b903649e149fb76233"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "93dcce1da226a1f8d71823a32035f96e"
  }, {
    "url": "manifest.webmanifest",
    "revision": "10e73ebeec06f475c7876e43ad6a1a49"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html"), {
    denylist: [/\.zip$/i, /^\/api\//, /^\/healthz$/]
  }));
  workbox.registerRoute(/^https:\/\/fonts\.googleapis\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "google-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(/^https:\/\/fonts\.gstatic\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "gstatic-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');

}));
